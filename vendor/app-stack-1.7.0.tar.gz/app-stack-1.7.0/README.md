# App-Stack 1.7.0

The framework, packaged. Nothing here is edited: this directory is extracted from
`vendor/app-stack-1.7.0.tar.gz` at build time and is not tracked by the
consuming repository, so a local change to it is invisible and does not survive.

- `packages/core`, `packages/cli` — the runtime and the launcher.
- `packages/ui` — `component-names.ts` only, which the launcher reads to refuse a
  view naming a component that does not exist. The components themselves are in
  `dist/`, already built.
- `dist/` — the browser bundle. App-independent: the launcher injects the
  projection as `window.__APP__`.
- `docs/stack` — the reference for everything an app declares in config. The
  `bun docs/stack/checks/…` commands it names are app-stack's own gates and run
  there, not here.
- `docs/learnings` — the traps that bite an app author, not the framework's own.

**To change the framework, change app-stack and cut a new release.** A behaviour
gap is a version bump here, never a patch.
