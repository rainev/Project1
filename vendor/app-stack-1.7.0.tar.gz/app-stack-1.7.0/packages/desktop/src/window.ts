/**
 * Open a config directory in a desktop window.
 *
 * Layer 0, and deliberately the thinnest thing in the framework: it starts the ordinary server on
 * a loopback port, waits until that server answers, and points a native window at it. It holds no
 * capability of its own — no file access, no privileged bridge into the page — so the product
 * keeps working if this is replaced with a different wrapper, or with none.
 *
 * Three things here are not decoration, each measured:
 *
 *  - **`exitProcessOnClose: false`.** With `true`, clicking the window's close button crashes
 *    Neutralino 6.9.0 on macOS 26.2 — `dispatch_sync` on the main queue from the main thread,
 *    every time, 3 runs out of 3. With `false` it never does, and the page quits through
 *    `Neutralino.app.exit(0)` instead.
 *  - **`--parent-pid`.** Neutralino does not reap what it spawns. The service watches this
 *    process instead, so closing the window takes the server and every terminal it started with
 *    it — verified down to a job backgrounded inside a terminal.
 *  - **Wait for `/health` before showing the page.** The server compiles config, migrates and
 *    probes a sandbox before it answers; a window opened into that gap shows a connection error
 *    and looks broken.
 */
import { randomBytes } from 'node:crypto';
import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export interface WindowOptions {
  /** The app's config directory, as `run.ts` takes it. */
  configDir: string;
  title?: string;
  width?: number;
  height?: number;
  /** Flags passed through to the server unchanged (`--workspace-base`, `--database`, …). */
  serverArgs?: string[];
  /** Where the generated wrapper lives. Default: `.data/window` beside the app being run. */
  appDir?: string;
}

const CLI = fileURLToPath(new URL('../../cli/src/run.ts', import.meta.url));

/**
 * Keys the app keeps for itself.
 *
 * `JWT_SECRET` signs session cookies; `APP_DEK` encrypts fields a model declares encrypted. A
 * hosted deployment must supply both and the server refuses to boot without them in production —
 * that is correct there, where an operator is deploying on purpose.
 *
 * A desktop app has no operator. Asking someone to export two environment variables before
 * double-clicking their editor is asking them to be a deployment, and the usual result is the
 * ephemeral fallback: every restart invalidates sessions and loses anything encrypted, with a
 * warning nobody reads. So the launcher generates them once, 0600, beside the app's data, and
 * passes them in. Same guarantee as a server, none of the ceremony.
 */
async function ensureKeys(dataDir: string): Promise<Record<string, string>> {
  const keys: Record<string, string> = {};
  for (const [name, file] of [['JWT_SECRET', 'jwt.key'], ['APP_DEK', 'dek.key']] as const) {
    const path = join(dataDir, file);
    if (!existsSync(path)) {
      await mkdir(dataDir, { recursive: true });
      await writeFile(path, `${randomBytes(32).toString('base64')}\n`, { mode: 0o600 });
    }
    keys[`${name}_FILE`] = path;
  }
  return keys;
}

/** Start the server on a port it chooses, and return the URL once it answers. */
async function startServer(options: WindowOptions, env: Record<string, string>): Promise<{ url: string; stop: () => void }> {
  const args = [
    'run', CLI, options.configDir,
    '--port', '0',                    // the kernel picks; parsing one line beats racing for a port
    '--bind', '127.0.0.1',
    '--parent-pid', String(process.pid),
    ...(options.title ? ['--title', options.title] : []),
    ...(options.serverArgs ?? []),
  ];
  const child = spawn('bun', args, {
    stdio: ['pipe', 'pipe', 'inherit'],
    // The caller's own JWT_SECRET/APP_DEK win: someone who set them meant it.
    env: { ...env, ...process.env },
  });
  const stop = () => { try { child.kill('SIGTERM'); } catch { /* already gone */ } };

  const url = await new Promise<string>((res, rej) => {
    let seen = '';
    const timer = setTimeout(() => rej(new Error(`the server printed no address in 60s:\n${seen}`)), 60_000);
    child.stdout.on('data', (chunk: Buffer) => {
      seen += chunk.toString();
      process.stdout.write(chunk);                       // the server's own startup lines stay visible
      const match = seen.match(/listening on (http:\/\/[^\s]+)/);
      if (match) { clearTimeout(timer); res(match[1].replace(/\/$/, '')); }
    });
    child.on('exit', (code) => { clearTimeout(timer); rej(new Error(`the server exited (${code}) before it listened`)); });
  });

  // Listening is not the same as ready.
  for (let attempt = 0; attempt < 120; attempt++) {
    try {
      const response = await fetch(`${url}/health`);
      if (response.ok) return { url, stop };
    } catch { /* not up yet */ }
    await new Promise((r) => setTimeout(r, 250));
  }
  stop();
  throw new Error(`${url}/health never answered`);
}

/**
 * Make sure the wrapper exists. The first run downloads Neutralino's client binaries (~20 MB)
 * through its own CLI; later runs reuse them. Nothing is downloaded at page-load time.
 */
async function ensureWrapper(appDir: string): Promise<void> {
  /*
   * "It exists" is not "it works". A wrapper left behind by an older launcher can carry a config
   * this one did not write, and `neu run` dies on a missing key with a stack trace from inside
   * its own file watcher — which says nothing about the real problem. Check for the keys the tool
   * owns, and rebuild the wrapper rather than patching something unrecognised.
   */
  const configPath = join(appDir, 'neutralino.config.json');
  if (existsSync(join(appDir, 'bin')) && existsSync(configPath)) {
    try {
      const existing = JSON.parse(await readFile(configPath, 'utf8')) as Record<string, unknown>;
      if (existing.cli && existing.modes) return;
    } catch { /* unreadable: rebuild it */ }
    console.log('  the window runtime looks incomplete — rebuilding it');
    await rm(appDir, { recursive: true, force: true });
  }
  await mkdir(dirname(appDir), { recursive: true });
  console.log('  fetching the window runtime (first run only)…');
  await new Promise<void>((res, rej) => {
    const child = spawn('npx', ['--yes', '@neutralinojs/neu@latest', 'create', appDir.split('/').pop()!],
      { cwd: dirname(appDir), stdio: 'inherit' });
    child.on('exit', (code) => (code === 0 ? res() : rej(new Error(`could not create the window runtime (exit ${code})`))));
  });
}

/** The page the window loads first: it redirects to the app, and owns the quit path. */
const loader = (url: string) => `<!doctype html><meta charset=utf-8><title>loading</title>
<style>body{margin:0;display:grid;place-items:center;height:100vh;background:#0f0f13;color:#8a8a9a;
font:14px ui-monospace,Menlo,monospace}</style>
<body>starting…
<script src="/js/neutralino.js"></script><script>
  Neutralino.init();
  // The close button is left to the OS, and the OS path is the one that crashes this wrapper —
  // so the app exits through Neutralino instead, and the window is told to go to the server.
  Neutralino.events.on('windowClose', () => Neutralino.app.exit(0));
  location.replace(${JSON.stringify(url)});
</script>`;

export async function openWindow(options: WindowOptions): Promise<number> {
  // Beside the app, not inside its config: `<configDir>/..` is `app/` in the vendoring layout,
  // and a generated wrapper does not belong in the directory that is supposed to be only YAML.
  const appDir = options.appDir ?? resolve(process.cwd(), '.data', 'window');
  const keys = await ensureKeys(resolve(process.cwd(), '.data'));
  const { url, stop } = await startServer(options, keys);
  await ensureWrapper(appDir);

  await writeFile(join(appDir, 'resources', 'index.html'), loader(url));

  /*
   * PATCH the scaffold's config rather than writing one.
   *
   * `neu run` reads keys the wrapper's own tooling owns — `cli.resourcesPath` among them — and a
   * hand-written config that looks complete crashes it with `Cannot read properties of undefined`.
   * Generating only the fields this launcher actually decides leaves the rest to the tool that
   * understands them, and survives the next version adding another.
   */
  const configPath = join(appDir, 'neutralino.config.json');
  const config = JSON.parse(await readFile(configPath, 'utf8')) as Record<string, any>;
  config.nativeAllowList = ['app.*', 'os.*', 'window.*', 'events.*', 'debug.log'];
  config.modes = {
    ...(config.modes ?? {}),
    window: {
      ...(config.modes?.window ?? {}),
      title: options.title ?? 'app-stack',
      width: options.width ?? 1400,
      height: options.height ?? 900,
      minWidth: 720,
      minHeight: 480,
      center: true,
      // Measured: `true` crashes this wrapper on every close. See the header.
      exitProcessOnClose: false,
    },
  };
  await writeFile(configPath, `${JSON.stringify(config, null, 2)}\n`);

  console.log(`  window → ${url}`);
  const exitCode = await new Promise<number>((res) => {
    const child = spawn('npx', ['--yes', '@neutralinojs/neu@latest', 'run'], { cwd: appDir, stdio: 'inherit' });
    const bye = () => { try { child.kill('SIGTERM'); } catch { /* gone */ } };
    process.on('SIGINT', bye);
    process.on('SIGTERM', bye);
    child.on('exit', (code) => res(code ?? 0));
  });

  stop();            // belt: the service also dies with this process via --parent-pid
  return exitCode;
}

if (import.meta.main) {
  const argv = process.argv.slice(2);
  const configDir = argv.find((a) => !a.startsWith('--'));
  if (!configDir) {
    console.error('usage: window <configDir> [--title <text>] [server flags…]');
    process.exit(2);
  }
  const titleAt = argv.indexOf('--title');
  const serverArgs = argv.filter((a, i) =>
    a !== configDir && i !== titleAt && i !== titleAt + 1);
  process.exit(await openWindow({
    configDir: resolve(configDir),
    title: titleAt >= 0 ? argv[titleAt + 1] : undefined,
    serverArgs,
  }));
}
