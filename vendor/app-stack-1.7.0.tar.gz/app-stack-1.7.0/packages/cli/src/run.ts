#!/usr/bin/env bun
/**
 * `blitzpi run <configDir>` — roadmap initiative 9, DEF-007.
 *
 * The whole claim of this framework is that an application is a directory of
 * YAML. This is the command that makes the claim falsifiable: point it at a
 * config directory and a secured, running application comes up — the same
 * binary, the same generic bundle, no build step and no code generation.
 *
 * It is deliberately thin. `createApp` already compiles the config, migrates,
 * resolves keys, builds the dispatcher and serves; the launcher's only jobs are
 * to find the bundle, read the flags, and fail with something an operator can
 * act on. The roadmap is explicit that this is not a packaging or distribution
 * project and should not be scoped as one.
 */
import { existsSync, fstatSync } from 'node:fs';
import { resolve } from 'node:path';
import { createApp, resolveDatabaseUrl } from '@appstack/core';
import { BUILTIN_ICON_NAMES, COMPONENT_NAMES, COMPONENT_PROPS } from '@appstack/ui/component-names';

const USAGE = `blitzpi run <config-dir> [options]

  A directory of YAML becomes a running, secured application.

  --port <n>        Port to listen on (default: PORT, else 3000)
  --bind <host>     Interface to listen on (default: every interface). Use
                    127.0.0.1 to keep the server on this machine.
  --parent-pid <n>  Exit when that process goes away, killing any channel
                    processes too. Shell-agnostic on purpose: a desktop wrapper
                    that does not reap its own children (Neutralino does not)
                    gets the same behaviour as a bare terminal.
  --local-actor     No sign-in: run every request as one local administrator.
                    For a single-user desktop app. Refused unless --bind names a
                    loopback address.
  --workspace-base <dir>
                    The directory every x-channels root must sit under
                    (default: your home directory). A channel whose row points
                    outside it is refused before anything starts.
  --database <url>  sqlite:// | postgres:// | mysql://  (default: DATABASE_URL,
                    else sqlite://.data/<name>.sqlite beside the config)
  --dist <dir>      The built UI bundle (default: the framework's own)
  --title <text>    Document title
  --files <dir>     Where uploaded bytes live (default: .data/files)
  --no-ui           Serve the API only; do not look for a bundle
`;

function parse(argv: string[]) {
  const [dir, ...rest] = argv;
  const flags: Record<string, string | boolean> = {};
  for (let i = 0; i < rest.length; i++) {
    const arg = rest[i]!;
    if (!arg.startsWith('--')) throw new Error(`unexpected argument "${arg}"`);
    const name = arg.slice(2);
    if (name === 'no-ui' || name === 'local-actor') { flags[name] = true; continue; }
    const value = rest[++i];
    if (value === undefined) throw new Error(`--${name} needs a value`);
    flags[name] = value;
  }
  return { dir, flags };
}

/**
 * The generic bundle, which ships with the framework rather than with the app.
 *
 * That is the point of §19's design: the bundle carries no app definition, so
 * one build serves every config directory. A missing one is an operator-facing
 * error naming the command that produces it, not a 503 discovered later.
 */
function resolveDist(explicit: string | undefined): string {
  const candidates = explicit
    ? [resolve(explicit)]
    : [resolve(import.meta.dir, '../../../apps/showcase/web/dist')];
  const found = candidates.find((path) => existsSync(`${path}/index.html`));
  if (!found) {
    throw new Error(
      `no UI bundle at ${candidates.join(' or ')}. Build it with \`bun run build:web\`, ` +
      'pass --dist <dir>, or pass --no-ui to serve the API alone.',
    );
  }
  return found;
}

const argv = Bun.argv.slice(2);
if (argv.length === 0 || argv[0] === '--help' || argv[0] === '-h') {
  console.log(USAGE);
  process.exit(argv.length === 0 ? 2 : 0);
}

const { dir, flags } = parse(argv);
const configDir = resolve(dir!);

// Checked here rather than left to the loader, because "no models found" names
// a directory the caller may not have meant to type.
if (!existsSync(`${configDir}/models`)) {
  console.error(`blitzpi run: ${configDir} has no models/ directory — is that the config directory?`);
  process.exit(2);
}

const name = configDir.split('/').filter(Boolean).slice(-2)[0] ?? 'app';

const { server, models, applied, shutdown } = await createApp({
  configDir,
  distDir: flags['no-ui'] ? undefined : resolveDist(flags.dist as string | undefined),
  databaseUrl: (flags.database as string) ?? resolveDatabaseUrl(`sqlite://.data/${name}.sqlite`),
  port: Number(flags.port ?? process.env.PORT ?? 3000),
  hostname: (flags.bind as string) ?? process.env.BIND ?? undefined,
  workspaceBase: (flags['workspace-base'] as string) ?? process.env.WORKSPACE_BASE ?? undefined,
  localActor: flags['local-actor'] === true || process.env.LOCAL_ACTOR === '1',
  title: (flags.title as string) ?? undefined,
  filesDir: flags.files as string | undefined,
  components: COMPONENT_NAMES,
  componentProps: COMPONENT_PROPS,
  // This runner is how a VENDORED app boots, so a check wired only into the
  // showcase's own entry point does not run for any real deployment. The icon
  // cross-check was that for one release: an app could name an icon nothing
  // could draw and boot clean.
  builtinIcons: BUILTIN_ICON_NAMES,
});

console.log(`blitzpi run ${configDir}`);
console.log(`  listening on ${server.url}`);
console.log(`  models: ${[...models.keys()].join(', ')}`);
console.log(`  tables: ${applied.join(', ')}`);

/**
 * Leave nothing running that this process started.
 *
 * A channel owns a real process; if the server goes and the pty stays, the user has an
 * invisible program holding their files and the port the next launch needs. Three ways
 * out, all ending in the same `shutdown()`:
 *
 *  - a signal (Ctrl-C, or a supervisor stopping us);
 *  - **stdin closing** — the shell-agnostic parent-death signal: a wrapper that spawns
 *    us with a pipe gets this for free, whatever the wrapper is;
 *  - **`--parent-pid`** — for a wrapper that cannot give us a pipe. Neutralino does not
 *    reap its extension processes, so relying on the wrapper is not an option.
 */
let stopping = false;
const stop = (why: string) => {
  if (stopping) return;
  stopping = true;
  console.log(`blitzpi run: stopping (${why})`);
  shutdown();
  process.exit(0);
};

process.on('SIGINT', () => stop('SIGINT'));
process.on('SIGTERM', () => stop('SIGTERM'));

/**
 * Only a PIPE means "a parent is holding this open". Testing `!isTTY` instead treats
 * `> log 2>&1 &` — stdin on /dev/null — as a closed parent, and the server exits the
 * instant it starts. Measured: it did exactly that.
 */
let stdinIsPipe = false;
try { stdinIsPipe = fstatSync(0).isFIFO(); } catch { stdinIsPipe = false; }
if (stdinIsPipe) {
  process.stdin.on('end', () => stop('stdin closed'));
  process.stdin.on('close', () => stop('stdin closed'));
  process.stdin.resume();
}

const parentPid = Number(flags['parent-pid'] ?? process.env.PARENT_PID ?? 0);
if (parentPid > 0) {
  setInterval(() => {
    try { process.kill(parentPid, 0); }
    catch { stop(`parent ${parentPid} is gone`); }
  }, 1000).unref?.();
}
