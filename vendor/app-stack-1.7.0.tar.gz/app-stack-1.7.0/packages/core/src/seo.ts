/**
 * What a crawler and a link preview see (WP-07 S-120).
 *
 * Everything else about a page is decided in the browser: `createAppStack` reads
 * the projection, picks the page and renders it. A crawler may not run any of
 * that, and a link preview certainly will not — so the handful of facts that
 * have to survive without JavaScript are written into the document the server
 * already personalises.
 *
 * **Only from the projection.** These tags are built from the same per-actor
 * page list the document carries, so a page absent for this reader has no title
 * and no description to leak, and the sitemap cannot list a route a visitor may
 * not reach. There is no second source of truth about what exists.
 */
import { addressesOf, languageTags, matchRoute, resolveLocale, type LanguageSet } from './routes.ts';
import type { PageProjection } from './projection.ts';

/** Minimal HTML-text escaping for an attribute or an element's text. */
export const escapeHtml = (value: string): string =>
  value.replace(/[&<>"']/g, (c) => (
    { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!
  ));

/** The projected page this path resolves to, if any. */
export function pageFor(pages: readonly PageProjection[], pathname: string): PageProjection | undefined {
  return pages.find((page) => matchRoute(page.route, pathname) !== undefined);
}

/**
 * `<title>`, `<meta name="description">` and `<link rel="canonical">` for one
 * request, or `''` when the path resolves to no page this reader may see.
 *
 * The canonical is the page's declared ROUTE PATTERN resolved against the
 * requested path — which for a static page is the path itself, and for
 * `/articles/:slug` is the URL actually asked for. It is emitted so that a
 * request carrying tracking parameters, or reached through a redirect, still
 * names one address.
 */
export function seoTags(
  pages: readonly PageProjection[], url: URL, appTitle?: string,
  /**
   * The address the public reaches this app at (`app.yaml`), when it differs
   * from the one the request arrived on. Behind a proxy terminating TLS they
   * always differ: the process sees http, the reader used https, and a
   * canonical naming the former tells a crawler the insecure URL is the
   * authoritative one. Absent falls back to the request, which is right when
   * nothing sits in front.
   */
  publicOrigin?: string,
  /** The app's declared languages, so `/fil/about` resolves to the About page. */
  languages?: LanguageSet,
): string {
  // The canonical below still names the requested path, prefix and all: this
  // address is the Filipino page, not a duplicate of the English one.
  // The path with any language prefix removed: the page this address is about,
  // and the base every language's address is built from. It is the REQUESTED
  // path rather than the route pattern, so `/notes/abc` names `/fil/notes/abc`
  // and not `/fil/notes/:id`.
  const { path: bare } = resolveLocale(url.pathname, languages);
  const page = pageFor(pages, bare);
  if (!page) return '';

  const title = page.title && appTitle && page.title !== appTitle
    ? `${page.title} — ${appTitle}`
    : page.title ?? appTitle;

  const tags: string[] = [];
  if (title) tags.push(`<title>${escapeHtml(title)}</title>`);
  if (page.description) {
    tags.push(`<meta name="description" content="${escapeHtml(page.description)}">`);
  }
  const origin = publicOrigin ?? url.origin;
  // Query and fragment dropped: they are how the same page is reached, not
  // which page it is.
  tags.push(`<link rel="canonical" href="${escapeHtml(`${origin}${url.pathname}`)}">`);

  /**
   * `hreflang`, which is what stops two languages of a page competing as
   * duplicates. Each version names **every** version including itself — a
   * crawler that reaches only the Filipino page has to be able to find the
   * English one from it — and `x-default` names the default language, which is
   * where a reader whose own language the site does not publish should land.
   */
  if (languages) {
    const addresses = addressesOf(bare, languages);
    const tagFor = languageTags(languages);
    addresses.forEach((path, i) => {
      tags.push(`<link rel="alternate" hreflang="${escapeHtml(tagFor[i]!)}" href="${escapeHtml(`${origin}${path}`)}">`);
    });
    tags.push(`<link rel="alternate" hreflang="x-default" href="${escapeHtml(`${origin}${addresses[0]}`)}">`);
  }
  return tags.join('');
}

/**
 * The sitemap, from the pages a VISITOR is projected.
 *
 * Deliberately built for the anonymous actor rather than for whoever asked:
 * a sitemap is a public document, and one generated per reader would either
 * disclose an administrator's page set to a crawler or vary per request in a
 * way no crawler expects.
 *
 * Parameterised routes are omitted. `/articles/:slug` is a shape, not an
 * address, and enumerating its rows means reading them — which is a policy
 * decision per model, not something a sitemap should assume.
 */
export function sitemapXml(
  visitorPages: readonly PageProjection[],
  origin: string,
  /**
   * The app's declared languages. Each page is then listed **once per
   * language**, because each language of a page is its own address and a
   * crawler cannot discover an address nothing links to from outside.
   */
  languages?: LanguageSet,
): string {
  const routes = visitorPages
    .map((page) => page.route)
    .filter((route) => !route.includes(':'))
    .sort();

  const urls = routes
    .flatMap((route) => addressesOf(route, languages))
    .map((path) => `  <url><loc>${escapeHtml(`${origin}${path}`)}</loc></url>`)
    .join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls}\n</urlset>\n`;
}

/**
 * `robots.txt`, naming the sitemap.
 *
 * Nothing is disallowed here: what a visitor may not reach is already absent
 * from their projection and refused by the server, and a `Disallow` list is a
 * map of interesting paths handed to whoever asks for it.
 */
export const robotsTxt = (origin: string): string =>
  `User-agent: *\nAllow: /\nSitemap: ${origin}/sitemap.xml\n`;
