/**
 * `app.yaml` — what the application is, as opposed to what it contains.
 *
 * One document, no directory, like `theme.yaml` and `icons.yaml`. A missing
 * file is not an error: everything here has a defensible default taken from the
 * request.
 *
 * It exists because **the request cannot answer every question about the app.**
 * Behind a proxy that terminates TLS, an https site receives http requests, so
 * `url.origin` names an address that is real for the process and wrong for the
 * public — and a canonical or a sitemap built from it tells a crawler the
 * insecure URL is the authoritative one. That is not hypothetical: it was live
 * on a deployed site, which carried this very file declaring the right answer
 * while nothing read it.
 */
import { ConfigError } from './model.ts';
import { assertNoYamlTraps } from './config/yaml-traps.ts';

export interface AppConfigDoc {
  /**
   * The address the public reaches this app at, without a trailing slash —
   * `https://example.com`. Used for the canonical link, the sitemap and the
   * `Sitemap:` line in robots.txt. Absent: each is built from the request.
   */
  publicOrigin?: string;
  /** The languages this app publishes in. Absent: the app is single-language. */
  languages?: Languages;
}

/**
 * Which languages exist, and which one is the default.
 *
 * The default is load-bearing twice over: it is the language whose pages keep
 * **bare paths** (`/about`, while the others are prefixed `/fil/about`), so
 * adding a language to a live site changes no existing URL; and it is the
 * **fallback**, so a string missing from another language renders in this one.
 * Those are the same choice, which is why it is one field rather than two.
 */
export interface Languages {
  /** Bare paths, and the fallback for every missing string. */
  default: string;
  /** Path-prefixed, and allowed to be incomplete. At least one. */
  alternates: string[];
  /**
   * How each language names ITSELF — `fil: Filipino`, not `fil: Filipino (in
   * English)`. What a picker draws.
   *
   * Not in `locales/`, deliberately: a language's own name reads the same
   * whichever language you are reading, which is why every multilingual site on
   * the web writes "Deutsch" and not "German". Putting it in the catalogue would
   * invite translating it and produce a picker a reader cannot use to escape a
   * language they do not speak.
   *
   * Absent for a language: its tag, uppercased.
   */
  labels?: Record<string, string>;
}

const ORIGIN = /^https?:\/\/[^/?#\s]+$/;
/** A language subtag, optionally refined — `en`, `fil`, `pt-BR`, `zh-Hant`. */
const TAG = /^[a-z]{2,3}(-[A-Za-z0-9]{2,8})*$/;

function compileLanguages(raw: unknown, source: string): Languages {
  if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) {
    throw new ConfigError(source, 'languages must be a mapping with "default" and "alternates"');
  }
  const doc = raw as Record<string, unknown>;
  const known = ['default', 'alternates', 'labels'];
  const extra = Object.keys(doc).filter((k) => !known.includes(k));
  if (extra.length) {
    throw new ConfigError(source,
      `unknown key(s) ${extra.join(', ')} under languages — known: ${known.join(', ')}`);
  }

  const fallback = doc.default;
  if (typeof fallback !== 'string' || !TAG.test(fallback)) {
    throw new ConfigError(source,
      `languages.default must be a language tag — "en", "fil", "pt-BR" — not ${JSON.stringify(fallback)}`);
  }

  const alternates = doc.alternates;
  if (!Array.isArray(alternates) || alternates.length === 0) {
    throw new ConfigError(source,
      'languages.alternates must list at least one language — remove the whole "languages" block for a single-language app');
  }
  const seen = new Set<string>([fallback]);
  for (const tag of alternates) {
    if (typeof tag !== 'string' || !TAG.test(tag)) {
      throw new ConfigError(source,
        `languages.alternates must be language tags — "fil", "pt-BR" — not ${JSON.stringify(tag)}`);
    }
    if (seen.has(tag)) {
      throw new ConfigError(source,
        `"${tag}" is listed twice under languages${tag === fallback ? ' — it is already the default, which is not an alternate' : ''}`);
    }
    seen.add(tag);
  }
  const labels = compileLabels(doc.labels, [...seen], source);
  return { default: fallback, alternates: alternates as string[], ...(labels ? { labels } : {}) };
}

/** `labels` names languages the app declares, and each name is a string. */
function compileLabels(
  raw: unknown, declared: string[], source: string,
): Record<string, string> | undefined {
  if (raw === undefined) return undefined;
  if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) {
    throw new ConfigError(source, 'languages.labels is a mapping of language tag to its own name');
  }
  const out: Record<string, string> = {};
  for (const [tag, name] of Object.entries(raw as Record<string, unknown>)) {
    if (!declared.includes(tag)) {
      throw new ConfigError(source,
        `languages.labels names "${tag}", which this app does not publish in — declared: ${declared.join(', ')}`);
    }
    if (typeof name !== 'string' || name.length === 0) {
      throw new ConfigError(source, `languages.labels.${tag} must be the language's own name, as a string`);
    }
    out[tag] = name;
  }
  return out;
}

/** Every language the app publishes in, the default first. */
export const allLanguages = (doc: AppConfigDoc): string[] =>
  doc.languages ? [doc.languages.default, ...doc.languages.alternates] : [];

export function compileAppConfig(raw: unknown, source: string): AppConfigDoc {
  if (raw === null || raw === undefined) return {};
  if (typeof raw !== 'object' || Array.isArray(raw)) {
    throw new ConfigError(source, 'app.yaml must be a mapping');
  }
  const doc = raw as Record<string, unknown>;
  const known = ['publicOrigin', 'languages'];
  const extra = Object.keys(doc).filter((k) => !known.includes(k));
  if (extra.length) {
    throw new ConfigError(source, `unknown key(s) ${extra.join(', ')} — known: ${known.join(', ')}`);
  }

  const out: AppConfigDoc = {};

  const origin = doc.publicOrigin;
  if (origin !== undefined) {
    if (typeof origin !== 'string' || !ORIGIN.test(origin)) {
      throw new ConfigError(source,
        `publicOrigin must be a scheme and host with no path — "https://example.com", not ${JSON.stringify(origin)}`);
    }
    out.publicOrigin = origin;
  }

  if (doc.languages !== undefined) out.languages = compileLanguages(doc.languages, source);

  return out;
}

/** Loads `<configDir>/app.yaml`. A missing file leaves every value to the request. */
export async function loadAppConfig(configDir: string): Promise<AppConfigDoc> {
  const file = Bun.file(`${configDir}/app.yaml`);
  if (!(await file.exists())) return {};
  const text = await file.text();
  assertNoYamlTraps(text, 'app.yaml');
  return compileAppConfig(Bun.YAML.parse(text), 'app.yaml');
}
