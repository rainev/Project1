/**
 * Three gates, deny by default (ARCHITECTURE §11).
 *
 * Expressions are JEXL, compiled to an AST once at boot and evaluated per
 * request against a frozen, plain-data projection — no functions, no tx, no
 * call. An expression can read what it needs and cannot do anything.
 */
import { compileExpression, type Compiled } from './expressions.ts';
import type { Actor } from './engine/types.ts';
import type { Model } from './model.ts';

export interface GateView {
  actor: { id: string; roles: string[]; orgId: string };
  op: string;
  model: { name: string };
  input: Record<string, unknown>;
  row?: Record<string, unknown>;
  now: string;
}

export interface CompiledGates {
  access: Record<string, Compiled>;
  scope: Record<string, Compiled>;
  fieldAccess: Record<string, { read?: Compiled; write?: Compiled }>;
  /**
   * A transition's own `access`, keyed by the transition name (W-101). It
   * composes with `x-access.write` — both, never either — for the reason a
   * view's `x-access` composes with `requires`: a move narrows who may write
   * this model, and must never be a way to widen it.
   */
  transitions: Record<string, Compiled>;
}

const compiledByModel = new WeakMap<Model, CompiledGates>();

/** Compile at boot so a broken expression fails startup, not a request. */
export function compileGates(model: Model): CompiledGates {
  const compile = (expression: string, where: string): Compiled =>
    compileExpression(expression, `${model.name}.${where}`);

  const gates: CompiledGates = { access: {}, scope: {}, fieldAccess: {}, transitions: {} };
  for (const [name, transition] of Object.entries(model.states?.transitions ?? {})) {
    if (!transition.access) continue;
    gates.transitions[name] = compile(transition.access, `x-states.transitions.${name}.access`);
  }
  for (const [perm, expr] of Object.entries(model.access)) {
    gates.access[perm] = compile(expr, `x-access.${perm}`);
  }
  for (const [col, expr] of Object.entries(model.scope)) {
    gates.scope[col] = compile(expr, `x-scope.${col}`);
  }
  for (const [field, policy] of Object.entries(model.fieldAccess)) {
    gates.fieldAccess[field] = {
      read: policy.read ? compile(policy.read, `x-field-access.${field}.read`) : undefined,
      write: policy.write ? compile(policy.write, `x-field-access.${field}.write`) : undefined,
    };
  }
  compiledByModel.set(model, gates);
  return gates;
}

function gatesFor(model: Model): CompiledGates {
  return compiledByModel.get(model) ?? compileGates(model);
}

export function makeView(actor: Actor, op: string, model: Model, input: Record<string, unknown>, row?: Record<string, unknown>): GateView {
  return Object.freeze({
    actor: Object.freeze({ id: actor.id, roles: Object.freeze([...actor.roles]) as string[], orgId: actor.orgId }),
    op,
    model: Object.freeze({ name: model.name }),
    input: Object.freeze({ ...input }),
    row: row ? Object.freeze({ ...row }) : undefined,
    now: new Date().toISOString(),
  }) as GateView;
}

/** Operations that read. One definition, shared by the intake and the gates (AUD-046). */
export const READ_OPS = new Set(['get', 'list', 'count', 'aggregate', 'schema', 'query', 'history']);
export const permissionFor = (op: string) => (READ_OPS.has(op) ? 'read' : 'write');

/**
 * Deny by default: a missing or non-true expression refuses.
 *
 * A declared transition is a write like every other custom action, so
 * `x-access.write` decides first. Its own `access`, if it declared one, is then
 * required AS WELL — never instead — so the lifecycle can say "only an admin
 * reopens a closed note" without becoming a second way to grant write.
 */
export function allowsAction(model: Model, view: GateView): boolean {
  const gates = gatesFor(model);
  const expression = gates.access[permissionFor(view.op)];
  if (!expression) return false;
  try {
    if (expression.evalSync(view) !== true) return false;
    const transition = gates.transitions[view.op];
    return transition ? transition.evalSync(view) === true : true;
  } catch {
    return false;
  }
}

/**
 * Scope expressions evaluate to VALUES, bound into the query — never predicates.
 * A post-fetch filter would break pagination and leak through aggregates.
 */
export function resolveScope(model: Model, view: GateView): Record<string, unknown> {
  const scope: Record<string, unknown> = {};
  for (const [column, expression] of Object.entries(gatesFor(model).scope)) {
    const value = expression.evalSync(view);
    if (value !== null && value !== undefined) scope[column] = value;
  }
  return scope;
}

/**
 * Inbound: drop fields this actor may not write, before hooks and persistence.
 *
 * A refused field is reported two ways, and the model says which (WP-02 H-120,
 * AUD-059). By default it is `denied`: dropped, the rest of the write proceeds,
 * and the caller is told in `meta.denied` rather than left to infer it from a
 * 201 and a missing value. `x-field-access.<f>.onDenied: reject` puts it in
 * `rejected` instead, and the engine turns that into a 422 — for a field where
 * silently continuing would be worse than failing.
 */
export function filterWrite(model: Model, view: GateView, input: Record<string, unknown>) {
  const gates = gatesFor(model);
  const allowed: Record<string, unknown> = {};
  const denied: string[] = [];
  const rejected: string[] = [];
  for (const [key, value] of Object.entries(input)) {
    const policy = gates.fieldAccess[key]?.write;
    if (policy && policy.evalSync(view) !== true) {
      (model.fieldAccess[key]?.onDenied === 'reject' ? rejected : denied).push(key);
      continue;
    }
    allowed[key] = value;
  }
  return { allowed, denied, rejected };
}

/** Per-field predicates, used to project derived schemas for this actor. */
/**
 * A field the app declared `x-internal`. Checked before policy everywhere,
 * because policy is an expression the app owns and this is not: a password
 * hash stays unreadable whatever `x-field-access` says about it.
 */
export const isInternal = (model: Model, field: string): boolean =>
  model.props[field]?.internal === true;

export function canRead(model: Model, view: GateView, field: string): boolean {
  if (isInternal(model, field)) return false;
  const policy = gatesFor(model).fieldAccess[field]?.read;
  return policy ? policy.evalSync(view) === true : true;
}

export function canWrite(model: Model, view: GateView, field: string): boolean {
  if (isInternal(model, field)) return false;
  const policy = gatesFor(model).fieldAccess[field]?.write;
  return policy ? policy.evalSync(view) === true : true;
}

/** Outbound: remove fields this actor may not read. Separate from write policy. */
export function projectRead<T extends Record<string, unknown>>(model: Model, view: GateView, row: T): T {
  const gates = gatesFor(model);
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(row)) {
    if (isInternal(model, key)) continue;
    const policy = gates.fieldAccess[key]?.read;
    if (policy && policy.evalSync(view) !== true) continue;
    out[key] = value;
  }
  return out as T;
}
