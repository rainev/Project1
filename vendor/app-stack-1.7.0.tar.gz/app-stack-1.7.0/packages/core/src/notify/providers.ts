/**
 * Notification providers, declared (ARCHITECTURE §10; WP-06 W-120).
 *
 * A provider is somewhere a message can be sent: an HTTP endpoint, an SMTP
 * relay. It is named in configuration and referred to by name from an event
 * listener, so "what happens when a note is reopened" and "where operations
 * receive it" are separate decisions made in separate places — which is the
 * whole reason to have providers at all rather than a URL inline in a handler.
 *
 * **Not a config family.** One document, no directory, no cross-referencing
 * between documents — the same call `theme.yaml` made, for the same reason: a
 * family is for things there are many of, and a fourth family is the breadth
 * CLAUDE.md's failure list names.
 *
 * ## `secretRef` gets its first consumer
 *
 * §10 reserved `secretRef` as the spelling for "this config field NAMES a
 * secret", and until now nothing consumed it. A provider is what needed it: a
 * webhook signing key and an SMTP password are exactly the material the
 * literal-secret guard already refuses to let an author paste into YAML. So the
 * config carries the NAME of an environment variable and the framework resolves
 * it through the one seam (`secret()`), at boot, with the same `_FILE`
 * convention and the same errors as every other secret.
 *
 * The value never reaches the projection, never reaches an expression, and
 * never appears in an error message — a provider that cannot resolve its secret
 * reports its own name and the variable it wanted, never what it read.
 */
import { ajv, ConfigError, formatSchemaErrors } from '../config/loader.ts';
import { assertNoLiteralSecrets, secret, SecretError } from '../secrets.ts';
import { assertNoYamlTraps } from '../config/yaml-traps.ts';

const NAME = '^[A-Za-z_][A-Za-z0-9_-]*$';
/** An environment variable name, which is what `secretRef` holds. */
const ENV_NAME = '^[A-Z][A-Z0-9_]*$';

const META_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  required: ['providers'],
  properties: {
    $schema: { type: 'string' },
    title: { type: 'string' },
    providers: {
      type: 'object',
      minProperties: 1,
      propertyNames: { pattern: NAME },
      additionalProperties: {
        type: 'object',
        required: ['type'],
        additionalProperties: false,
        properties: {
          type: { enum: ['webhook', 'email'] },
          /** webhook: where to POST. */
          url: { type: 'string', pattern: '^https?://' },
          /** webhook: how long to wait before the attempt counts as failed. */
          timeoutMs: { type: 'integer', minimum: 100, maximum: 60000 },
          /** email: the relay. */
          host: { type: 'string', minLength: 1 },
          port: { type: 'integer', minimum: 1, maximum: 65535 },
          /** email: implicit TLS on connect (port 465). */
          tls: { type: 'boolean' },
          user: { type: 'string', minLength: 1 },
          from: { type: 'string', minLength: 3 },
          to: { type: 'array', minItems: 1, items: { type: 'string', minLength: 3 } },
          /**
           * The NAME of the environment variable holding this provider's
           * secret — a webhook signing key, an SMTP password. Never the secret.
           */
          secretRef: { type: 'string', pattern: ENV_NAME },
        },
      },
    },
  },
} as const;

const validate = ajv.compile(META_SCHEMA);

export interface WebhookProvider {
  name: string;
  type: 'webhook';
  url: string;
  timeoutMs: number;
  /** Resolved at boot from `secretRef`. Signs the body; absent means unsigned. */
  secret?: string;
  secretRef?: string;
}

export interface EmailProvider {
  name: string;
  type: 'email';
  host: string;
  port: number;
  tls: boolean;
  user?: string;
  from: string;
  to: string[];
  secret?: string;
  secretRef?: string;
}

export type Provider = WebhookProvider | EmailProvider;

/**
 * Values a provider reads from the environment (`{ env: NAME }`).
 *
 * A provider is the one place config describes DEPLOYMENT rather than the
 * application: an SMTP host, a port, the account to authenticate as, the
 * address operations watch, the URL a webhook posts to. Every other config
 * family describes what the app IS, which is the same on every deployment —
 * checked 2026-09-24, and they carry no environment-specific value at all. So
 * this seam lives here rather than in the shared loader: it is built where the
 * need was measured, and generalising it later is a smaller change than
 * un-generalising it.
 *
 * `secretRef` already covers credentials. This covers what sits beside them —
 * the values that are environment-specific WITHOUT being secret, which had
 * nowhere to go and so stayed literal in YAML (`user: app-stack`).
 *
 *     host: { env: SMTP_HOST }
 *     port: { env: SMTP_PORT, default: 2525 }
 *
 * **An unset variable with no default refuses the boot**, naming the variable
 * and where it was named. The alternative is trading a hardcoded value for a
 * silent empty one, which is worse: a mailer with no host fails at the first
 * send, to nobody, long after the deploy that caused it.
 *
 * `default` exists so a checkout boots without six variables set. **A default
 * is for local convenience and must never be a credential** — the literal
 * secret guard runs over this document first, so it cannot be key material,
 * and the rule in `docs/stack/09-secrets.md` is what covers the rest.
 *
 * Resolution happens BEFORE the meta-schema validates, so the schema sees the
 * resolved document and needs no knowledge of this form at all.
 */
const ENV_REF = /^[A-Z][A-Z0-9_]*$/;

/** Keys whose declared type is not a string, so an environment value is converted. */
const COERCE: Record<string, 'integer' | 'boolean'> = {
  port: 'integer', timeoutMs: 'integer', tls: 'boolean',
};

function coerce(raw: string, key: string, where: string, source: string): unknown {
  const want = COERCE[key];
  if (!want) return raw;
  if (want === 'integer') {
    if (!/^-?\d+$/.test(raw)) {
      throw new ConfigError(source, `${where} read "${raw}" from the environment, which is not a whole number`);
    }
    return Number(raw);
  }
  if (raw !== 'true' && raw !== 'false') {
    throw new ConfigError(source, `${where} read "${raw}" from the environment, which is not true or false`);
  }
  return raw === 'true';
}

/** Replace every `{ env: NAME }` with what the environment holds. */
function resolveEnvRefs(node: unknown, source: string, where = '', key = ''): unknown {
  if (Array.isArray(node)) {
    return node.map((item, i) => resolveEnvRefs(item, source, `${where}[${i}]`, key));
  }
  if (!node || typeof node !== 'object') return node;

  const entries = Object.entries(node as Record<string, unknown>);
  const named = entries.find(([k]) => k === 'env');
  if (named) {
    const extra = entries.filter(([k]) => k !== 'env' && k !== 'default').map(([k]) => k);
    if (extra.length) {
      throw new ConfigError(source, `${where} names an environment variable, so it may carry only \`env\` and \`default\` — not ${extra.join(', ')}`);
    }
    const name = named[1];
    if (typeof name !== 'string' || !ENV_REF.test(name)) {
      throw new ConfigError(source, `${where}.env must be an environment variable name — capitals, digits and underscores, starting with a letter`);
    }
    const fallback = (node as Record<string, unknown>).default;
    const raw = process.env[name];
    if (raw === undefined || raw === '') {
      if (fallback !== undefined) return fallback;
      throw new ConfigError(source, `${where} reads ${name} from the environment, which is not set (set ${name}, or give this field a \`default\`)`);
    }
    return coerce(raw, key, where, source);
  }

  return Object.fromEntries(
    entries.map(([k, v]) => [k, resolveEnvRefs(v, source, where ? `${where}.${k}` : k, k)]),
  );
}

const DEFAULT_TIMEOUT_MS = 5000;

/**
 * Resolve one provider's secret.
 *
 * Outside production a missing one warns and leaves the provider unsigned or
 * unauthenticated, exactly as a missing `JWT_SECRET` boots on an ephemeral
 * value with a warning that says what it costs. Production refuses, because a
 * webhook that quietly stops being signed is worse than one that does not send:
 * the receiver cannot tell "unsigned" from "forged" unless somebody decided in
 * advance that it would always be signed.
 */
function resolveSecret(name: string, ref: string | undefined, source: string): string | undefined {
  if (!ref) return undefined;
  try {
    return secret(ref);
  } catch (error) {
    if (!(error instanceof SecretError)) throw error;
    if (process.env.NODE_ENV === 'production') {
      throw new ConfigError(source, `provider "${name}" names secretRef ${ref}, which is not set: ${error.message}`);
    }
    console.warn(
      `WARNING: notification provider "${name}" names secretRef ${ref}, which is not set. ` +
      'It will send unsigned and unauthenticated. Production refuses to boot without it.',
    );
    return undefined;
  }
}

export function compileProviders(doc: unknown, source: string): Map<string, Provider> {
  // The guard runs on what was WRITTEN, before anything is resolved: a secret
  // pasted into the file is the thing it exists to catch, and a value that
  // arrived from the environment is not that.
  assertNoLiteralSecrets(doc, source);
  const resolvedDoc = resolveEnvRefs(doc, source);
  if (!validate(resolvedDoc)) throw new ConfigError(source, formatSchemaErrors(validate.errors));

  const raw = resolvedDoc as { providers: Record<string, any> };
  const providers = new Map<string, Provider>();

  for (const [name, def] of Object.entries(raw.providers)) {
    const resolved = resolveSecret(name, def.secretRef, source);

    if (def.type === 'webhook') {
      if (!def.url) throw new ConfigError(source, `provider "${name}" is a webhook and needs a url`);
      for (const key of ['host', 'port', 'tls', 'user', 'from', 'to']) {
        if (def[key] !== undefined) {
          throw new ConfigError(source, `provider "${name}" is a webhook, so "${key}" means nothing to it`);
        }
      }
      providers.set(name, {
        name, type: 'webhook', url: def.url,
        timeoutMs: def.timeoutMs ?? DEFAULT_TIMEOUT_MS,
        secret: resolved, secretRef: def.secretRef,
      });
      continue;
    }

    for (const key of ['host', 'from', 'to'] as const) {
      if (def[key] === undefined) {
        throw new ConfigError(source, `provider "${name}" is an email provider and needs "${key}"`);
      }
    }
    if (def.url !== undefined) {
      throw new ConfigError(source, `provider "${name}" is an email provider, so "url" means nothing to it`);
    }
    if (def.timeoutMs !== undefined) {
      throw new ConfigError(source, `provider "${name}" is an email provider, so "timeoutMs" means nothing to it`);
    }
    providers.set(name, {
      name, type: 'email', host: def.host,
      port: def.port ?? (def.tls === true ? 465 : 25),
      tls: def.tls === true,
      user: def.user, from: def.from, to: [...def.to],
      secret: resolved, secretRef: def.secretRef,
    });
  }

  return providers;
}

/**
 * Load `config/notifications.yaml`, if the app declares one.
 *
 * An app that sends nothing has no file, which is not an error — the same
 * stance the loader takes to a missing `queries/` directory.
 */
export async function loadProviders(configDir: string): Promise<Map<string, Provider>> {
  const file = Bun.file(`${configDir}/notifications.yaml`);
  if (!(await file.exists())) return new Map();
  const text = await file.text();
  assertNoYamlTraps(text, 'notifications.yaml');
  return compileProviders(Bun.YAML.parse(text), 'notifications.yaml');
}
