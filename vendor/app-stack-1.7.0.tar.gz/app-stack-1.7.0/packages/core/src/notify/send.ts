/**
 * Sending, per provider type (WP-06 W-120).
 *
 * Both senders are deliberately thin and deliberately **throwing**: a send that
 * fails throws, the outbox counts the attempt, backs off and tries again. That
 * is the whole reason notifications hang off events rather than off the request
 * — a webhook receiver being down is not a reason to fail somebody's write, and
 * a retry is not something each provider should reinvent.
 *
 * Nothing here logs a secret, a body, or a recipient list on failure. The error
 * names the provider and what the far end said.
 */
import { createHmac } from 'node:crypto';
import { connect as netConnect, type Socket } from 'node:net';
import { connect as tlsConnect } from 'node:tls';
import type { EmailProvider, Provider, WebhookProvider } from './providers.ts';

/** What a listener asked to send. Ids and names, like the outbox row it came from. */
export interface Message {
  /** The event that caused it — `note.restart`. */
  event: string;
  model: string;
  rowId?: string;
  /** Whatever the declaration's `data` evaluated to. */
  data: Record<string, unknown>;
  at: string;
  /**
   * Recipients the DECLARATION named, overriding the provider's `to` for this
   * message only (S-111, AUD-067).
   *
   * Absent means the declaration named none, and the provider's `to` — the
   * operator's address, fixed in `notifications.yaml` at boot — remains the
   * default. That is why this is an override and not a replacement: an operator
   * webhook or an operator mailbox declared beside a per-participant one is
   * unchanged by this field existing.
   */
  to?: string[];
  /** A declared subject line. Absent falls back to the event name. */
  subject?: string;
  /** A declared plain-text body. Absent falls back to the data as JSON. */
  text?: string;
  /** A declared HTML body, sent as the richer half of a multipart/alternative. */
  html?: string;
}

export const SIGNATURE_HEADER = 'x-appstack-signature';
export const EVENT_HEADER = 'x-appstack-event';

/**
 * The signature a receiver checks: `sha256=<hex>` over the exact bytes sent.
 *
 * Over the BODY and not over a reconstruction of it, because a receiver that
 * has to rebuild the string to verify is a receiver that will eventually
 * rebuild it differently. Exported so a test — and the gate's own receiver —
 * verifies with the same function the sender used.
 */
export function sign(secret: string, body: string): string {
  return `sha256=${createHmac('sha256', secret).update(body).digest('hex')}`;
}

async function sendWebhook(provider: WebhookProvider, message: Message): Promise<void> {
  const body = JSON.stringify(message);
  const headers: Record<string, string> = {
    'content-type': 'application/json',
    [EVENT_HEADER]: message.event,
  };
  // Unsigned when no secret resolved: outside production that is a warning at
  // boot, not a silent downgrade here (`providers.ts`).
  if (provider.secret) headers[SIGNATURE_HEADER] = sign(provider.secret, body);

  let response: Response;
  try {
    response = await fetch(provider.url, {
      method: 'POST', headers, body,
      signal: AbortSignal.timeout(provider.timeoutMs),
    });
  } catch (error) {
    // A DNS failure, a refused connection, a timeout. The URL is configuration,
    // so naming it helps an operator and tells a caller nothing they set.
    throw new Error(`provider "${provider.name}" could not reach ${provider.url}: ${(error as Error).message}`);
  }
  if (!response.ok) {
    throw new Error(`provider "${provider.name}" was refused by ${provider.url}: HTTP ${response.status}`);
  }
}

// ---------------------------------------------------------------------------
// SMTP
// ---------------------------------------------------------------------------

/**
 * A line-oriented conversation with an SMTP relay.
 *
 * Written here rather than pulled in because the surface actually used is
 * small — EHLO, optional AUTH LOGIN, MAIL, RCPT, DATA, QUIT — and a dependency
 * that speaks the whole protocol would be a much larger thing to argue for
 * (§21). What it does NOT do is in `09-secrets.md` and in the handoff: no
 * STARTTLS upgrade, so a relay that requires it on port 587 is not reachable;
 * `tls: true` connects with implicit TLS (port 465), which is.
 */
class SmtpSession {
  #socket: Socket;
  #buffer = '';
  #pending: ((line: string) => void)[] = [];
  #lines: string[] = [];
  #failure?: Error;

  constructor(socket: Socket) {
    this.#socket = socket;
    socket.setEncoding('utf8');
    socket.on('data', (chunk: string) => {
      this.#buffer += chunk;
      let index = this.#buffer.indexOf('\r\n');
      while (index !== -1) {
        this.#deliver(this.#buffer.slice(0, index));
        this.#buffer = this.#buffer.slice(index + 2);
        index = this.#buffer.indexOf('\r\n');
      }
    });
    socket.on('error', (error: Error) => this.#fail(error));
    socket.on('close', () => this.#fail(new Error('the relay closed the connection')));
  }

  #deliver(line: string) {
    const waiting = this.#pending.shift();
    if (waiting) waiting(line);
    else this.#lines.push(line);
  }

  #fail(error: Error) {
    this.#failure = error;
    for (const waiting of this.#pending.splice(0)) waiting(`000 ${error.message}`);
  }

  /** One reply line. A multi-line reply is `250-…` until `250 …`. */
  #line(timeoutMs: number): Promise<string> {
    const ready = this.#lines.shift();
    if (ready !== undefined) return Promise.resolve(ready);
    if (this.#failure) return Promise.resolve(`000 ${this.#failure.message}`);
    return new Promise((resolve) => {
      const timer = setTimeout(() => resolve('000 timed out waiting for the relay'), timeoutMs);
      this.#pending.push((line) => { clearTimeout(timer); resolve(line); });
    });
  }

  /**
   * Send a command (or nothing) and read to the end of the reply.
   *
   * `label` is what an error may say the command was. It exists because the two
   * base64 lines of AUTH LOGIN are the username and the PASSWORD, and a failed
   * login would otherwise put the password in an error message and from there
   * into `_outbox.lastError` and an audit row. Caught by
   * `packages/core/test/notify.test.ts`, which asserts the message does not
   * contain the credential it just sent.
   */
  async say(command: string | undefined, expect: number, label?: string, timeoutMs = 10_000): Promise<string[]> {
    if (command !== undefined) this.#socket.write(`${command}\r\n`);
    const reply: string[] = [];
    for (;;) {
      const line = await this.#line(timeoutMs);
      reply.push(line);
      // `250-EXTENSION` continues; `250 OK` ends.
      if (line.length < 4 || line[3] !== '-') break;
    }
    const code = Number(reply[reply.length - 1]!.slice(0, 3));
    if (code !== expect) {
      throw new Error(`the relay answered "${reply.join(' / ')}" to ${label ?? command ?? '<greeting>'}`);
    }
    return reply;
  }

  end() { this.#socket.end(); }
}

/**
 * Who this message is actually for.
 *
 * The declaration's recipients when it named any, the provider's otherwise.
 * One function because MAIL/RCPT and the `To:` header must never disagree —
 * two readings of "who is this for" is how a message reaches an address the
 * envelope does not name.
 */
const recipientsOf = (provider: EmailProvider, message: Message): string[] =>
  (message.to?.length ? message.to : provider.to);

/**
 * A header value a row supplied cannot inject headers of its own.
 *
 * `run.ts` already refuses a line break in an address, and this is the second
 * half of the same rule at the boundary that would actually be exploited: every
 * value that becomes a header passes through here, whoever assembled it. CR and
 * LF are refused rather than stripped, because silently sending a subject other
 * than the one declared is its own defect.
 */
function headerSafe(value: string, what: string): string {
  if (/[\r\n]/.test(value)) throw new Error(`${what} may not contain a line break`);
  return value;
}

/** A boundary that cannot occur in either part, so neither can end the message early. */
const boundaryFor = (): string => `----appstack-${crypto.randomUUID()}`;

function rfc2822(provider: EmailProvider, message: Message): string {
  const subject = headerSafe(
    message.subject ?? `${message.event}${message.rowId ? ` (${message.rowId})` : ''}`,
    'a subject',
  );
  const text = message.text ?? JSON.stringify(message.data, null, 2);
  const headers = [
    `From: ${headerSafe(provider.from, 'a From address')}`,
    `To: ${recipientsOf(provider, message).map((r) => headerSafe(r, 'a recipient')).join(', ')}`,
    `Subject: ${subject}`,
    `Date: ${new Date(message.at).toUTCString()}`,
    'MIME-Version: 1.0',
  ];

  // No HTML declared: the message stays exactly the shape it was before WP-11,
  // so an existing email provider sends an identical message.
  if (message.html === undefined) {
    return [...headers, 'Content-Type: text/plain; charset=utf-8', '', text].join('\r\n');
  }

  // Both halves, so a reader that cannot render HTML still gets the words —
  // `alternative` is the part that says they are the same message, not two.
  const boundary = boundaryFor();
  return [
    ...headers,
    `Content-Type: multipart/alternative; boundary="${boundary}"`,
    '',
    `--${boundary}`,
    'Content-Type: text/plain; charset=utf-8',
    '',
    text,
    `--${boundary}`,
    'Content-Type: text/html; charset=utf-8',
    '',
    message.html,
    `--${boundary}--`,
  ].join('\r\n');
}

async function sendEmail(provider: EmailProvider, message: Message): Promise<void> {
  const socket = provider.tls
    ? tlsConnect({ host: provider.host, port: provider.port, servername: provider.host })
    : netConnect({ host: provider.host, port: provider.port });

  const session = new SmtpSession(socket as Socket);
  try {
    await session.say(undefined, 220);            // the greeting
    await session.say(`EHLO ${provider.from.split('@')[1] ?? 'localhost'}`, 250);

    if (provider.user && provider.secret) {
      await session.say('AUTH LOGIN', 334, 'AUTH LOGIN');
      await session.say(Buffer.from(provider.user).toString('base64'), 334, 'AUTH LOGIN (username)');
      await session.say(Buffer.from(provider.secret).toString('base64'), 235, 'AUTH LOGIN (password)');
    }

    await session.say(`MAIL FROM:<${provider.from}>`, 250);
    // The declaration's recipients when it named any — the same list the `To:`
    // header is built from, so the envelope and the header always agree.
    for (const recipient of recipientsOf(provider, message)) {
      await session.say(`RCPT TO:<${headerSafe(recipient, 'a recipient')}>`, 250);
    }
    await session.say('DATA', 354);

    // The body, then the lone dot that ends it. A line that IS a dot would end
    // it early, so it is escaped the way the protocol says (RFC 5321 §4.5.2).
    const payload = rfc2822(provider, message)
      .split('\r\n').map((line) => (line.startsWith('.') ? `.${line}` : line)).join('\r\n');
    // The body is the payload, so it is never echoed into an error either.
    await session.say(`${payload}\r\n.`, 250, 'the message body');
    await session.say('QUIT', 221, 'QUIT').catch(() => {});
  } catch (error) {
    throw new Error(`provider "${provider.name}" could not send through ${provider.host}:${provider.port}: ${(error as Error).message}`);
  } finally {
    session.end();
  }
}

/** Send one message through one provider. Throws, so the outbox retries. */
export function send(provider: Provider, message: Message): Promise<void> {
  return provider.type === 'webhook' ? sendWebhook(provider, message) : sendEmail(provider, message);
}
