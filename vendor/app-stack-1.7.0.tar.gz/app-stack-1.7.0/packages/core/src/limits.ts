/**
 * Paging and export limits, read from the environment once at boot.
 *
 * These are **operational** knobs, not secrets and not app config: how much a
 * deployment is willing to serve depends on its database and its hardware, not
 * on the model. So they resolve through the environment like `PLATFORM_ADMINS`
 * does, rather than through a config family (nothing would parse) or `secret()`
 * (nothing here is confidential).
 *
 * What they do NOT change is decision 40: paging stays server-side, the server
 * still mints every cursor, and a request is still clamped into `[1, max]` with
 * a default when it names no limit. The environment moves the ceiling; it never
 * hands the ceiling to the caller.
 *
 * Read once, at module load, so a boot fails on a bad value rather than a
 * request — the same posture as the gates and the model compiler. A value that
 * is not a positive integer is a deployment mistake, so it throws and names the
 * variable instead of silently falling back to the default and serving a
 * different page size than the operator asked for.
 */

function positiveInt(name: string, fallback: number): number {
  const raw = process.env[name];
  if (raw === undefined || raw.trim() === '') return fallback;
  const value = Number(raw.trim());
  if (!Number.isInteger(value) || value < 1) {
    throw new Error(
      `${name} must be a positive integer (got "${raw}"). It is a row count, ` +
      `and leaving it unset uses the default of ${fallback}.`,
    );
  }
  return value;
}

/**
 * `0` or `unlimited` means no ceiling. Used by the CSV export, where the answer
 * to "how many rows" is "every row this reader's scope permits" and a number is
 * only a safety valve an operator may choose to fit.
 */
function optionalCeiling(name: string): number {
  const raw = process.env[name]?.trim().toLowerCase();
  if (raw === undefined || raw === '' || raw === '0' || raw === 'unlimited') return Infinity;
  const value = Number(raw);
  if (!Number.isInteger(value) || value < 1) {
    throw new Error(
      `${name} must be a positive integer, 0, or "unlimited" (got "${raw}"). ` +
      `Unset means unlimited: a streaming export delivers the reader's whole scope.`,
    );
  }
  return value;
}

/** A model list: `/v0/list/<model>`. The generic surface, so the tighter ceiling. */
export const LIST_DEFAULT_LIMIT = positiveInt('LIST_DEFAULT_LIMIT', 25);
export const LIST_MAX_LIMIT = positiveInt('LIST_MAX_LIMIT', 100);

/**
 * A declared query (§7.1). Looser than a model list because a report is a
 * deliberate, named, compiled read rather than a generic one, and its shape was
 * approved at boot.
 */
export const QUERY_DEFAULT_LIMIT = positiveInt('QUERY_DEFAULT_LIMIT', 50);
export const QUERY_MAX_LIMIT = positiveInt('QUERY_MAX_LIMIT', 500);

/**
 * The CSV export's internal page size — how much it holds at once, not how much
 * it delivers. It pages by cursor and streams each page out, so this trades
 * round trips against peak memory and is invisible to the reader.
 */
export const CSV_PAGE_SIZE = positiveInt('CSV_PAGE_SIZE', 500);

/**
 * How many rows an export may deliver. **Unlimited by default.**
 *
 * An export is a stream: it pages server-side and writes each page to the
 * response, so total row count costs duration and round trips, never memory.
 * The bound that matters is the reader's own scope — org scope is injected into
 * every page and field policy is applied per row — so a row the export reaches
 * is a row that reader may already list. A fixed cap truncated the answer
 * instead, silently, which made the export lie about what the scope contained.
 *
 * Set it to a number if a deployment wants a safety valve; 0 or `unlimited`
 * restores the default.
 */
export const CSV_MAX_ROWS = optionalCeiling('CSV_MAX_ROWS');

/**
 * `"50MB"` → bytes. `null` when it is not a size, so each caller can raise the
 * error its own context deserves — a model names the field, the environment
 * names the variable.
 *
 * One parser for both, because `x-upload.maxSize` and `UPLOAD_DEFAULT_MAX_SIZE`
 * are the same quantity written in the same notation, and two parsers would
 * eventually disagree about what `1GB` means.
 */
export function parseByteSize(value: string): number | null {
  const match = /^(\d+)(B|KB|MB|GB)$/i.exec(String(value).trim());
  if (!match) return null;
  const units: Record<string, number> = { B: 1, KB: 1024, MB: 1024 ** 2, GB: 1024 ** 3 };
  return Number(match[1]) * units[match[2]!.toUpperCase()]!;
}

/**
 * The ceiling an upload property gets when its `x-upload.maxSize` says nothing.
 *
 * A per-property declaration always wins — the showcase's attachment declares
 * `1MB` and stays at `1MB` — so this is the answer to "the author did not say",
 * not a cap on what they may say. It is a deployment question (disk, bandwidth,
 * how long a request may take) rather than a modelling one, which is why it
 * lives here rather than staying a literal in the model compiler.
 */
function uploadDefault(): number {
  const name = 'UPLOAD_DEFAULT_MAX_SIZE';
  const raw = process.env[name]?.trim();
  if (raw === undefined || raw === '') return 50 * 1024 ** 2;   // 50MB
  const bytes = parseByteSize(raw);
  if (bytes === null || bytes < 1) {
    throw new Error(
      `${name} must be a size like "50MB" — digits followed by B, KB, MB or GB ` +
      `(got "${raw}"). Leaving it unset uses 50MB.`,
    );
  }
  return bytes;
}

export const UPLOAD_DEFAULT_MAX_SIZE = uploadDefault();

/**
 * Rate limiting on the credential routes (§22, WP-05 P-111).
 *
 * The per-IP and per-email numbers count **failures** on `login`, `refresh` and
 * invite redemption — a successful sign-in consumes nothing, which is why the
 * browser gate can sign in thirty times in a run without tripping anything.
 * `register` counts every attempt instead, because there the threat is the
 * volume of accounts created rather than guessing, so its ceiling is separate
 * and looser.
 */
export const RATE_LIMIT_WINDOW_SECONDS = positiveInt('RATE_LIMIT_WINDOW_SECONDS', 60);
export const RATE_LIMIT_PER_IP = positiveInt('RATE_LIMIT_PER_IP', 10);
export const RATE_LIMIT_PER_EMAIL = positiveInt('RATE_LIMIT_PER_EMAIL', 5);
export const RATE_LIMIT_REGISTER_PER_IP = positiveInt('RATE_LIMIT_REGISTER_PER_IP', 30);
