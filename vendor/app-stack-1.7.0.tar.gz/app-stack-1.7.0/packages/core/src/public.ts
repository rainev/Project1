/**
 * The anonymous actor, and what a model must declare to be reachable by one
 * (WP-07 S-101, ARCHITECTURE §19).
 *
 * Until now a request with no session was a 401 at the intake and nothing else:
 * there was no identity, so there was nothing for a gate to judge. A public site
 * needs a visitor to be able to READ declared rows, which means a visitor has to
 * be an actor — and the moment it is, every gate in the system applies to it
 * exactly as to anyone else. That is the whole design: **no new authorization
 * path, one more actor.**
 *
 * Two independent things already keep an org-scoped model invisible to it, and
 * both are left doing their job rather than replaced by a `public: true` flag:
 *
 *  1. **The read gate denies by default.** `x-access.read: "'admin' in
 *     actor.roles"` is false for an actor holding only `anonymous`, so the
 *     model refuses at phase one exactly as it would for any other stranger.
 *  2. **Tenant scope binds to nothing.** A visitor has no org, so
 *     `x-scope: { orgId: actor.orgId }` binds the empty string and matches no
 *     row — every row carries a real orgId.
 *
 * Belt and braces, deliberately: either alone would do, and a change that
 * weakens one should still leave a visitor seeing nothing.
 */
import { allowsAction, makeView, resolveScope } from './gates.ts';
import type { Actor } from './engine/types.ts';
import type { Model } from './model.ts';
import { tenancyDerivedScopeKeys, tenantScopeKeys } from './tenancy.ts';

/**
 * The role a visitor holds, so config can name it — `x-access.read:
 * "'anonymous' in actor.roles"` says what it means far better than `"true"`,
 * which reads as "I forgot to write a policy".
 */
export const ANONYMOUS_ROLE = 'anonymous';

/**
 * One frozen actor for every visitor. It is not a session and grants nothing on
 * its own; it exists so the gates have a subject.
 *
 * `orgId` is the empty string rather than a sentinel like `'public'`, because a
 * sentinel is a value a row could one day actually carry. The empty string
 * cannot: `create` writes the acting org's id, and there is no path that writes
 * an empty one.
 */
export const ANONYMOUS: Actor = Object.freeze({
  id: 'anonymous',
  roles: Object.freeze([ANONYMOUS_ROLE]) as string[],
  orgId: '',
});

export const isAnonymous = (actor: Actor | undefined): boolean =>
  actor?.id === ANONYMOUS.id && actor.orgId === '';

/**
 * Models a visitor's read gate admits — which is not the same as models a
 * visitor can see rows of, and the difference is what the boot check below is
 * about.
 */
export function publicModels(models: Iterable<Model>): Model[] {
  return [...models].filter((model) => allowsAction(model, makeView(ANONYMOUS, 'list', model, {})));
}

/**
 * A model open to visitors must resolve, FOR A VISITOR, to a scope that selects
 * something.
 *
 * Checked by evaluating the scope rather than by classifying its expressions.
 * The first version of this classified them — refuse any public model whose
 * scope mentions `actor.orgId` — and that was wrong in the way a static reading
 * usually is: it rejected the one shape that actually works.
 *
 *   x-scope:
 *     orgId:     "'anonymous' in actor.roles ? null : actor.orgId"
 *     published: "'anonymous' in actor.roles ? true : null"
 *
 * `resolveScope` drops a null, so that resolves to `{ published: true }` for a
 * visitor and `{ orgId: … }` for a member — one declaration, two worlds, and no
 * new keyword. Evaluating it says so; parsing it could not.
 *
 * Two failures are worth a boot error because both are silent:
 *
 *  - **Nothing resolved.** The adapter refuses an unscoped read at request time
 *    (§22), so the page 500s rather than showing nothing.
 *  - **A tenant key bound to the empty string.** A visitor has no org, so the
 *    read matches no row, forever, with no error anywhere.
 */
export function assertPublicModelsAreScoped(models: Iterable<Model>): void {
  for (const model of publicModels(models)) {
    const scope = resolveScope(model, makeView(ANONYMOUS, 'list', model, {}));
    const keys = Object.keys(scope);

    if (keys.length === 0) {
      throw new Error(
        `model "${model.name}": x-access.read admits a visitor with no session, but x-scope ` +
        `resolves to nothing for one — an unscoped read is refused at request time, so the page ` +
        `would fail rather than show nothing. Give a visitor something to be judged by, e.g. ` +
        `x-scope: { published: "'anonymous' in actor.roles ? true : null" }.`,
      );
    }

    /**
     * An empty value is damning only for a TENANCY key.
     *
     * `{ orgId: '' }` is the silent failure this exists to catch — the org a
     * visitor does not have, matching nothing, forever, with no error. But
     * `{ createdAt: '' }` is a deliberate idiom: a value no row carries, chosen
     * so a visitor may reach a model's SCHEMA (a read like any other) without
     * reaching its rows. Refusing that would forbid the one way a public form
     * can render. So: evaluate the scope, and classify the key.
     */
    const tenancy = new Set([...tenantScopeKeys(model), ...tenancyDerivedScopeKeys(model)]);
    const empty = keys.filter((key) => scope[key] === '' && tenancy.has(key));
    if (empty.length > 0) {
      throw new Error(
        `model "${model.name}": x-access.read admits a visitor with no session, but x-scope ` +
        `${empty.length > 1 ? 'keys' : 'key'} ${empty.map((k) => `"${k}"`).join(', ')} ` +
        `${empty.length > 1 ? 'resolve' : 'resolves'} to the empty string for one — that is the ` +
        `org a visitor does not have, so the read would match nothing, silently. Drop the key for ` +
        `a visitor (\`"'anonymous' in actor.roles ? null : actor.orgId"\`) and scope them by a ` +
        `property of the row instead.`,
      );
    }
  }
}
