import { resolve, sep } from 'node:path';
import type { Actor } from './engine/types.ts';
import type { AppProjection } from './projection.ts';
import type { Handler } from './server.ts';
import { seoTags } from './seo.ts';

/**
 * Serves the prebuilt bundle and injects **this actor's** projection into the
 * document (§19).
 *
 * The bundle is generic; the projection is not, and there is no endpoint that
 * hands out the app definition. Building it once at boot — which is what this
 * did until AUD-006 — handed every visitor, signed in or not, the whole app's
 * page set.
 */
export function createAssets(
  distDir: string,
  /**
   * The projection for this actor AND this URL.
   *
   * The URL is here because a `when: { state: … }` node is judged against the
   * record the requested page is about (N-102), and the only place that record
   * is named is the path. Async because resolving it is a gated database read.
   */
  project: (actor: Actor | undefined, url: URL) => AppProjection | Promise<AppProjection>,
  resolveActor: (request: Request) => Promise<Actor | undefined> | Actor | undefined,
  /**
   * The app's declared tokens, as one `:root` rule (S-110). A property of the
   * APP, not of the reader — so unlike the projection it is the same for
   * everyone, and it is built once at boot rather than per request.
   */
  themeCss = '',
  /**
   * The app's own images, from `<configDir>/assets` (WP-09 C-122).
   *
   * An app had nowhere to put a logo, a payment QR or a favicon: the config
   * directory held YAML and the only other source was the framework's bundle,
   * which is generic and rebuilt (AUD-077). So the config directory gains a
   * sibling for bytes, served by the route that already serves the bundle
   * rather than by a second one — a view references `/assets/logo.svg` and the
   * app declares nothing beyond dropping the file in.
   *
   * The bundle is checked FIRST so an app cannot shadow a framework asset.
   */
  appAssetsDir?: string,
  /** `app.yaml`'s `publicOrigin`, for the canonical link. See `app-config.ts`. */
  publicOrigin?: string,
): Handler {
  const style = themeCss ? `<style data-theme-tokens>${themeCss}</style>` : '';

  /**
   * Resolve a request path inside the app's asset directory, or refuse.
   *
   * Two things are going on here, and the second exists because of the first.
   *
   * The path must be percent-DECODED, or an image whose name contains a space
   * or an accent is requested as `/assets/my%20logo.svg` and never found. That
   * decode is also what makes traversal reachable: `%2e%2e%2f` is `../` on the
   * other side of it, and `new URL()` normalises the literal `../` form before
   * this code ever sees it but leaves the encoded form alone.
   *
   * So the containment check is not defence in depth — it is the thing standing
   * between a decoded `../../.data/jwt.key` and the file it names. The check is
   * that the RESOLVED path is still under the directory, which is the only form
   * that holds against encoded traversal, mixed encodings and the cases a
   * substring match on `..` misses. Proven by reintroducing the naive join and
   * watching `app-assets.test.ts` go red.
   */
  const assetFile = (pathname: string) => {
    if (!appAssetsDir || !pathname.startsWith('/assets/')) return undefined;
    let relative: string;
    try {
      relative = decodeURIComponent(pathname.slice('/assets'.length));
    } catch {
      return undefined; // malformed percent-encoding is not a filename
    }
    // A NUL byte truncates a path in some syscalls; it is never in an image name.
    if (relative.includes('\0')) return undefined;
    const root = resolve(appAssetsDir);
    const target = resolve(root, `.${relative}`);
    if (target !== root && !target.startsWith(`${root}${sep}`)) return undefined;
    return Bun.file(target);
  };
  const shell = async (request: Request, url: URL, html: string) => {
    const projection = await project(await resolveActor(request), url);
    /**
     * The handful of facts that must survive without JavaScript (S-120).
     *
     * Built from THIS projection, so a page absent for this reader has no title
     * and no description to leak — and a crawler, which is always a visitor,
     * sees only what a visitor is projected.
     */
    const tags = seoTags(projection.pages, url, projection.title, publicOrigin, projection.languages);
    const inject = `${tags}${style}<script>window.__APP__=${JSON.stringify(projection)}</script>`;
    /**
     * The bundle ships its own `<title>`, so ours has to REPLACE it rather than
     * join it. Two title elements is not a tie a crawler breaks in your favour —
     * it takes the first, which is the build's generic one, and every per-page
     * title is silently ignored. Driven 2026-09-18: `/public` served
     * `<title>App-Stack Showcase</title>` followed by the page's own.
     */
    const body = tags.includes('<title>') ? html.replace(/<title>[\s\S]*?<\/title>/i, '') : html;
    return new Response(body.replace('</head>', `${inject}</head>`), {
      headers: {
        'content-type': 'text/html; charset=utf-8',
        // The document now varies per actor. A shared cache holding one actor's
        // projection and serving it to another would undo the whole change.
        'cache-control': 'private, no-store',
        vary: 'cookie',
      },
    });
  };

  return async ({ request, url }) => {
    const path = url.pathname === '/' ? '/index.html' : url.pathname;
    const file = Bun.file(`${distDir}${path}`);

    // Static assets carry no projection and stay cacheable.
    if (await file.exists()) {
      if (!path.endsWith('.html')) return new Response(file);
      return shell(request, url, await file.text());
    }

    // The app's own images, after the bundle so an app cannot shadow a
    // framework asset, and before the SPA fallback so a missing image is a 404
    // rather than an HTML document with an image's content type expected.
    const asset = assetFile(path);
    if (asset && (await asset.exists())) {
      return new Response(asset, { headers: { 'cache-control': 'public, max-age=3600' } });
    }

    // Unknown path: hand back the shell so client routing can resolve it.
    const index = Bun.file(`${distDir}/index.html`);
    if (!(await index.exists())) {
      return new Response('UI bundle not built', { status: 503 });
    }
    return shell(request, url, await index.text());
  };
}
