/**
 * Generic dispatch: one route surface for every model.
 *
 * Split into intake (`http/intake.ts` — request to envelope, result to
 * response) and engine (`engine/execute.ts` — the one execution path), with
 * the audit record and the shared error classification in `engine/audit.ts`.
 * This file is the stable import surface for all three.
 */
export { createDispatcher, parseFilters } from './http/intake.ts';
export { createEngine, BUILTIN_OPS } from './engine/execute.ts';
export type { DispatchOptions, EngineOptions } from './engine/execute.ts';
export { describeError, createAuditWriter } from './engine/audit.ts';
export type { Actor, Envelope, Source, Query, ActionContext, HookResult, StagedFile } from './engine/types.ts';
export { BadRequest, DecryptionFailure, Denied, NotFound, ValidationFailure } from './errors.ts';
