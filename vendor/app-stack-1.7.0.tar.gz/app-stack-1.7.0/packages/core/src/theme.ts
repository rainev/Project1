/**
 * Theming from configuration (WP-07 S-110, decision G).
 *
 * Components never name a raw colour — they name a token, and the token is a CSS
 * custom property. That was already true; what was missing is that the tokens
 * lived in one application's stylesheet, so "re-theme the app" meant editing
 * CSS and rebuilding the bundle. A framework whose promise is configuration and
 * nothing else cannot ask that.
 *
 * `config/theme.yaml` declares the tokens; boot compiles them to a `:root` rule
 * and the document carries it alongside the projection. The bundle is unchanged
 * and uncached-per-actor either way — the tokens are a property of the app, not
 * of who is reading it (per-tenant themes are S-111, and land on top of this).
 *
 * **Not a config family.** One document, no directory, no cross-referencing —
 * so it needs neither `loadFamily` nor a fourth entry in §3.1. A family is for
 * things there are many of.
 */
import { ajv, ConfigError, formatSchemaErrors } from './config/loader.ts';
import { assertNoYamlTraps } from './config/yaml-traps.ts';

/**
 * What a token VALUE may contain.
 *
 * These strings are rendered into a `<style>` element, so the containing rule is
 * only as safe as the values inside it: a `;` or a `}` ends the declaration and
 * everything after it is attacker-chosen CSS. Config is codebase-owned and as
 * trusted as code, which is an argument for care rather than against it — the
 * same argument applies to the SQL this framework refuses to build from strings.
 *
 * So: the characters CSS values actually need — `oklch(98.4% 0.003 247.9)`,
 * `#0b0b0c`, `0.375rem`, `"Inter", system-ui, sans-serif` — and nothing that can
 * leave the declaration.
 */
const VALUE = '^[A-Za-z0-9 ()%.,/#_-]+$';

const TOKEN_MAP = { type: 'object', additionalProperties: { type: 'string', pattern: VALUE, minLength: 1 } };

/**
 * Closed, like every other meta-schema here: a token nobody consumes is a typo,
 * and a typo that loads silently is a theme that half applies.
 */
const META_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  properties: {
    $schema: { type: 'string' },
    title: { type: 'string' },
    /** `--color-<name>`: canvas, surface, line, ink, muted, accent, danger, focus. */
    colors: TOKEN_MAP,
    /** `--radius-<name>`: control, surface. */
    radius: TOKEN_MAP,
    /** `--font-<name>`: sans, mono. */
    fonts: TOKEN_MAP,
    /** Anything else, verbatim: `--<name>`. The escape hatch, and it is narrow. */
    tokens: TOKEN_MAP,
  },
} as const;

const validateTheme = ajv.compile(META_SCHEMA);

export interface Theme {
  /** `--name` → value, ready to render. */
  variables: Record<string, string>;
}

/** `accentHover` → `accent-hover`. Config reads naturally; CSS gets its spelling. */
const kebab = (name: string) => name.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`);

const PREFIXES: Record<string, string> = {
  colors: '--color-', radius: '--radius-', fonts: '--font-', tokens: '--',
};

/**
 * Does this value close every parenthesis it opens?
 *
 * The meta-schema's character class already excludes `;`, `}`, quotes and
 * brackets, so a parenthesis is the only thing in a legal value that can be
 * left hanging — and it is the one AUD-080 was actually about, a truncated
 * `linear-gradient(90deg,`.
 *
 * This is not a CSS parser and is not trying to be. It answers the one question
 * that decides whether a value can damage anything OUTSIDE itself, which is a
 * different question from whether the value is meaningful CSS. `10furlongs` is
 * nonsense and costs only its own declaration; an unclosed `(` costs every
 * token after it.
 */
function unbalanced(value: string): boolean {
  let depth = 0;
  for (const character of value) {
    if (character === '(') depth++;
    else if (character === ')' && --depth < 0) return true;
  }
  return depth !== 0;
}

export function compileTheme(doc: unknown, source: string): Theme {
  if (!validateTheme(doc)) throw new ConfigError(source, formatSchemaErrors(validateTheme.errors));
  const raw = doc as Record<string, Record<string, string> | undefined>;

  const variables: Record<string, string> = {};
  for (const [group, prefix] of Object.entries(PREFIXES)) {
    for (const [name, value] of Object.entries(raw[group] ?? {})) {
      if (!/^[A-Za-z][A-Za-z0-9]*$/.test(name)) {
        throw new ConfigError(source, `${group}.${name} is not a token name — letters and digits, starting with a letter`);
      }
      /**
       * Refuse at BOOT, which is the half of AUD-080 that matters most: the
       * finding was not only that a broken token took its siblings down, but
       * that it did so in silence — no error at boot, none in the browser, and
       * YAML key order quietly deciding which tokens survived.
       *
       * It is refused rather than dropped because a theme that half applies is
       * the failure being fixed. A missing gradient is not obviously a missing
       * gradient when you are looking at the page; a server that will not start
       * and names the token is unmissable.
       */
      if (unbalanced(value)) {
        throw new ConfigError(source,
          `${group}.${name} does not close every "(" it opens — ${JSON.stringify(value)}. ` +
          'An unclosed parenthesis consumes the end of its own rule and every token declared after it, ' +
          'so CSS drops them all with no error anywhere (AUD-080).');
      }
      variables[`${prefix}${kebab(name)}`] = value;
    }
  }
  return { variables };
}

/**
 * The tokens as a stylesheet, or `''` when the app declared none.
 *
 * `:root` rather than a class, so it overrides the bundle's compiled defaults
 * without every component opting in — the build already emits utilities that
 * read these same properties, so redefining them is the whole mechanism.
 *
 * **One rule per token, not one rule for all of them** (WP-09 C-117, AUD-080).
 * Rendering every token into a single `:root{…}` made the whole block one
 * parse: a value CSS cannot parse — an unbalanced `linear-gradient(90deg,` —
 * takes the declarations *after* it down with it, because the parser skips to
 * the end of the rule. That is how `--hero-size`, `--hero-tracking` and
 * `--section-rhythm` were served in the HTML and absent from
 * `getComputedStyle`, with no error at boot and none in the browser, and with
 * YAML key order silently deciding which tokens survived.
 *
 * The meta-schema validates the characters a value may contain, not whether it
 * parses, and a CSS parser is not something to reimplement here. So make the
 * blast radius one token: each gets its own rule, and a malformed value now
 * costs exactly itself while its siblings stand.
 */
export function themeCss(theme: Theme | undefined): string {
  const entries = Object.entries(theme?.variables ?? {});
  if (entries.length === 0) return '';
  return entries.map(([name, value]) => `:root{${name}:${value}}`).join('');
}

/** Loads `<configDir>/theme.yaml`. A missing file is not an error: the bundle's own tokens stand. */
export async function loadTheme(configDir: string): Promise<Theme | undefined> {
  const file = Bun.file(`${configDir}/theme.yaml`);
  if (!(await file.exists())) return undefined;
  const text = await file.text();
  assertNoYamlTraps(text, 'theme.yaml');
  return compileTheme(Bun.YAML.parse(text), 'theme.yaml');
}
