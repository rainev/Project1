/**
 * A model is a JSON Schema document plus `x-` keywords.
 * One declaration; the table, the API surface and the UI all derive from it.
 */
import type { ValidateFunction } from 'ajv';
import { BadRequest } from './errors.ts';
import { indexColumn } from './crypto/field.ts';
import { ajv, ConfigError, formatSchemaErrors, loadFamily } from './config/loader.ts';
import {
  compileDeclarations, crossReferenceDeclarations, HANDLER_SCHEMA,
  type HandlerDecl,
} from './handlers/declare.ts';
import { SYSTEM_FIELDS } from './config/system-fields.ts';
import { BUILTIN_EVENTS, BUILTIN_OPS, WRITE_OPS, eventFor, HOOKED_OPS, hookPoint } from './ops.ts';
import { RESERVED_ROLES } from './auth/roles.ts';
import { parseByteSize, UPLOAD_DEFAULT_MAX_SIZE } from './limits.ts';
import { PUBLIC_KEYWORDS } from './schema.ts';

export { ConfigError };

export type PropType = 'string' | 'number' | 'integer' | 'boolean';

export interface PropDef {
  type: PropType;
  transient: boolean;
  /** Stored, and never readable or writable by any actor. See `x-internal`. */
  internal: boolean;
  /**
   * How each `enum` value is SHOWN, by value. See `x-labels`.
   *
   * An enum value is two things at once: an identifier the server compares
   * against, and a label a reader sees. This separates them. The stored value
   * never changes; only what is drawn in a select or a grid cell does.
   */
  labels?: Record<string, string>;
}

/**
 * Per-field read and write policy — the `x-field-access` gate (§11).
 *
 * `onDenied` says what a refused WRITE does: `drop` (the default) keeps the
 * rest of the write and reports the field in `meta.denied`; `reject` fails the
 * whole request with a 422 naming it (WP-02 H-120).
 */
export interface FieldPolicy { read?: string; write?: string; onDenied?: 'drop' | 'reject' }

/**
 * One declared schema change.
 *
 * A rename and a drop are indistinguishable from a fresh declaration by
 * inspection alone — a column that vanished from the config either moved or
 * was meant to go — so the framework refuses both and an author says which.
 * Nothing else is declarable: a type change needs a cast per engine, which is
 * backlog, not this keyword.
 */
export type MigrationStep =
  | { rename: { from: string; to: string }; drop?: undefined }
  | { drop: string; rename?: undefined };

/**
 * One declared move in a record's lifecycle (`x-states.transitions.<name>`).
 *
 * A transition IS a custom action: the compiler synthesises the same `call`
 * declaration an author would have written by hand, so it runs on the one
 * generic route surface, through the one execution path, past the same gates
 * (WP-06 W-101). There is no second dispatcher and no second grammar.
 */
export interface Transition {
  /** The states the row may be in for this move to be legal. */
  from: string[];
  /** The state the row lands in. */
  to: string;
  /**
   * Fields that must be present on the row ONCE the move is done — satisfied by
   * the stored row or by the payload, whichever carries them (§5's state axis,
   * AUD-005). Compiled into `require[<name>]`, which `deriveSchema` then
   * evaluates against the row.
   */
  require: string[];
  /** A JEXL expression narrowing `x-access.write` for this move alone. */
  access?: string;
  /**
   * How the move is SHOWN — on a board's buttons, in a grid's row actions.
   *
   * A transition name is an identifier: it is a route segment, a hook point and
   * what the server matches on, so it cannot be the words a reader sees without
   * making those the same thing. Absent, the name is shown, which is what every
   * declaration written before this keeps doing.
   */
  label?: string;
}

/** A model's declared lifecycle (`x-states`). */
export interface States {
  /** The property holding the state. Plaintext, `type: string`, with an `enum`. */
  field: string;
  /** The state a row is created in when the caller names none. */
  initial: string;
  /** The field's `enum`, in declaration order — which is also lane order. */
  values: string[];
  transitions: Record<string, Transition>;
}

/**
 * One declared piece of recurring work (`x-schedules.<name>`, WP-06 W-121).
 *
 * A keyword on the model rather than a fourth config family, per the handoff's
 * own recommendation: every schedule so far is *about* a model's rows, a family
 * is for things there are many of, and a keyword can be promoted later if
 * something unattached to a model ever needs one. Promotion is cheap; an unused
 * directory is the breadth CLAUDE.md's failure list names.
 */
/**
 * One declared duplex channel (`x-channels.<name>`).
 *
 * A keyword on the model, not a fourth config family, for the reason `x-schedules`
 * is one: a channel is *about* a model's rows — a row is the session it belongs to —
 * and it needs no parser of its own (§21). Promotion stays cheap if something
 * unattached to a model ever needs a channel.
 *
 * There is no `mode`. Every channel is duplex; server-sent events are deferred, and a
 * schema slot with no runtime consumer behind it is the declaration-only state §3.1
 * exists to catch. Adding `mode` later, defaulting to `duplex`, breaks no declaration.
 */
export interface Channel {
  /** A framework-supplied runner, chosen by name — never app code. */
  run: string;
  /**
   * Where this channel is contained. Either a **model property** holding a path, or the literal
   * **`$base`** — the server's `--workspace-base`, which no row can name because no row knows it.
   * `$base` is what a "pick a project" surface needs: it reaches outside every project root by
   * definition, so it is the one place a channel may look wider, and the runner that serves it
   * is the narrowest one there is.
   */
  root: string;
  /**
   * The model property holding the provider id — which program the runner starts.
   * A property rather than a literal, so one declaration serves a row that picks its
   * CLI. The id resolves against the framework's own provider list, never to free text.
   */
  provider: string;
  /** What the runner acts with. A channel's process has authority of its own, so it must say so. */
  roles: string[];
  /** Bytes of recent output the engine keeps, so a reconnect can replay them. */
  replayBytes: number;
  /** Message name -> direction and payload schema, validated in both directions. */
  messages: Record<string, ChannelMessage>;
}

export interface ChannelMessage {
  direction: 'in' | 'out';
  schema: object;
}

export interface Schedule {
  /** Milliseconds between runs. */
  everyMs: number;
  /** The declared spelling, kept for messages and for the `_schedule` row. */
  every: string;
  /** The operation to run — an action or a transition on this model. */
  op: string;
  /**
   * Rows to run it for, as `field:op:value` filters. Absent means run the
   * operation ONCE with no id, which is how a schedule that creates something
   * is written.
   */
  where: string[];
  /** Most rows one run will touch. A schedule is not a migration. */
  limit: number;
  /** Data for the operation, as expressions — the same values a `call` takes. */
  data: Record<string, string | number | boolean | null>;
  /**
   * The authority the run acts with.
   *
   * Server configuration, like `PLATFORM_ADMINS`: there is no session behind a
   * schedule, so the roles come from the codebase-owned config and never from a
   * request. The gates then apply exactly as they would to a person holding
   * them — a scheduled run can do nothing an operator with these roles could
   * not do by hand.
   */
  roles: string[];
}

/**
 * One declared limit (`x-guards`).
 *
 * `where` is a set of equality terms, ANDed: the KEY is a filterable field of
 * this model, resolved to a column from the codebase-owned model definition,
 * and the VALUE is an expression evaluated against the same view a gate sees —
 * so the term is bound as a parameter and never concatenated (§22). That is
 * what makes the count SCOPED in both senses: the adapter adds the server's
 * org scope, and `where` narrows it to the cohort the limit is about.
 */
export interface Guard {
  /** The author's name for it, which is what an error and the docs call it. */
  name: string;
  /** Operations this guard applies to — builtins and declared actions alike. */
  on: string[];
  /** Filterable field -> expression. ANDed. */
  where: Record<string, string>;
  /** The most rows `where` may match. The write that would exceed it is refused. */
  max: number;
  /** What the refusal says. A workflow fact, like a transition's. */
  reason: string;
}

export interface Model {
  name: string;
  table: string;
  /**
   * `x-dispatch: read` — generic dispatch may read this model and may not write
   * it. The framework's identity models declare it: they are operated by the
   * routes under `/v0/auth/`, each of which re-derives the actor and decides for
   * itself, and `roles` is a writable column, so an ordinary `update` carrying
   * it would be privilege escalation through the one door.
   *
   * Absent means both, which is every application model.
   */
  dispatch: 'read' | 'full';
  /**
   * Declared by the framework rather than loaded from an app's config.
   *
   * The unscoped storage operations (`systemCreate`, `systemList`, …) are for
   * these alone — they carry no gates and no scope, which is right for the
   * routes that operate identity and wrong for anything an app declares. It is
   * a property rather than a naming rule because the name is now `user`, and a
   * prefix cannot answer a question about ownership.
   */
  framework: boolean;
  /** Permission name -> JEXL expression. Absent means deny. */
  access: Record<string, string>;
  /** Column -> JEXL expression yielding a VALUE that is bound into the query. */
  scope: Record<string, string>;
  /**
   * Per-field read/write policy, keyed by field. Named for the gate it feeds
   * (`x-field-access`), not for "fields", which is what the audit record calls
   * the list of names in a payload.
   */
  fieldAccess: Record<string, FieldPolicy>;
  /** Fields that must be unique within the query scope. */
  unique: string[];
  /** Sort/filter allowlists. Default: every persisted column. */
  sortable: string[];
  filterable: string[];
  /** Lifecycle point -> handler references (`path#export`). */
  /**
   * Fields holding a reference to another model's row.
   *
   * The field stores a plain id; there is no join. Pickers and label resolution
   * go back through generic dispatch, so the referenced model's own gates and
   * scope apply — a relation cannot be used to see something you may not read.
   */
  lookups: Record<string, { model: string; label: string }>;
  /** Encrypted fields, and whether they carry a blind index for equality lookup. */
  encrypted: Record<string, { search?: 'exact' }>;
  /** Properties that carry an uploaded file, with their limits. */
  uploads: Record<string, { accept: string[]; maxSize: number }>;
  /**
   * Lifecycle point -> handlers, in declaration order. A handler is either a
   * `path#export` reference to code or a DECLARATION the framework runs itself
   * (§13, WP-02 D-02). The engine cannot tell which it got.
   */
  hooks: Record<string, HandlerDecl[]>;
  /** Custom operation -> its handler, code or declaration. */
  actions: Record<string, HandlerDecl>;
  /**
   * Event name -> handlers that run AFTER the causing transaction commits
   * (`x-events`, WP-06 W-111). Same grammar as `x-hooks` and the same registry;
   * what differs is when they run and that a failure retries instead of
   * rolling anything back.
   */
  events: Record<string, HandlerDecl[]>;
  /** Recurring work this model declares (`x-schedules`, WP-06 W-121). */
  schedules: Record<string, Schedule>;
  /** Duplex channels this model declares (`x-channels`). */
  channels: Record<string, Channel>;
  /**
   * The declared lifecycle, if the model has one (`x-states`). Every transition
   * also appears in `actions` and in `require`, because a transition is an
   * action with a requirement set — this is what the state-dependent parts
   * (the phase-two guard, the board's legal moves) read.
   */
  states?: States;
  /**
   * Declared capacity limits (`x-guards`, WP-11 S-121, AUD-071).
   *
   * A gate expression sees `{ actor, op, model, input, row, now }` and no
   * aggregate, so "refuse when 30 seats are already confirmed" was not
   * expressible in `x-access` or in a `deny` hook. A guard is the one keyword
   * that can ask the database a counting question, and it is deliberately not
   * an expression: it is a scoped equality count with a ceiling, evaluated
   * inside the operation's own transaction, so what it counted cannot change
   * between the counting and the write.
   */
  guards: Guard[];
  /** Author-declared properties, in declaration order. */
  props: Record<string, PropDef>;
  /** Properties that are persisted (declared minus transient). */
  columns: string[];
  notNull: string[];
  /**
   * Declared intent for a schema change the framework refuses to guess
   * (`x-storage.migrations`, WP-04 E-121). Applied in order, before the
   * additive diff, and permanent: once a step has run its `from` column no
   * longer exists, so re-running it is a no-op rather than a second rename.
   */
  migrations: MigrationStep[];
  require: Record<string, string[]>;
  /** The base JSON Schema, carrying no `required` — see ARCHITECTURE §5. */
  schema: Record<string, unknown>;
}

export { SYSTEM_FIELDS };
export { BUILTIN_EVENTS, BUILTIN_OPS, WRITE_OPS, eventFor, HOOKED_OPS, hookPoint };

const IDENTIFIER = /^[A-Za-z_][A-Za-z0-9_]*$/;

/**
 * Standard JSON Schema keywords a property may carry: the public set the
 * derived schema forwards to the client, plus the framework's own `x-` ones.
 * Anything else — a typo, a keyword nothing consumes — fails at boot rather
 * than loading silently (WP-00, found while testing the shared loader).
 */
const PROPERTY_KEYWORDS = Object.fromEntries([...PUBLIC_KEYWORDS].map((k) => [k, {}]));

/** What a model document may contain. Anything else fails at boot. */
const META_SCHEMA = {
  type: 'object',
  required: ['$id', 'type', 'properties'],
  additionalProperties: false,
  properties: {
    $schema: { type: 'string' },
    title: { type: 'string' },
    description: { type: 'string' },
    // Admitted by the meta-schema only so the compiler can refuse it with the
    // message that names the replacement (`x-require`).
    required: {},
    $id: { type: 'string', pattern: IDENTIFIER.source },
    type: { const: 'object' },
    properties: {
      type: 'object',
      minProperties: 1,
      additionalProperties: {
        type: 'object',
        required: ['type'],
        additionalProperties: false,
        properties: {
          ...PROPERTY_KEYWORDS,
          type: { enum: ['string', 'number', 'integer', 'boolean'] },
          'x-transient': { type: 'boolean' },
          'x-internal': { type: 'boolean' },
          'x-labels': { type: 'object', additionalProperties: { type: 'string' }, minProperties: 1 },
          format: { type: 'string' },
          'x-upload': {
            type: 'object',
            properties: {
              accept: { type: 'array', items: { type: 'string' } },
              maxSize: { type: 'string' },
            },
            additionalProperties: false,
          },
          'x-lookup': {
            type: 'object',
            required: ['model'],
            properties: {
              model: { type: 'string', pattern: IDENTIFIER.source },
              label: { type: 'string', pattern: IDENTIFIER.source },
            },
            additionalProperties: false,
          },
          'x-encrypt': {
            oneOf: [
              { type: 'boolean' },
              { type: 'object', properties: { search: { const: 'exact' } }, additionalProperties: false },
            ],
          },
        },
      },
    },
    'x-storage': {
      type: 'object',
      properties: {
        table: { type: 'string', pattern: IDENTIFIER.source },
        notNull: { type: 'array', items: { type: 'string' } },
        migrations: {
          type: 'array',
          items: {
            type: 'object',
            additionalProperties: false,
            minProperties: 1,
            maxProperties: 1,
            properties: {
              rename: {
                type: 'object',
                required: ['from', 'to'],
                additionalProperties: false,
                properties: {
                  from: { type: 'string', pattern: IDENTIFIER.source },
                  to: { type: 'string', pattern: IDENTIFIER.source },
                },
              },
              drop: { type: 'string', pattern: IDENTIFIER.source },
            },
          },
        },
      },
      additionalProperties: false,
    },
    'x-require': {
      type: 'object',
      additionalProperties: { type: 'array', items: { type: 'string' } },
    },
    'x-access': {
      type: 'object',
      additionalProperties: { type: 'string', minLength: 1 },
    },
    'x-scope': {
      type: 'object',
      additionalProperties: { type: 'string', minLength: 1 },
    },
    'x-unique': { type: 'array', items: { type: 'string' } },
    'x-dispatch': { enum: ['read'] },
    'x-query': {
      type: 'object',
      properties: {
        sortable: { type: 'array', items: { type: 'string' } },
        filterable: { type: 'array', items: { type: 'string' } },
      },
      additionalProperties: false,
    },
    'x-hooks': {
      type: 'object',
      additionalProperties: { type: 'array', items: HANDLER_SCHEMA },
    },
    /**
     * Post-commit handlers, keyed by event name (§12, WP-06 W-111).
     *
     * A name is `<model>.<event>`, because an event is something that happened
     * to a row of a model and a listener may live on a different model. Both
     * halves are checked at boot against what actually emits.
     */
    'x-events': {
      type: 'object',
      propertyNames: { pattern: '^[A-Za-z_][A-Za-z0-9_]*\\.[A-Za-z_][A-Za-z0-9_]*$' },
      additionalProperties: { type: 'array', minItems: 1, items: HANDLER_SCHEMA },
    },
    'x-actions': {
      type: 'object',
      additionalProperties: HANDLER_SCHEMA,
    },
    'x-field-access': {
      type: 'object',
      additionalProperties: {
        type: 'object',
        properties: {
          read: { type: 'string' },
          write: { type: 'string' },
          onDenied: { enum: ['drop', 'reject'] },
        },
        additionalProperties: false,
      },
    },
    /**
     * Recurring work (WP-06 W-121). A keyword, not a family — see `Schedule`.
     */
    'x-schedules': {
      type: 'object',
      minProperties: 1,
      propertyNames: { pattern: '^[A-Za-z_][A-Za-z0-9_-]*$' },
      additionalProperties: {
        type: 'object',
        required: ['every', 'op'],
        additionalProperties: false,
        properties: {
          every: { type: 'string', pattern: '^[1-9][0-9]*[smhd]$' },
          op: { type: 'string', pattern: IDENTIFIER.source },
          where: { type: 'array', items: { type: 'string', minLength: 3 } },
          limit: { type: 'integer', minimum: 1, maximum: 1000 },
          data: { type: 'object', additionalProperties: { type: ['string', 'number', 'boolean', 'null'] } },
          roles: { type: 'array', minItems: 1, items: { type: 'string', minLength: 1 } },
        },
      },
    },
    /**
     * Duplex channels (`x-channels`). Shape only; `compileChannels` does the
     * cross-checks that need the model — the runner exists, `root` names a real
     * property, every message schema actually compiles.
     */
    'x-channels': {
      type: 'object',
      minProperties: 1,
      propertyNames: { pattern: IDENTIFIER.source },
      additionalProperties: {
        type: 'object',
        required: ['run', 'root', 'provider', 'roles', 'messages'],
        additionalProperties: false,
        properties: {
          run: { type: 'string', pattern: IDENTIFIER.source },
          root: { anyOf: [{ type: 'string', pattern: IDENTIFIER.source }, { const: '$base' }] },
          provider: { type: 'string', pattern: IDENTIFIER.source },
          roles: { type: 'array', minItems: 1, items: { type: 'string', minLength: 1 } },
          replay: {
            type: 'object', additionalProperties: false,
            properties: { bytes: { type: 'integer', minimum: 0, maximum: 1048576 } },
          },
          messages: {
            type: 'object',
            minProperties: 1,
            propertyNames: { pattern: IDENTIFIER.source },
            additionalProperties: {
              type: 'object',
              required: ['direction', 'schema'],
              additionalProperties: false,
              properties: {
                direction: { enum: ['in', 'out'] },
                schema: { type: 'object' },
              },
            },
          },
        },
      },
    },
    /**
     * The record's lifecycle (§5's state axis, WP-06 W-101). One state field,
     * one initial state, and a named move per legal transition — each of which
     * becomes a custom operation on the generic surface.
     */
    /**
     * Declared capacity limits (S-121). One keyword, general: any scoped count
     * on any operation, rather than a keyword shaped around one application.
     */
    'x-guards': {
      type: 'object',
      minProperties: 1,
      propertyNames: { pattern: IDENTIFIER.source },
      additionalProperties: {
        type: 'object',
        required: ['on', 'where', 'max', 'reason'],
        additionalProperties: false,
        properties: {
          on: { type: 'array', minItems: 1, items: { type: 'string', pattern: IDENTIFIER.source } },
          where: {
            type: 'object',
            minProperties: 1,
            propertyNames: { pattern: IDENTIFIER.source },
            additionalProperties: { type: 'string', minLength: 1 },
          },
          max: { type: 'integer', minimum: 0 },
          reason: { type: 'string', minLength: 1 },
        },
      },
    },
    'x-states': {
      type: 'object',
      required: ['field', 'initial', 'transitions'],
      additionalProperties: false,
      properties: {
        field: { type: 'string', pattern: IDENTIFIER.source },
        initial: { type: 'string', minLength: 1 },
        transitions: {
          type: 'object',
          minProperties: 1,
          // A transition name becomes a route segment and a hook point, so it
          // is held to the same shape every other operation name is.
          propertyNames: { pattern: IDENTIFIER.source },
          additionalProperties: {
            type: 'object',
            required: ['from', 'to'],
            additionalProperties: false,
            properties: {
              from: { type: 'array', minItems: 1, items: { type: 'string', minLength: 1 } },
              to: { type: 'string', minLength: 1 },
              require: { type: 'array', items: { type: 'string' } },
              access: { type: 'string', minLength: 1 },
              label: { type: 'string', minLength: 1 },
            },
          },
        },
      },
    },
  },
} as const;

/** The shared size parser; the error names the field, which only this caller knows. */
function parseSize(value: string, source: string, field: string): number {
  const bytes = parseByteSize(value);
  if (bytes === null) throw new ConfigError(source, `x-upload.maxSize on "${field}" must look like "10MB"`);
  return bytes;
}

const validateMeta: ValidateFunction = ajv.compile(META_SCHEMA);

/**
 * Keywords that have been renamed. The meta-schema is strict, so without this
 * a renamed keyword fails with "must NOT have additional properties", which
 * tells an author nothing about where their declaration went.
 */
const RENAMED: Record<string, string> = {
  'x-fields': 'x-field-access',
};

/**
 * Runs as the loader's preflight, before the meta-schema, and again at the top
 * of `compileModel` for callers that compile a document by hand.
 */
export function refuseRenamed(doc: unknown, source: string): void {
  for (const [was, now] of Object.entries(RENAMED)) {
    if (doc && typeof doc === 'object' && was in (doc as Record<string, unknown>)) {
      throw new ConfigError(source, `"${was}" has been renamed to "${now}"`);
    }
  }
}

export function compileModel(doc: unknown, source: string): Model {
  refuseRenamed(doc, source);
  if (!validateMeta(doc)) throw new ConfigError(source, formatSchemaErrors(validateMeta.errors));

  const raw = doc as Record<string, any>;
  const name: string = raw.$id;
  const table: string = raw['x-storage']?.table ?? name;

  const props: Record<string, PropDef> = {};
  for (const [key, def] of Object.entries<any>(raw.properties)) {
    if (!IDENTIFIER.test(key)) {
      throw new ConfigError(source, `property "${key}" is not a safe identifier`);
    }
    if ((SYSTEM_FIELDS as readonly string[]).includes(key)) {
      throw new ConfigError(source, `"${key}" is framework-owned and cannot be declared`);
    }
    /**
     * `x-internal` is the inverse of `x-transient`: stored, and never leaving
     * the process. A password hash, a token hash, an API key — material a row
     * must carry and no actor may read, including the actor it belongs to.
     *
     * It is not policy. `x-field-access` is an expression the app owns and may
     * change; this is a property of the field, so nothing an app writes can
     * grant it. Declaring both is a contradiction and refused below.
     */
    const internal = def['x-internal'] === true;
    if (internal && def['x-transient'] === true) {
      throw new ConfigError(source, `"${key}" is both x-internal and x-transient — the first is stored and never read, the second is neither`);
    }
    /**
     * `x-labels` names how each value is shown. Every key has to be a value the
     * field declares — a label for a value that does not exist is dead config,
     * and the typo it usually is would silently show the identifier instead.
     * Not every value needs one: a value with no label shows itself.
     */
    let labels: Record<string, string> | undefined;
    if (def['x-labels']) {
      const values: unknown = def.enum;
      if (!Array.isArray(values)) {
        throw new ConfigError(source, `"${key}" declares x-labels but no enum — there are no values to label`);
      }
      for (const value of Object.keys(def['x-labels'])) {
        if (!values.includes(value)) {
          throw new ConfigError(source,
            `x-labels on "${key}" names "${value}", which is not one of its values — declared: ${values.join(', ')}`);
        }
      }
      labels = { ...def['x-labels'] };
    }
    props[key] = { type: def.type, transient: def['x-transient'] === true, internal, ...(labels ? { labels } : {}) };
  }

  const columns = Object.keys(props).filter((k) => !props[k]!.transient);

  const notNull: string[] = raw['x-storage']?.notNull ?? [];
  for (const field of notNull) {
    if (!columns.includes(field)) {
      throw new ConfigError(source, `x-storage.notNull references unknown or transient field "${field}"`);
    }
  }

  // A declared step describes a column that is LEAVING the declaration, so its
  // `from`/`drop` must not still be declared — that would be a rename to a
  // field that already exists, which is a contradiction, not a migration.
  const migrations: MigrationStep[] = raw['x-storage']?.migrations ?? [];
  for (const step of migrations) {
    const leaving = step.rename?.from ?? step.drop!;
    if ((SYSTEM_FIELDS as readonly string[]).includes(leaving)) {
      throw new ConfigError(source, `x-storage.migrations names "${leaving}", which is framework-owned`);
    }
    if (step.rename) {
      const { from, to } = step.rename;
      if (from === to) {
        throw new ConfigError(source, `x-storage.migrations renames "${from}" to itself`);
      }
      if (columns.includes(from)) {
        throw new ConfigError(source,
          `x-storage.migrations renames "${from}", which is still declared as a property — remove it, or rename a different field`);
      }
      if (!columns.includes(to)) {
        throw new ConfigError(source,
          `x-storage.migrations renames "${from}" to "${to}", which is not a persisted property of "${name}"`);
      }
    } else {
      const field = step.drop!;
      if (columns.includes(field)) {
        throw new ConfigError(source,
          `x-storage.migrations drops "${field}", which is still declared as a property`);
      }
    }
  }

  // Copied for the reason `actions` is: a transition contributes its own
  // requirement set, and the raw document must read the same on a second compile.
  const require: Record<string, string[]> = { ...(raw['x-require'] ?? {}) };
  for (const [op, fields] of Object.entries(require)) {
    for (const field of fields) {
      if (!(field in props)) {
        throw new ConfigError(source, `x-require.${op} references unknown field "${field}"`);
      }
    }
  }

  if ('required' in raw) {
    throw new ConfigError(source, 'base schema must not carry `required` — use x-require (ARCHITECTURE §5)');
  }

  const access: Record<string, string> = raw['x-access'] ?? {};
  const scope: Record<string, string> = raw['x-scope'] ?? {};

  for (const col of Object.keys(scope)) {
    if (!columns.includes(col) && !(SYSTEM_FIELDS as readonly string[]).includes(col)) {
      throw new ConfigError(source, `x-scope references unknown field "${col}"`);
    }
  }

  const unique: string[] = raw['x-unique'] ?? [];
  for (const field of unique) {
    if (!columns.includes(field)) {
      throw new ConfigError(source, `x-unique references unknown or transient field "${field}"`);
    }
  }

  const encrypted: Record<string, { search?: 'exact' }> = {};
  for (const [key, def] of Object.entries<any>(raw.properties)) {
    const setting = def['x-encrypt'];
    if (setting === undefined || setting === false) continue;
    if (props[key]!.type !== 'string') {
      throw new ConfigError(source, `x-encrypt on "${key}" requires type string`);
    }
    if (props[key]!.transient) {
      throw new ConfigError(source, `"${key}" is transient and is never stored, so x-encrypt is meaningless`);
    }
    encrypted[key] = setting === true ? {} : { search: setting.search };
  }

  const lookups: Record<string, { model: string; label: string }> = {};
  for (const [key, def] of Object.entries<any>(raw.properties)) {
    const setting = def['x-lookup'];
    if (setting === undefined) continue;
    if (props[key]!.type !== 'string') {
      throw new ConfigError(source, `x-lookup on "${key}" requires type string — it holds an id`);
    }
    if (props[key]!.transient) {
      throw new ConfigError(source, `"${key}" is transient, so a lookup on it would reference nothing stored`);
    }
    if (key in encrypted) {
      throw new ConfigError(source, `"${key}" is encrypted and cannot be a lookup — the id must be readable to resolve`);
    }
    lookups[key] = { model: setting.model, label: setting.label ?? 'id' };
  }

  const uploads: Record<string, { accept: string[]; maxSize: number }> = {};
  for (const [key, def] of Object.entries<any>(raw.properties)) {
    if (def['x-upload'] === undefined && def.format !== 'binary') continue;
    if (def.format !== 'binary') {
      throw new ConfigError(source, `x-upload on "${key}" requires format: binary`);
    }
    if (props[key]!.transient) {
      throw new ConfigError(source, `"${key}" is transient, so it cannot hold an uploaded file`);
    }
    const settings = def['x-upload'] ?? {};
    uploads[key] = {
      accept: settings.accept ?? [],
      // A declared size always wins; the environment answers only for a property
      // that declared none (`UPLOAD_DEFAULT_MAX_SIZE`, 50MB by default).
      maxSize: settings.maxSize === undefined
        ? UPLOAD_DEFAULT_MAX_SIZE
        : parseSize(settings.maxSize, source, key),
    };
  }

  const systemSortable = ['createdAt', 'updatedAt', 'id'];
  const query = raw['x-query'] ?? {};
  const checkList = (list: string[], key: string) => {
    for (const field of list) {
      if (!columns.includes(field) && !systemSortable.includes(field)) {
        throw new ConfigError(source, `x-query.${key} references unknown or transient field "${field}"`);
      }
      /**
       * Sorting or filtering by a field nothing may read is an oracle: the
       * ORDER of the rows answers a question the field itself never would, and
       * `db/sql.ts` validates a request's sort against this list rather than
       * against readability. Sealing the list is what keeps that safe.
       */
      if (props[field]?.internal) {
        throw new ConfigError(source, `x-query.${key} references "${field}", which is x-internal — ordering or filtering by it would answer questions about a value nothing may read`);
      }
    }
    return list;
  };
  // Encrypted columns are opaque to the database, so they are not sortable or
  // filterable by default. Naming one explicitly is an error, caught below.
  const plain = columns.filter((c) => !(c in encrypted));
  const sortable = query.sortable ? checkList(query.sortable, 'sortable') : [...plain, ...systemSortable];
  // `id` and every lookup field are always filterable, whatever an author
  // declares. Both are opaque identifiers whose only use IS equality: resolving
  // a relation fetches a known set in one call (`where=id:in:…`), and filtering
  // by a relation — "notes for this customer" — is the entire point of having
  // one. Neither leaks anything a filter could not already establish, and
  // forgetting to list them is a papercut, not a policy decision.
  // Sorting is NOT force-added: a lookup sorts by default like any column
  // (which groups rows by target), but an explicit sortable list is respected.
  const declaredFilterable = query.filterable ? checkList(query.filterable, 'filterable') : [...plain];
  const alwaysFilterable = ['id', ...Object.keys(lookups)];
  const filterable = [...declaredFilterable, ...alwaysFilterable.filter((f) => !declaredFilterable.includes(f))];

  // Encrypted columns are opaque to the database. Reject the impossible at BOOT
  // rather than returning silently wrong results in production.
  for (const field of Object.keys(encrypted)) {
    if (sortable.includes(field)) {
      throw new ConfigError(source, `"${field}" is encrypted and cannot be sortable — ciphertext does not order`);
    }
    if (filterable.includes(field) && encrypted[field]!.search !== 'exact') {
      throw new ConfigError(source,
        `"${field}" is encrypted and cannot be filterable without x-encrypt.search: exact (a blind index)`);
    }
    if (unique.includes(field) && encrypted[field]!.search !== 'exact') {
      throw new ConfigError(source,
        `"${field}" is encrypted and cannot be unique without x-encrypt.search: exact (a blind index)`);
    }
  }

  // A searchable encrypted field gets a framework-owned shadow column.
  for (const [field, setting] of Object.entries(encrypted)) {
    if (setting.search !== 'exact') continue;
    const shadow = indexColumn(field);
    props[shadow] = { type: 'string', transient: false };
    columns.push(shadow);
    filterable.push(shadow);
  }

  const fieldAccess: Record<string, FieldPolicy> = raw['x-field-access'] ?? {};
  for (const name of Object.keys(fieldAccess)) {
    if (!(name in props)) {
      throw new ConfigError(source, `x-field-access references unknown field "${name}"`);
    }
  }

  const hooks: Record<string, HandlerDecl[]> = raw['x-hooks'] ?? {};
  // Copied, because the transitions below are APPENDED to it: `schema` keeps a
  // reference to the raw document, and a compiler that mutated what an author
  // wrote would make the same file compile differently the second time.
  const actions: Record<string, HandlerDecl> = { ...(raw['x-actions'] ?? {}) };

  const states = compileStates(raw, source, { name, props, columns, encrypted, actions, require });

  const events: Record<string, HandlerDecl[]> = raw['x-events'] ?? {};
  const schedules = compileSchedules(raw, source, { actions, filterable, states });
  const channels = compileChannels(raw, source, { props });
  const guards = compileGuards(raw, source, { filterable, encrypted, actions });

  // Code references and declarations, checked together and reported together:
  // an author fixing a config wants every problem in it, not the first one.
  // Cross-MODEL checks (does the model a call names exist, does it have that
  // op) run in `loadModels`, once every model has compiled.
  const declarationProblems = compileDeclarations({ name, props }, hooks, actions, events);
  if (declarationProblems.length) {
    throw new ConfigError(source, declarationProblems.join('; '));
  }

  // A hook bound to a point the dispatcher never fires is worse than a broken
  // one: the file and the export both resolve at boot, so it looks wired and is
  // silent forever. Reject the point, naming what is available.
  const hookable = [...HOOKED_OPS, ...Object.keys(actions)];
  const points = hookable.flatMap((op) => [hookPoint('before', op), hookPoint('after', op)]);
  for (const point of Object.keys(hooks)) {
    if (!points.includes(point)) {
      throw new ConfigError(source,
        `x-hooks."${point}" is never fired — valid points are ${points.join(', ')}`);
    }
  }

  // Same reasoning for x-require: a set named for an operation that does not
  // exist silently contributes no `required` to anything.
  const requireable = ['create', 'update', ...Object.keys(actions)];
  for (const op of Object.keys(require)) {
    if (!requireable.includes(op)) {
      throw new ConfigError(source,
        `x-require."${op}" names no operation — valid keys are ${requireable.join(', ')}`);
    }
  }

  return {
    name, table, dispatch: raw['x-dispatch'] === 'read' ? 'read' : 'full',
    framework: source.startsWith('framework:'),
    props, columns, notNull, migrations, require, access, scope, fieldAccess, unique,
    sortable, filterable, encrypted, lookups, uploads, hooks, actions, events, schedules, channels, states,
    guards, schema: raw,
  };
}

/**
 * `x-guards` — the structural half (S-121, AUD-071).
 *
 * Only what can be decided from the document itself: that the operation exists,
 * that the field can be counted on, and that the field is not ciphertext. The
 * EXPRESSIONS are compiled by `engine/guards.ts` at boot, next to the gates, for
 * the same reason the gates are compiled there — a broken expression fails
 * startup, and this module has no opinion about the expression language.
 */
/**
 * Operations a guard may be declared on.
 *
 * The writes that can ADD to a counted set, and nothing else. Not the reads:
 * "refuse a read because 30 rows exist" is not a capacity limit but an access
 * rule, which `x-access` already expresses. And not `delete`, which can only
 * make a count smaller — a keyword that accepted it would be admitting a
 * declaration that can never fire, which is the silent-and-looks-wired failure
 * the boot checks exist to prevent.
 */
const GUARDABLE_OPS = ['create', 'update'] as const;

function compileGuards(
  raw: any, source: string,
  owner: { filterable: string[]; encrypted: Record<string, unknown>; actions: Record<string, unknown> },
): Guard[] {
  const declared = raw['x-guards'];
  if (declared === undefined) return [];

  // Every operation a guard may name: the builtin writes and every declared
  // action, which includes every transition, since a transition IS an action.
  const guardable = [...GUARDABLE_OPS, ...Object.keys(owner.actions)];
  const guards: Guard[] = [];

  for (const [name, def] of Object.entries<any>(declared)) {
    for (const op of def.on as string[]) {
      if (!guardable.includes(op)) {
        throw new ConfigError(source,
          `x-guards."${name}".on names "${op}", which is not an operation this model has — ` +
          `valid operations are ${guardable.join(', ')}`);
      }
    }
    for (const field of Object.keys(def.where)) {
      // The count goes through the adapter's filter path, which resolves a
      // column from THIS definition and refuses anything not declared
      // filterable. Saying so at boot beats a request-time refusal, and it is
      // what keeps the identifier codebase-owned (§22).
      if (!owner.filterable.includes(field)) {
        throw new ConfigError(source,
          `x-guards."${name}".where counts on "${field}", which is not filterable — ` +
          `add it to x-query.filterable, or count on one of ${owner.filterable.join(', ') || '<none declared>'}`);
      }
      if (field in owner.encrypted) {
        throw new ConfigError(source,
          `x-guards."${name}".where counts on "${field}", which is encrypted — ` +
          'a count is a filter, and ciphertext does not compare');
      }
    }
    guards.push({
      name, on: [...def.on], where: { ...def.where }, max: def.max, reason: def.reason,
    });
  }
  return guards;
}

const DURATION_MS: Record<string, number> = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000 };

/**
 * Runners the framework supplies. A channel picks one **by name**, the way a database
 * engine or a notification provider is picked — not by `path#export` like a handler.
 * That difference is the point: a handler is app code, trusted and unsandboxed, and a
 * channel starts a process. An app that could name its own runner could start anything,
 * and an app whose whole source is YAML could not ship one anyway.
 */
export const CHANNEL_RUNNERS = ['pty', 'files', 'browse'] as const;

/** `x-channels.<name>.root` may name this instead of a property: the server's workspace base. */
export const BASE_ROOT = '$base';

/**
 * Compile `x-channels`.
 *
 * Every check is here because the alternative is a channel that binds at boot and fails
 * when someone opens it — or worse, opens onto nothing. A message schema that does not
 * compile would be discovered on the first frame; `root` naming no property would be
 * discovered as an undefined containment root, which is the one failure that must never
 * be reached at runtime.
 */
function compileChannels(
  raw: Record<string, any>, source: string,
  model: { props: Record<string, any> },
): Record<string, Channel> {
  const declared = raw['x-channels'];
  if (declared === undefined) return {};

  const channels: Record<string, Channel> = {};
  for (const [name, def] of Object.entries<any>(declared)) {
    if (!(CHANNEL_RUNNERS as readonly string[]).includes(def.run)) {
      throw new ConfigError(source,
        `x-channels.${name} names runner "${def.run}", which the framework does not supply — ` +
        `available: ${CHANNEL_RUNNERS.join(', ')}`);
    }
    for (const key of ['root', 'provider'] as const) {
      if (key === 'root' && def.root === BASE_ROOT) continue;   // the server's base, not a row's value
      if (!Object.hasOwn(model.props, def[key])) {
        throw new ConfigError(source,
          `x-channels.${name}.${key} is "${def[key]}", which is not a property of this model — ` +
          `declared: ${Object.keys(model.props).join(', ') || 'none'}`);
      }
    }
    for (const role of def.roles as string[]) {
      if (RESERVED_ROLES.includes(role)) {
        throw new ConfigError(source,
          `x-channels.${name}.roles names the reserved role "${role}" — it is granted by server configuration (PLATFORM_ADMINS) and nowhere else`);
      }
    }

    const messages: Record<string, ChannelMessage> = {};
    for (const [messageName, message] of Object.entries<any>(def.messages)) {
      try {
        ajv.compile(message.schema);
      } catch (error) {
        throw new ConfigError(source,
          `x-channels.${name}.messages.${messageName}.schema is not a valid schema: ${(error as Error).message}`);
      }
      messages[messageName] = { direction: message.direction, schema: message.schema };
    }
    if (!Object.values(messages).some((m) => m.direction === 'in')
        || !Object.values(messages).some((m) => m.direction === 'out')) {
      throw new ConfigError(source,
        `x-channels.${name} declares no ${Object.values(messages).some((m) => m.direction === 'in') ? 'out' : 'in'} message — ` +
        `a duplex channel needs both directions`);
    }

    channels[name] = {
      run: def.run,
      root: def.root,
      provider: def.provider,
      roles: [...def.roles],
      replayBytes: def.replay?.bytes ?? 65536,
      messages,
    };
  }
  return channels;
}

/** The filter operators the intake accepts, so a schedule's `where` is the same language. */
const FILTER_OPS = ['eq', 'ne', 'gt', 'gte', 'lt', 'lte', 'contains', 'in'];

/**
 * Compile `x-schedules` (W-121).
 *
 * Every check here exists because the alternative is silence: a schedule naming
 * an operation that does not exist, or filtering on a column the adapter will
 * refuse, would bind at boot and fail in a background loop nobody is watching —
 * the same reason a hook bound to an unfired point is a boot error.
 */
function compileSchedules(
  raw: Record<string, any>, source: string,
  model: {
    actions: Record<string, HandlerDecl>;
    filterable: string[];
    states: States | undefined;
  },
): Record<string, Schedule> {
  const declared = raw['x-schedules'];
  if (declared === undefined) return {};

  const runnable = Object.keys(model.actions);
  const schedules: Record<string, Schedule> = {};

  for (const [name, def] of Object.entries<any>(declared)) {
    if (!runnable.includes(def.op)) {
      throw new ConfigError(source,
        `x-schedules.${name} runs "${def.op}", which is not an operation of this model — ` +
        `declared: ${runnable.join(', ') || 'none'}`);
    }
    for (const [i, filter] of ((def.where ?? []) as string[]).entries()) {
      const [field, op] = filter.split(':');
      if (!field || !op || !FILTER_OPS.includes(op)) {
        throw new ConfigError(source,
          `x-schedules.${name}.where[${i}] is "${filter}" — expected field:op:value, where op is one of ${FILTER_OPS.join(', ')}`);
      }
      if (!model.filterable.includes(field)) {
        throw new ConfigError(source,
          `x-schedules.${name}.where[${i}] filters on "${field}", which is not filterable — ` +
          `filterable: ${model.filterable.join(', ')}`);
      }
    }
    const roles: string[] = def.roles ?? [];
    // The reserved role is server configuration and nothing else may confer it
    // — a schedule is config, but §22.1 is about there being exactly ONE path,
    // and `PLATFORM_ADMINS` is it.
    for (const role of roles) {
      if (RESERVED_ROLES.includes(role)) {
        throw new ConfigError(source,
          `x-schedules.${name}.roles names the reserved role "${role}" — it is granted by server configuration (PLATFORM_ADMINS) and nowhere else`);
      }
    }
    if (roles.length === 0) {
      throw new ConfigError(source,
        `x-schedules.${name} declares no roles — a scheduled run has no session, so it must say what authority it acts with`);
    }

    const unit = def.every.slice(-1) as keyof typeof DURATION_MS;
    schedules[name] = {
      every: def.every,
      everyMs: Number(def.every.slice(0, -1)) * DURATION_MS[unit]!,
      op: def.op,
      where: [...(def.where ?? [])],
      limit: def.limit ?? 100,
      data: { ...(def.data ?? {}) },
      roles: [...roles],
    };
  }

  return schedules;
}

/**
 * A JEXL string literal for one state value.
 *
 * The synthesised transition is an ordinary declaration, and in a declaration a
 * string is an EXPRESSION, never a literal — so the target state has to be
 * written the way an author would write it, quoted. Escaping the two characters
 * that could close the quote early is what keeps a state named `won't fix` a
 * state rather than a syntax error at boot.
 */
const stateLiteral = (value: string) => `'${value.replace(/\\/g, '\\\\').replace(/'/g, "\\'")}'`;

/**
 * Compile `x-states` and turn every transition into a custom action (W-101).
 *
 * The synthesis is the point. A transition is not a new kind of thing the
 * engine has to learn: it is the `call` declaration an author would otherwise
 * have written — `update` this row, set the state field — so it arrives on the
 * generic route surface, runs through the one execution path, and passes
 * `x-access.write`, scope and field policy like any other write. What the
 * lifecycle adds is two things the engine consults by name: the legal `from`
 * states, checked by the phase-two gate once the row is loaded, and the
 * requirement set, which `deriveSchema` evaluates against that same row.
 *
 * `require` fields are forwarded from the payload into the update, because a
 * requirement a caller can satisfy and whose value is then discarded is a lie:
 * the form asks for a customer, and the customer must land on the row.
 */
function compileStates(
  raw: Record<string, any>, source: string,
  model: {
    name: string; props: Record<string, PropDef>; columns: string[];
    encrypted: Record<string, unknown>;
    actions: Record<string, HandlerDecl>; require: Record<string, string[]>;
  },
): States | undefined {
  const declared = raw['x-states'];
  if (declared === undefined) return undefined;

  const { field, initial } = declared as { field: string; initial: string };
  if (!model.columns.includes(field)) {
    throw new ConfigError(source, `x-states.field references unknown or transient field "${field}"`);
  }
  if (model.props[field]!.type !== 'string') {
    throw new ConfigError(source, `x-states.field "${field}" must be type string — a state is a named value`);
  }
  if (field in model.encrypted) {
    throw new ConfigError(source,
      `"${field}" is encrypted and cannot be the state field — a lane is a filter, and ciphertext does not compare`);
  }
  const values: unknown = raw.properties[field].enum;
  if (!Array.isArray(values) || values.length === 0) {
    throw new ConfigError(source,
      `x-states.field "${field}" declares no enum — a lifecycle needs its states named, as enum: [...]`);
  }
  const states = values.map(String);
  const list = states.join(', ');
  if (!states.includes(initial)) {
    throw new ConfigError(source,
      `x-states.initial "${initial}" is not a value of "${field}" — valid states are ${list}`);
  }

  const transitions: Record<string, Transition> = {};
  for (const [name, raw_] of Object.entries<any>(declared.transitions)) {
    if (BUILTIN_OPS.has(name)) {
      throw new ConfigError(source,
        `x-states.transitions."${name}" is a builtin operation — a transition may be named anything but ${[...BUILTIN_OPS].join(', ')}`);
    }
    if (name in model.actions) {
      throw new ConfigError(source,
        `x-states.transitions."${name}" is already declared as x-actions.${name} — a transition IS an action, so rename one of them`);
    }
    if (!states.includes(raw_.to)) {
      throw new ConfigError(source,
        `x-states.transitions.${name}.to "${raw_.to}" is not a value of "${field}" — valid states are ${list}`);
    }
    for (const from of raw_.from as string[]) {
      if (!states.includes(from)) {
        throw new ConfigError(source,
          `x-states.transitions.${name}.from names "${from}", which is not a value of "${field}" — valid states are ${list}`);
      }
    }
    const required: string[] = raw_.require ?? [];
    for (const name_ of required) {
      if (!(name_ in model.props)) {
        throw new ConfigError(source, `x-states.transitions.${name}.require references unknown field "${name_}"`);
      }
      if (name_ === field) {
        throw new ConfigError(source,
          `x-states.transitions.${name}.require names "${field}", which the transition writes itself`);
      }
    }
    transitions[name] = { from: [...raw_.from], to: raw_.to, require: required, access: raw_.access, label: raw_.label };

    // The synthesis: the declaration an author would have written by hand.
    const data: Record<string, string> = { [field]: stateLiteral(raw_.to) };
    for (const name_ of required) data[name_] = `input.${name_}`;
    model.actions[name] = { call: { op: 'update', model: model.name, id: 'id', data } };
    model.require[name] = required;
  }

  // `x-require` and a transition's own `require` would be two places to declare
  // one thing, and the loser would be silent — so there is only ever one.
  for (const op of Object.keys(raw['x-require'] ?? {})) {
    if (op in transitions) {
      throw new ConfigError(source,
        `x-require."${op}" names transition "${op}" — declare its requirements as x-states.transitions.${op}.require`);
    }
  }

  return { field, initial, values: states, transitions };
}

/**
 * Resolve a caller-supplied selector to the MODEL'S OWN identifier string.
 * Callers may select a field; a caller's string never becomes SQL text.
 */
/** Resolve against an explicit allowlist — the identifier returned is the model's own string. */
export function allowedColumn(model: Model, selector: unknown, allowlist: string[], what: string): string {
  if (typeof selector !== 'string') throw new BadRequest(`${model.name}: ${what} must be a string`);
  for (const own of allowlist) if (own === selector) return own;
  throw new BadRequest(`${model.name}: "${selector}" is not ${what}`);
}

export function column(model: Model, selector: unknown, opts: { system?: boolean } = {}): string {
  if (typeof selector !== 'string') {
    throw new BadRequest(`${model.name}: field selector must be a string`);
  }
  for (const own of model.columns) if (own === selector) return own;
  if (opts.system !== false) {
    for (const own of SYSTEM_FIELDS) if (own === selector) return own;
  }
  throw new BadRequest(`${model.name}: unknown field "${selector}"`);
}

export async function loadModels(dir: string, registered: readonly Model[] = []): Promise<Map<string, Model>> {
  const models = new Map<string, Model>();
  for (const { source, value: model } of await loadFamily(dir, { meta: validateMeta, compile: compileModel, preflight: refuseRenamed })) {
    /**
     * `_` names the framework's TABLES — `_users`, `_orgs`, `_audits` — which an
     * app shares a database with. Its models no longer carry the prefix, so a
     * model named `_archive` would work; it would also default its table to
     * `_archive` and sit in the namespace reserved for tables an app does not
     * own, which is a collision waiting for whichever framework release adds
     * that name.
     *
     * Checked HERE rather than in `compileModel`, because this is the path an
     * app's config takes and the framework's own models do not.
     */
    if (model.name.startsWith('_')) {
      throw new ConfigError(source, `model "${model.name}" starts with "_", which names the framework's own tables — choose a name without it`);
    }
    if (models.has(model.name)) throw new ConfigError(source, `duplicate model "${model.name}"`);
    models.set(model.name, model);
  }

  if (models.size === 0) throw new ConfigError(dir, 'no models found');

  /**
   * The framework's own readable models join the map BEFORE the cross-model
   * checks, so an app may point a relation or a declared query at one. After
   * them would be too late: the lookup check runs there, and `user` would read
   * as an unknown model to the very declaration this registration exists for.
   *
   * They are added after the per-model checks above, which are the app's: the
   * reserved-prefix refusal is about a name an app chose, and the framework's
   * models are not an app's to be refused.
   */
  for (const model of registered) {
    const clash = models.get(model.name);
    if (clash) {
      throw new ConfigError(`${dir}/${model.name}`,
        `"${model.name}" is a model the framework registers — choose another name for this one`);
    }
    models.set(model.name, model);
  }

  // Cross-model checks run once every model is compiled: a lookup naming a model
  // that loads later must not fail merely because of directory order. The same
  // applies to a declarative hook calling another model (WP-02 H-102).
  const callProblems = crossReferenceDeclarations(models);
  if (callProblems.length) throw new ConfigError(dir, callProblems.join('; '));

  /**
   * An `x-events` key must name something that actually emits (§13's posture).
   *
   * A listener bound to an event nothing fires is worse than a broken one: the
   * file and the export both resolve at boot, so it looks wired and is silent
   * forever — the same reason a hook bound to an unfired point is refused. The
   * emitters are the three builtin names and every declared action, which
   * includes every transition, since a transition IS an action.
   */
  for (const model of models.values()) {
    for (const name of Object.keys(model.events)) {
      const [target, event] = name.split('.') as [string, string];
      const emitter = models.get(target);
      if (!emitter) {
        throw new ConfigError(model.name,
          `x-events."${name}" names unknown model "${target}" — known: ${[...models.keys()].join(', ')}`);
      }
      const emitted = [...BUILTIN_EVENTS, ...Object.keys(emitter.actions)];
      if (!emitted.includes(event)) {
        throw new ConfigError(model.name,
          `x-events."${name}" names an event "${target}" never emits — it emits ${emitted.join(', ')}`);
      }
    }
  }

  for (const model of models.values()) {
    for (const [field, lookup] of Object.entries(model.lookups)) {
      const target = models.get(lookup.model);
      if (!target) {
        throw new ConfigError(model.name,
          `x-lookup on "${field}" names unknown model "${lookup.model}" — known: ${[...models.keys()].join(', ')}`);
      }
      if (target.name === model.name) {
        throw new ConfigError(model.name, `x-lookup on "${field}" points at its own model`);
      }
      const labelIsOwn = target.columns.includes(lookup.label);
      const labelIsSystem = (SYSTEM_FIELDS as readonly string[]).includes(lookup.label);
      if (!labelIsOwn && !labelIsSystem) {
        throw new ConfigError(model.name,
          `x-lookup on "${field}" labels by "${lookup.label}", which "${target.name}" does not have`);
      }
      if (target.props[lookup.label]?.internal) {
        throw new ConfigError(model.name,
          `x-lookup on "${field}" labels by "${lookup.label}", which is x-internal on "${target.name}" — a label is rendered wherever the relation is drawn`);
      }
      if (lookup.label in target.encrypted) {
        throw new ConfigError(model.name,
          `x-lookup on "${field}" labels by "${lookup.label}", which is encrypted on "${target.name}" — a picker cannot sort or search it`);
      }
    }
  }

  return models;
}
