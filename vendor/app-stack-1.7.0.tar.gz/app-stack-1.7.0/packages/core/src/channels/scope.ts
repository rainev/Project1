/**
 * Containment for host resources.
 *
 * `x-scope` filters rows: column -> expression -> an equality the adapter applies. That
 * shape cannot express "this path is inside the project", and the gate language cannot
 * either — gate expressions are JEXL over frozen plain data, deliberately unable to call
 * anything (§11). So a channel's root is contained here, in the runtime consumer, where
 * the filesystem can actually be consulted.
 *
 * The technique is BlitzPi's `guard-bash.js` zone ladder, ported: canonicalise first,
 * resolve symlinks, and compare resolved path to resolved root — never compare the
 * strings a caller supplied. The macOS trap that ladder documents applies here too:
 * `os.tmpdir()` resolves under `/private/var`, so a path can look like it is outside a
 * root and be inside it, or the reverse.
 */
import { realpathSync } from 'node:fs';
import { isAbsolute, resolve, sep } from 'node:path';

export class ContainmentError extends Error {
  readonly path: string;
  readonly root: string;
  constructor(detail: string, path: string, root: string) {
    super(`containment: ${detail}`);
    this.name = 'ContainmentError';
    this.path = path;
    this.root = root;
  }
}

/** Resolve as far as the filesystem allows; a path that does not exist yet still canonicalises. */
function canonical(target: string): string {
  try {
    return realpathSync(target);
  } catch {
    // The leaf may not exist (a file about to be written). Resolve the deepest existing
    // ancestor and re-append the rest, so a symlinked ancestor is still followed.
    const parts = resolve(target).split(sep);
    const tail: string[] = [];
    while (parts.length > 1) {
      tail.unshift(parts.pop()!);
      try {
        return resolve(realpathSync(parts.join(sep) || sep), ...tail);
      } catch { /* keep walking up */ }
    }
    return resolve(target);
  }
}

/**
 * Return the canonical path, or throw if it escapes the root.
 *
 * The root itself is allowed; everything checked is `root` or below it. A relative path
 * is refused outright rather than resolved against some ambient cwd — whose cwd it would
 * be is exactly the ambiguity an escape hides in.
 */
export function contain(target: string, root: string): string {
  if (!isAbsolute(root)) throw new ContainmentError('the root must be an absolute path', target, root);
  if (typeof target !== 'string' || target.length === 0) {
    throw new ContainmentError('no path given', String(target), root);
  }
  if (!isAbsolute(target)) throw new ContainmentError('the path must be absolute', target, root);

  const canonicalRoot = canonical(root);
  const canonicalTarget = canonical(target);

  if (canonicalTarget !== canonicalRoot && !canonicalTarget.startsWith(canonicalRoot + sep)) {
    throw new ContainmentError(
      `"${canonicalTarget}" is outside "${canonicalRoot}"`, canonicalTarget, canonicalRoot);
  }
  return canonicalTarget;
}

/** True when `target` is inside `root`; the non-throwing form, for filtering. */
export function contains(target: string, root: string): boolean {
  try {
    contain(target, root);
    return true;
  } catch {
    return false;
  }
}
