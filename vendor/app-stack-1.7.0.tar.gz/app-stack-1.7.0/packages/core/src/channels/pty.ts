/**
 * The `pty` channel runner — the only code in the framework that starts a process.
 *
 * Bun cannot use `node-pty`: the module loads, but no data flows and `resize` throws
 * `EBADF` (measured 2026-09-20, Bun 1.4.0; the identical script works under Node). So the
 * pty pair comes from libc's `openpty` through `bun:ffi`, and two things libc cannot give
 * us through a plain FFI declaration live in `../../native/`:
 *
 *  - **`libwinsize.dylib`** — `ioctl` is variadic, and Apple ARM64 passes variadic
 *    arguments on the stack, so a plain declaration hands the `struct winsize *` to a
 *    register the callee never reads. It returns 0 — success — having written nothing.
 *  - **`spawn-helper`** — `setsid` + `TIOCSCTTY` must run between fork and exec, and
 *    `Bun.spawn` has no hook there. Without it the child has no controlling terminal.
 *
 * Both are compiled at release time, never at runtime.
 */
import { dlopen, FFIType, ptr } from 'bun:ffi';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';

const NATIVE = fileURLToPath(new URL('../../native/', import.meta.url));

const SIGHUP = 1;
const SIGKILL = 9;

/**
 * The FFI is opened on FIRST USE, never on import.
 *
 * `app.ts` imports the channel runtime, which imports the runner table, which
 * imports this module — so every application loads this file whether or not it
 * declares a channel. Opening libc at module scope therefore ran on every boot,
 * and the path below is macOS-only: a deployment to Linux died at startup with
 * `Failed to open library "/usr/lib/libSystem.B.dylib"` before it read a line of
 * config, for an app that had no channel at all.
 *
 * Lazy means an app that declares no `x-channels` never touches libc, and one
 * that does gets a failure naming the platform rather than a dlopen error.
 */
type Libc = ReturnType<typeof openLibc>;
type Native = ReturnType<typeof openNative>;

/** libc by platform. Linux has no single stable soname for `openpty`; both are tried. */
const LIBC_CANDIDATES = process.platform === 'darwin'
  ? ['/usr/lib/libSystem.B.dylib']
  : ['libutil.so.1', 'libc.so.6'];

function openLibc() {
  const symbols = {
    openpty: { args: [FFIType.ptr, FFIType.ptr, FFIType.ptr, FFIType.ptr, FFIType.ptr], returns: FFIType.int },
    read: { args: [FFIType.int, FFIType.ptr, FFIType.u64], returns: FFIType.i64 },
    write: { args: [FFIType.int, FFIType.ptr, FFIType.u64], returns: FFIType.i64 },
    close: { args: [FFIType.int], returns: FFIType.int },
    kill: { args: [FFIType.int, FFIType.int], returns: FFIType.int },
  } as const;
  const failures: string[] = [];
  for (const candidate of LIBC_CANDIDATES) {
    try { return dlopen(candidate, symbols); }
    catch (error) { failures.push(`${candidate}: ${(error as Error).message}`); }
  }
  throw new PtyError(
    `a pty channel needs libc's openpty, and none of [${LIBC_CANDIDATES.join(', ')}] could be opened on ` +
    `${process.platform}. A channel declaring \`run: pty\` cannot start here — ${failures.join('; ')}`);
}

function openNative() {
  const library = join(NATIVE, process.platform === 'darwin' ? 'libwinsize.dylib' : 'libwinsize.so');
  try {
    return dlopen(library, {
      as_set_winsize: { args: [FFIType.int, FFIType.u16, FFIType.u16], returns: FFIType.int },
      as_get_rows: { args: [FFIType.int], returns: FFIType.int },
      as_get_cols: { args: [FFIType.int], returns: FFIType.int },
      /** `fcntl` is variadic — see the C file. Through FFI it silently sets nothing. */
      as_set_nonblocking: { args: [FFIType.int], returns: FFIType.int },
    });
  } catch (error) {
    throw new PtyError(
      `a pty channel needs the compiled helper at ${library}, which this release does not carry for ` +
      `${process.platform}-${process.arch} — ${(error as Error).message}`);
  }
}

let libcHandle: Libc | undefined;
let nativeHandle: Native | undefined;
const libcOf = (): Libc => (libcHandle ??= openLibc());
const nativeOf = (): Native => (nativeHandle ??= openNative());

/**
 * Secrets that must never reach a channel's process. The runner hands the child an
 * environment it built, not this process's own: app-stack holds the data-encryption key
 * and the database URL in memory, and a channel's process is arbitrary by design — that
 * is the whole point of a terminal. Blocking cannot un-leak a value already exported.
 */
const SENSITIVE = new Set([
  'APP_DEK', 'APP_DEK_ACTIVE', 'DATABASE_URL', 'JWT_SECRET', 'JWT_SECRET_FILE', 'PLATFORM_ADMINS',
]);
const SENSITIVE_SHAPE = /(^APP_DEK_)|(_(PASS|PASSWORD|SECRET|TOKEN|KEY)$)/i;

export function scrubEnv(base: Record<string, string | undefined>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const key of Object.keys(base)) {
    if (SENSITIVE.has(key) || SENSITIVE_SHAPE.test(key)) continue;
    const value = base[key];
    if (value !== undefined) out[key] = value;
  }
  return out;
}

export interface PtyOptions {
  command: string;
  args?: string[];
  cwd: string;
  cols?: number;
  rows?: number;
  /** Extra variables for the child, merged over the scrubbed parent environment. */
  env?: Record<string, string>;
}

export interface Pty {
  readonly pid: number;
  write(data: string): void;
  resize(cols: number, rows: number): void;
  /** What the child's terminal actually reports, read back from the kernel — not what we asked for. */
  size(): { cols: number; rows: number };
  /**
   * End the session. Signals the process GROUP, not the pid: `spawn-helper` called
   * `setsid`, so the child leads its own group, and a terminal's children are exactly
   * what a caller means by "stop this". Hangup first — **an interactive shell ignores
   * SIGTERM**, which is why a plain `kill()` looked like it did nothing — then SIGKILL
   * for anything still standing.
   */
  kill(): void;
  onData(handler: (chunk: string) => void): void;
  onExit(handler: (info: { exitCode: number }) => void): void;
}

export class PtyError extends Error {
  constructor(detail: string) {
    super(`pty: ${detail}`);
    this.name = 'PtyError';
  }
}

export function spawnPty(options: PtyOptions): Pty {
  const cols = options.cols ?? 120;
  const rows = options.rows ?? 32;

  const master = new Int32Array(1);
  const slave = new Int32Array(1);
  const nameBuffer = new Uint8Array(256);
  if (libcOf().symbols.openpty(ptr(master), ptr(slave), ptr(nameBuffer), null, null) !== 0) {
    throw new PtyError('openpty failed');
  }
  const terminator = nameBuffer.indexOf(0);
  const slavePath = new TextDecoder().decode(nameBuffer.subarray(0, terminator < 0 ? nameBuffer.length : terminator));

  // The initial size is set by spawn-helper on the slave, after its own open and before
  // exec — see that file for why doing it here instead leaves the child reading 0x0.

  const child = Bun.spawn(
    [join(NATIVE, 'spawn-helper'), slavePath, String(rows), String(cols), options.command, ...(options.args ?? [])],
    {
      cwd: options.cwd,
      env: { ...scrubEnv(process.env), TERM: 'xterm-256color', ...(options.env ?? {}) },
      stdin: 'ignore',
      stdout: 'ignore',
      stderr: 'ignore',
    },
  );

  // The slave is the child's now. Holding it open here would keep the master readable
  // forever after the child exits, so the stream would never end.
  libcOf().symbols.close(slave[0]);

  const dataHandlers: ((chunk: string) => void)[] = [];
  const exitHandlers: ((info: { exitCode: number }) => void)[] = [];
  let closed = false;

  /**
   * Read the master ourselves, rather than through `fs.createReadStream`.
   *
   * The stream form works in isolation and **silently stops flowing inside the server**:
   * it emits `readable` forever and never `data`, so a terminal opens, the process runs,
   * and not one byte reaches the socket. It turned on something as unrelated as whether
   * `process.stdin` had been resumed — which is not a thing a pty's correctness may
   * depend on. A non-blocking fd and an explicit interval have no such coupling.
   *
   * The interval backs off while the terminal is quiet, so an idle session costs a
   * 25ms timer rather than a spin.
   */
  if (nativeOf().symbols.as_set_nonblocking(master[0]) !== 0) {
    throw new PtyError('could not put the pty master in non-blocking mode');
  }
  const buffer = new Uint8Array(1 << 16);
  const decoder = new TextDecoder();
  let poll: ReturnType<typeof setInterval> | undefined;
  let idleFor = 0;

  const drain = () => {
    let read = 0;
    for (;;) {
      const n = Number(libcOf().symbols.read(master[0], ptr(buffer), BigInt(buffer.length)));
      if (n <= 0) break;
      read += n;
      const text = decoder.decode(buffer.subarray(0, n), { stream: true });
      for (const handler of dataHandlers) handler(text);
    }
    if (read > 0) {
      idleFor = 0;
      if (interval !== FAST) schedule(FAST);
    } else if (++idleFor > 40 && interval !== SLOW) {
      schedule(SLOW);
    }
  };

  const FAST = 5;
  const SLOW = 25;
  let interval = FAST;
  const schedule = (ms: number) => {
    if (poll) clearInterval(poll);
    interval = ms;
    poll = setInterval(drain, ms);
  };
  schedule(FAST);

  const finish = async () => {
    const exitCode = await child.exited;
    if (closed) return;
    // One last drain: the child's final output is in the buffer even though the child
    // is gone, and dropping it would lose the last line of every session.
    drain();
    closed = true;
    if (poll) clearInterval(poll);
    libcOf().symbols.close(master[0]);
    for (const handler of exitHandlers) handler({ exitCode });
  };
  void finish();

  return {
    pid: child.pid,
    write(data) {
      if (closed) return;
      const bytes = new TextEncoder().encode(data);
      libcOf().symbols.write(master[0], ptr(bytes), BigInt(bytes.length));
    },
    resize(nextCols, nextRows) {
      if (closed) return;
      if (!Number.isInteger(nextCols) || !Number.isInteger(nextRows) || nextCols <= 0 || nextRows <= 0) {
        throw new PtyError(`resize needs positive integers, got ${nextCols}x${nextRows}`);
      }
      nativeOf().symbols.as_set_winsize(master[0], nextRows, nextCols);
    },
    size() {
      return { cols: nativeOf().symbols.as_get_cols(master[0]), rows: nativeOf().symbols.as_get_rows(master[0]) };
    },
    kill() {
      if (closed) return;
      libcOf().symbols.kill(-child.pid, SIGHUP);
      setTimeout(() => {
        if (!closed) libcOf().symbols.kill(-child.pid, SIGKILL);
      }, 400);
    },
    onData(handler) { dataHandlers.push(handler); },
    onExit(handler) { exitHandlers.push(handler); },
  };
}
