/**
 * The channel runtime — the consumer that makes `x-channels` more than a declaration.
 *
 * One WebSocket per open channel. The socket is the framework's first long-lived
 * connection, so everything request/response got for free has to be decided here:
 *
 *  - **Who may open it.** A WebSocket upgrade is a GET, and browsers do not apply
 *    same-origin policy to `new WebSocket()` — `server.ts`'s `sameOrigin()` does not
 *    cover this path. The upgrade therefore checks the Origin itself AND a token minted
 *    per connection. Without both, any page the user visits could open a socket to
 *    localhost and drive whatever the channel runs.
 *  - **What may cross it.** Every frame is validated against the declared message
 *    schema, in both directions. A channel whose payloads are unchecked would be an
 *    untyped hole beside a typed model layer, which is the drift this framework reset over.
 *  - **Where it may run.** The root comes from the row, and goes through `scope.ts`
 *    before anything starts. A denial writes an audit line and starts no process.
 *  - **What a reconnect sees.** Recent output is buffered to the declared bound, so a
 *    dropped socket does not lose the scrollback.
 */
import type { ServerWebSocket } from 'bun';
import { ajv } from '../config/loader.ts';
import { BASE_ROOT, type Channel, type Model } from '../model.ts';
import type { Actor } from '../engine/types.ts';
import { homedir } from 'node:os';
import { isAbsolute, join } from 'node:path';
import { contain, ContainmentError } from './scope.ts';
import { runnerFor, type RunnerSession } from './runners.ts';

export interface ChannelAudit {
  timestamp: string;
  event: string;
  model: string;
  channel: string;
  sessionId?: string;
  actor?: string;
  decision: 'open' | 'deny' | 'close' | 'refuse';
  detail?: string;
}

export interface ChannelSocketData {
  model: Model;
  channel: Channel;
  channelName: string;
  rowId: string;
  actor: Actor;
  token: string;
}

/** A row lookup the runtime can use without importing the engine. */
export type RowReader = (model: Model, id: string, actor: Actor) =>
  Promise<Record<string, unknown> | undefined>;

interface LiveSession {
  runner: RunnerSession;
  /** Recent output, trimmed to the channel's declared bound. */
  replay: string;
  sockets: Set<ServerWebSocket<ChannelSocketData>>;
}

const MAX_FRAME_BYTES = 1 << 20;

/**
 * Message names the framework owns, in both directions, without a declaration.
 *
 * `error` and `exit` are the runtime's own vocabulary: every channel can fail and every channel
 * can end, so making an app declare them is a rule whose only effect is that someone forgets it.
 * And forgetting is silent in the worst way — a refusal the runtime emits would be dropped for
 * being undeclared, so a denied write would look to the client exactly like a successful one.
 * Measured: that is what happened before this existed. `stop` is the inbound half.
 */
const RESERVED_OUT = new Set(['error', 'exit']);
const RESERVED_IN = new Set(['stop']);

/**
 * The row id for a channel that has no row.
 *
 * A channel rooted at `$base` never reads the row — its root is server configuration. Requiring
 * one anyway creates a bootstrap nobody can satisfy: app-studio's folder browser is declared on
 * the session model, so choosing a folder would mean first creating the session whose folder you
 * are trying to choose. `-` says "no row", and it is accepted **only** for a `$base` channel;
 * anything else still needs a real row, read through the engine, with its gates.
 */
const NO_ROW = '-';

export interface ChannelRuntimeOptions {
  models: Map<string, Model>;
  readRow: RowReader;
  audit?: (entry: ChannelAudit) => void;
  /** Origins allowed to open a channel. A desktop shell serves the page from the same origin. */
  allowedOrigin?: (origin: string | null, url: URL) => boolean;
  /**
   * The base every channel root must sit under, from server configuration — never from
   * a row. Without it the containment check is circular: a row saying `/` would be
   * "contained" in `/`. Defaults to the user's home directory.
   */
  workspaceBase?: string;
}

export function createChannelRuntime(options: ChannelRuntimeOptions) {
  const validators = new WeakMap<object, ReturnType<typeof ajv.compile>>();
  /** One live session per row: a reconnect rejoins rather than starting a second process. */
  const sessions = new Map<string, LiveSession>();
  /** Tokens minted for a pending upgrade, spent on use. */
  const tokens = new Map<string, { model: string; channel: string; rowId: string; expires: number }>();

  const audit = (entry: ChannelAudit) => options.audit?.(entry);
  const workspaceBase = options.workspaceBase ?? homedir();

  const validatorFor = (schema: object) => {
    let compiled = validators.get(schema);
    if (!compiled) {
      compiled = ajv.compile(schema);
      validators.set(schema, compiled);
    }
    return compiled;
  };

  /**
   * Mint a single-use token for one channel on one row. The desktop shell fetches this
   * over the ordinary, same-origin-checked HTTP surface, then opens the socket with it.
   */
  function mintToken(model: string, channel: string, rowId: string): string {
    const token = crypto.randomUUID();
    tokens.set(token, { model, channel, rowId, expires: Date.now() + 30_000 });
    return token;
  }

  function spendToken(token: string | null, model: string, channel: string, rowId: string): boolean {
    if (!token) return false;
    const minted = tokens.get(token);
    if (!minted) return false;
    tokens.delete(token);
    if (minted.expires < Date.now()) return false;
    return minted.model === model && minted.channel === channel && minted.rowId === rowId;
  }

  const key = (model: string, channel: string, rowId: string) => `${model}/${rowId}/${channel}`;

  function send(socket: ServerWebSocket<ChannelSocketData>, message: string, payload: unknown) {
    socket.send(JSON.stringify({ message, payload }));
  }

  return {
    mintToken,

    /** Route match for `/v0/channel/<model>/<id>/<channel>`. */
    parsePath(pathname: string, prefix: string) {
      if (!pathname.startsWith(`${prefix}channel/`)) return undefined;
      const [model, rowId, channel, ...rest] = pathname.slice(`${prefix}channel/`.length).split('/');
      if (!model || !rowId || !channel || rest.length) return undefined;
      return { model, rowId, channel };
    },

    /**
     * The checks a token request needs: the channel exists and this actor may use it.
     * Deliberately the same role test the upgrade applies — a token is not a way to get
     * a channel you could not have opened, only a way to prove the socket is yours.
     */
    async authorizeToken(actor: Actor | undefined,
                         target: { model: string; rowId: string; channel: string }): Promise<Response | undefined> {
      const deny = (status: number, detail: string) => {
        audit({ timestamp: new Date().toISOString(), event: 'token', model: target.model,
                channel: target.channel, sessionId: target.rowId, actor: actor?.id,
                decision: 'refuse', detail });
        return new Response(JSON.stringify({ error: 'forbidden', detail }), {
          status, headers: { 'content-type': 'application/json' } });
      };
      const model = options.models.get(target.model);
      if (!model) return deny(404, `no model "${target.model}"`);
      const channel = model.channels[target.channel];
      if (!channel) return deny(404, `model "${target.model}" declares no channel "${target.channel}"`);
      if (!actor) return deny(401, 'no actor');
      if (!channel.roles.some((role) => actor.roles.includes(role))) {
        return deny(403, `channel "${target.channel}" requires one of: ${channel.roles.join(', ')}`);
      }
      return undefined;
    },

    /**
     * Decide an upgrade. Returns the socket data to attach, or a Response refusing it.
     * **Both** the origin check and the token are required: either alone is a door.
     */
    async authorize(request: Request, url: URL, actor: Actor | undefined,
                    target: { model: string; rowId: string; channel: string }):
      Promise<{ data: ChannelSocketData } | Response> {

      const refuse = (status: number, detail: string) => {
        audit({ timestamp: new Date().toISOString(), event: 'upgrade', model: target.model,
                channel: target.channel, sessionId: target.rowId, actor: actor?.id,
                decision: 'refuse', detail });
        return new Response(JSON.stringify({ error: 'forbidden', detail }), {
          status, headers: { 'content-type': 'application/json' } });
      };

      const origin = request.headers.get('origin');
      const originOk = options.allowedOrigin
        ? options.allowedOrigin(origin, url)
        : origin === null || origin === url.origin;
      if (!originOk) return refuse(403, `cross-origin channel upgrade refused (origin: ${origin})`);

      if (!spendToken(url.searchParams.get('token'), target.model, target.channel, target.rowId)) {
        return refuse(403, 'missing or spent channel token');
      }

      const model = options.models.get(target.model);
      if (!model) return refuse(404, `no model "${target.model}"`);
      const channel = model.channels[target.channel];
      if (!channel) return refuse(404, `model "${target.model}" declares no channel "${target.channel}"`);
      if (!actor) return refuse(401, 'no actor');
      if (!channel.roles.some((role) => actor.roles.includes(role))) {
        return refuse(403, `channel "${target.channel}" requires one of: ${channel.roles.join(', ')}`);
      }

      return { data: { model, channel, channelName: target.channel, rowId: target.rowId, actor, token: '' } };
    },

    /**
     * Bun's websocket handlers.
     *
     * Every one of these is wrapped: a throw inside a socket handler is not caught by
     * `fetch`'s try/catch and **takes the whole server down with it** — observed once,
     * from a single bad row lookup. A channel is one connection; it may fail, and the
     * process it belongs to may die, but the server serves everyone.
     */
    handlers: {
      async open(socket: ServerWebSocket<ChannelSocketData>) {
        try { await openChannel(socket); }
        catch (error) {
          const detail = (error as Error).message;
          audit({ timestamp: new Date().toISOString(), event: 'open', model: socket.data.model.name,
                  channel: socket.data.channelName, sessionId: socket.data.rowId,
                  actor: socket.data.actor.id, decision: 'deny', detail });
          try { send(socket, 'error', { detail }); socket.close(1011, 'channel failed'); } catch { /* gone */ }
        }
      },

      message(socket: ServerWebSocket<ChannelSocketData>, raw: string | Buffer) {
        try { onMessage(socket, raw); }
        catch (error) {
          try { send(socket, 'error', { detail: (error as Error).message }); } catch { /* gone */ }
        }
      },

      close(socket: ServerWebSocket<ChannelSocketData>) {
        try { onClose(socket); } catch { /* the session is going away regardless */ }
      },
    },

    /** Kill every live session — the server is going down and its children go with it. */
    shutdown() {
      for (const [id, live] of sessions) {
        try { live.runner.kill(); } catch { /* already gone */ }
        sessions.delete(id);
      }
    },
  };

  // The handler bodies. Function declarations, so they hoist above the object that
  // wraps them.
  async function openChannel(socket: ServerWebSocket<ChannelSocketData>) {
        const { model, channel, channelName, rowId, actor } = socket.data;
        const id = key(model.name, channelName, rowId);
        const existing = sessions.get(id);
        if (existing) {
          // A reconnect: rejoin the live process and replay what it said meanwhile.
          existing.sockets.add(socket);
          if (existing.replay) send(socket, 'output', { data: existing.replay });
          audit({ timestamp: new Date().toISOString(), event: 'reconnect', model: model.name,
                  channel: channelName, sessionId: rowId, actor: actor.id, decision: 'open' });
          return;
        }

        const rowless = channel.root === BASE_ROOT && rowId === NO_ROW;
        const row = rowless ? {} : await options.readRow(model, rowId, actor);
        if (!row) {
          send(socket, 'error', { message: 'open', detail: `no ${model.name} "${rowId}"` });
          socket.close(1008, 'no such row');
          return;
        }

        // The root is a value from a row, and a row is data. It is only allowed to name
        // a place under the server's configured base — checked against the filesystem,
        // symlinks resolved, never against the string the row supplied. `$base` is the
        // exception the declaration had to spell out: the base itself, which no row names.
        let root: string;
        try {
          if (channel.root === BASE_ROOT) {
            root = contain(workspaceBase, workspaceBase);
          } else {
            // A relative root is read against the base. The browser hands back paths relative to
            // the channel root — it is never told the absolute one, so that the root cannot leak
            // into a client — and a row written from that listing would otherwise be unusable.
            const asked = String(row[channel.root] ?? '');
            root = contain(isAbsolute(asked) ? asked : join(workspaceBase, asked), workspaceBase);
          }
        } catch (error) {
          const detail = error instanceof ContainmentError ? error.message : String(error);
          audit({ timestamp: new Date().toISOString(), event: 'contain', model: model.name,
                  channel: channelName, sessionId: rowId, actor: actor.id, decision: 'deny', detail });
          send(socket, 'error', { detail });
          socket.close(1008, 'containment');
          return;
        }

        let runner: RunnerSession;
        try {
          runner = runnerFor(channel.run).start({
            root, provider: String(row[channel.provider] ?? ''), channel });
        } catch (error) {
          const detail = (error as Error).message;
          audit({ timestamp: new Date().toISOString(), event: 'start', model: model.name,
                  channel: channelName, sessionId: rowId, actor: actor.id, decision: 'deny', detail });
          send(socket, 'error', { detail });
          socket.close(1011, 'runner');
          return;
        }

        const live: LiveSession = { runner, replay: '', sockets: new Set([socket]) };
        sessions.set(id, live);

        runner.onOutput((message, payload) => {
          if (RESERVED_OUT.has(message)) {
            for (const open of live.sockets) send(open, message, payload);
            return;
          }
          const declared = channel.messages[message];
          if (!declared || declared.direction !== 'out') return;
          if (!validatorFor(declared.schema)(payload)) return;   // never emit what the declaration disallows
          if (message === 'output' && typeof payload.data === 'string') {
            live.replay = (live.replay + payload.data).slice(-channel.replayBytes);
          }
          for (const open of live.sockets) send(open, message, payload);
        });

        runner.onExit((info) => {
          for (const open of live.sockets) {
            send(open, 'exit', info);
            open.close(1000, 'exited');
          }
          sessions.delete(id);
          audit({ timestamp: new Date().toISOString(), event: 'exit', model: model.name,
                  channel: channelName, sessionId: rowId, actor: actor.id, decision: 'close',
                  detail: `exitCode ${info.exitCode}` });
        });

        audit({ timestamp: new Date().toISOString(), event: 'open', model: model.name,
                channel: channelName, sessionId: rowId, actor: actor.id, decision: 'open',
                detail: `pid ${runner.pid} in ${root}` });
  }

  function onMessage(socket: ServerWebSocket<ChannelSocketData>, raw: string | Buffer) {
        const { model, channel, channelName, rowId } = socket.data;
        const live = sessions.get(key(model.name, channelName, rowId));
        if (!live) return;

        const text = typeof raw === 'string' ? raw : raw.toString('utf8');
        if (text.length > MAX_FRAME_BYTES) {
          send(socket, 'error', { message: 'frame', detail: 'frame too large' });
          return;
        }

        let frame: { message?: string; payload?: unknown };
        try { frame = JSON.parse(text); }
        catch { send(socket, 'error', { message: 'frame', detail: 'frame is not JSON' }); return; }

        const declared = frame.message ? channel.messages[frame.message] : undefined;
        if (frame.message && RESERVED_IN.has(frame.message) && !declared) {
          if (frame.message === 'stop') live.runner.kill();
          return;
        }
        if (!declared || declared.direction !== 'in') {
          send(socket, 'error', { message: frame.message ?? null, detail: `"${frame.message}" is not an inbound message of this channel` });
          return;
        }
        const validate = validatorFor(declared.schema);
        if (!validate(frame.payload ?? {})) {
          send(socket, 'error', { message: frame.message, detail: `payload for "${frame.message}" does not match its declared schema` });
          return;
        }

        // `stop` is the one inbound message the runtime answers itself: ending a session
        // is not something a runner should have to implement, and every runner needs it.
        if (frame.message === 'stop') {
          live.runner.kill();
          return;
        }

        try {
          live.runner.receive(frame.message!, (frame.payload ?? {}) as Record<string, unknown>);
        } catch (error) {
          send(socket, 'error', { message: frame.message, detail: (error as Error).message });
        }
  }

  function onClose(socket: ServerWebSocket<ChannelSocketData>) {
        const { model, channelName, rowId } = socket.data;
        const live = sessions.get(key(model.name, channelName, rowId));
        if (!live) return;
        live.sockets.delete(socket);
        // The process outlives a dropped socket on purpose: that is what makes a
        // reconnect a reconnect. `stop` ends it, and so does the process exiting.
  }
}
