/**
 * Channel runners — framework capabilities a declaration picks **by name**.
 *
 * This is the `db/engines.ts` / `notify/providers.ts` pattern, not the handler pattern.
 * A handler is `path#namedExport`: app code, trusted, unsandboxed, resolved from the
 * app's own files. A channel starts a process, so an app that could name its own runner
 * could start anything — and an app whose entire source is YAML could not ship one
 * anyway. `run: pty` is a capability the framework offers; `handler: ./x.ts#run` is code
 * the app ships. Only the first may ever appear in a channel.
 *
 * Which *program* a `pty` channel runs is likewise not free text. The declaration names
 * the model property holding a **provider id**, and the id resolves here. A terminal is
 * arbitrary execution by definition — that is what it is for — but the choice of what
 * starts is a framework decision, made once, rather than a string an app supplies.
 */
import type { Channel } from '../model.ts';
import { browseRunner, filesRunner } from './files.ts';
import { spawnPty } from './pty.ts';

export interface RunnerContext {
  /** The contained, canonical root this session runs in — already checked by `scope.ts`. */
  root: string;
  /** The provider id read from the session row. */
  provider: string;
  channel: Channel;
}

export interface RunnerSession {
  readonly pid: number;
  /** Deliver one declared inbound message. Its payload is already schema-validated. */
  receive(message: string, payload: Record<string, unknown>): void;
  kill(): void;
  onOutput(handler: (message: string, payload: Record<string, unknown>) => void): void;
  onExit(handler: (info: { exitCode: number }) => void): void;
}

export interface ChannelRunner {
  readonly id: string;
  start(context: RunnerContext): RunnerSession;
}

export class RunnerError extends Error {
  constructor(detail: string) {
    super(`channel runner: ${detail}`);
    this.name = 'RunnerError';
  }
}

/**
 * Not every runner starts a process — `files` is the framework itself, reading and writing
 * inside the same contained root a `pty` would run in. `provider` is meaningless to it, which
 * is why the declaration still names one: one shape for every channel, checked the same way.
 */

/**
 * What a provider id starts. Adding one is a framework change and a release — which is
 * the point: the set of programs a channel can start is reviewable in one place.
 */
const PROVIDERS: Record<string, { command: string; args: string[] }> = {
  blitzpi: { command: 'blitzpi', args: [] },
  shell: { command: '/bin/sh', args: ['-l'] },
};

export const PROVIDER_IDS = Object.keys(PROVIDERS);

const ptyRunner: ChannelRunner = {
  id: 'pty',
  start(context) {
    const provider = PROVIDERS[context.provider];
    if (!provider) {
      throw new RunnerError(
        `unknown provider "${context.provider}" — the framework supplies: ${PROVIDER_IDS.join(', ')}`);
    }

    const pty = spawnPty({
      command: provider.command,
      args: provider.args,
      cwd: context.root,
      cols: 120,
      rows: 32,
    });

    return {
      pid: pty.pid,
      receive(message, payload) {
        // The message NAMES are the declaration's; what each does is the runner's
        // contract. `input` and `resize` are what a pty understands.
        if (message === 'input') pty.write(String(payload.data ?? ''));
        else if (message === 'resize') pty.resize(Number(payload.cols), Number(payload.rows));
        else throw new RunnerError(`the pty runner has nothing to do with message "${message}"`);
      },
      kill() { pty.kill(); },
      onOutput(handler) { pty.onData((data) => handler('output', { data })); },
      onExit(handler) { pty.onExit(handler); },
    };
  },
};

const RUNNERS: Record<string, ChannelRunner> = { pty: ptyRunner, files: filesRunner, browse: browseRunner };

export function runnerFor(id: string): ChannelRunner {
  const runner = RUNNERS[id];
  if (!runner) throw new RunnerError(`unknown runner "${id}"`);
  return runner;
}
