/**
 * The `files` channel runner — reading and writing inside a contained root.
 *
 * **Why a runner and not a model.** `APP-STUDIO-ARCHITECTURE.md` proposed a `file` model on the
 * ordinary gates. That reading is still the right instinct — files are a resource, and resources
 * are models here — but it does not survive contact with `x-storage`: storage in this framework
 * means a SQL table, and every op goes through `DBAdapter`. A filesystem-backed model therefore
 * means a second persistence path beside the one the engine has, which is a far larger change
 * than "the studio can open a file".
 *
 * A channel needs none of that. The containment check, the declared roles, the audit line and the
 * per-message schemas already exist and are already proven, and this reuses all four. What it
 * gives up is the generic API surface: a file is reached over its project's socket rather than at
 * `/v0/<action>/<model>`. For an editor in a desktop window that is no loss — the same socket
 * already carries the terminal.
 *
 * **Every path is contained on every message**, not once when the channel opens. The root is
 * fixed at open time; a path that arrives later is resolved and checked against it again, because
 * a message is data from a client and the client is not the authority on where it may write.
 */
import { mkdir, readdir, readFile, stat, writeFile } from 'node:fs/promises';
import { dirname, join, relative } from 'node:path';
import type { ChannelRunner, RunnerSession } from './runners.ts';
import { contain, ContainmentError } from './scope.ts';

/** A file this channel will hand over whole. Bigger than an editor should open in one message. */
const MAX_BYTES = 2 * 1024 * 1024;

export interface FileEntry {
  name: string;
  /** Always relative to the channel's root — an absolute path would leak where the root is. */
  path: string;
  kind: 'file' | 'directory';
  bytes?: number;
  modified?: string;
}

async function listDirectory(root: string, target: string): Promise<FileEntry[]> {
  const entries = await readdir(target, { withFileTypes: true });
  const out: FileEntry[] = [];
  for (const entry of entries) {
    const full = join(target, entry.name);
    let bytes: number | undefined;
    let modified: string | undefined;
    if (entry.isFile()) {
      try {
        const info = await stat(full);
        bytes = info.size;
        modified = info.mtime.toISOString();
      } catch { /* vanished between readdir and stat: report it without size */ }
    }
    out.push({
      name: entry.name,
      path: relative(root, full),
      kind: entry.isDirectory() ? 'directory' : 'file',
      ...(bytes === undefined ? {} : { bytes }),
      ...(modified === undefined ? {} : { modified }),
    });
  }
  // Directories first, then by name — the order a tree wants, decided here so every
  // client shows the same thing.
  return out.sort((a, b) =>
    a.kind === b.kind ? a.name.localeCompare(b.name) : a.kind === 'directory' ? -1 : 1);
}

function fileSession(context: { root: string }, allow: { read: boolean; write: boolean }): RunnerSession {
    const root = context.root;                    // already contained by the runtime
    const emit: ((message: string, payload: Record<string, unknown>) => void)[] = [];
    const exited: ((info: { exitCode: number }) => void)[] = [];
    const send = (message: string, payload: Record<string, unknown>) => {
      for (const handler of emit) handler(message, payload);
    };

    /** Resolve a client-supplied path inside the root, or refuse it. */
    const resolve = (raw: unknown): string => {
      const asked = String(raw ?? '');
      // A relative path is the client's normal case; make it absolute against the root
      // before containment, which only accepts absolute paths on purpose.
      const candidate = asked.startsWith('/') ? asked : join(root, asked);
      return contain(candidate, root);
    };

    const refuse = (message: string, error: unknown) => {
      const detail = error instanceof ContainmentError ? error.message : (error as Error).message;
      send('error', { message, detail });
    };

    return {
      pid: 0,   // no process: this runner is the framework itself
      receive(message, payload) {
        void (async () => {
          try {
            switch (message) {
              case 'list': {
                const target = resolve(payload.path ?? '.');
                send('listing', { path: relative(root, target) || '.', entries: await listDirectory(root, target) });
                return;
              }
              case 'read': {
                if (!allow.read) { send('error', { message, detail: 'this channel lists only — it does not read file contents' }); return; }
                const target = resolve(payload.path);
                const info = await stat(target);
                if (info.size > MAX_BYTES) {
                  send('error', { message, detail: `"${relative(root, target)}" is ${info.size} bytes; this channel hands over at most ${MAX_BYTES}` });
                  return;
                }
                send('content', { path: relative(root, target), data: await readFile(target, 'utf8') });
                return;
              }
              case 'write': {
                if (!allow.write) { send('error', { message, detail: 'this channel lists only — it does not write' }); return; }
                const target = resolve(payload.path);
                const data = String(payload.data ?? '');
                // The parent is created, but only inside the root — `contain` above already
                // refused anything else, so this cannot mkdir its way out.
                await mkdir(dirname(target), { recursive: true });
                await writeFile(target, data, 'utf8');
                send('wrote', { path: relative(root, target), bytes: Buffer.byteLength(data) });
                return;
              }
              default:
                send('error', { message, detail: `the files runner has nothing to do with message "${message}"` });
            }
          } catch (error) {
            refuse(message, error);
          }
        })();
      },
      kill() {
        for (const handler of exited) handler({ exitCode: 0 });
      },
      onOutput(handler) { emit.push(handler); },
      onExit(handler) { exited.push(handler); },
    } satisfies RunnerSession;
}

export const filesRunner: ChannelRunner = {
  id: 'files',
  start: (context) => fileSession(context, { read: true, write: true }),
};

/**
 * `browse` — the same code with both hands tied.
 *
 * It exists to answer one question: *which folder do you want to open?* That question reaches
 * outside every project root by definition, which is exactly why it gets the least power of
 * anything in the framework: **list only, no read, no write**, rooted at the server's
 * `--workspace-base` via `root: $base`. A picker needs names and shapes, never contents.
 *
 * The narrower gate is the point. Everything else is contained under one project; this one is
 * contained under the base, so if it could read it could read every project on the machine.
 */
export const browseRunner: ChannelRunner = {
  id: 'browse',
  start: (context) => fileSession(context, { read: false, write: false }),
};
