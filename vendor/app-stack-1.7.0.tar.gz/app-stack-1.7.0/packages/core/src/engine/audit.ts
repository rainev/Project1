/**
 * How a request ended — one classification shared by the wire and the audit
 * record, so the two can never disagree (batch 08, AUD-046).
 */
import type { DBAdapter } from '../db/adapter.ts';
import { BadRequest, DecryptionFailure, Denied, NotFound, ValidationFailure } from '../errors.ts';
import { AUDIT } from '../auth/system-models.ts';
import type { Envelope } from './types.ts';

export type Outcome = 'ok' | 'invalid' | 'denied' | 'not_found' | 'error';

export interface Described {
  outcome: Outcome;
  status: number;
  /** Detail safe to store and, where the body carries it, to return. */
  detail?: string;
  /** The JSON body the caller receives. */
  body: Record<string, unknown>;
}

/** Classify an error once; the audit row and the response both read this. */
export function describeError(error: unknown, meta: Envelope['meta']): Described {
  if (error === undefined) return { outcome: 'ok', status: 200, body: {} };
  if (error instanceof ValidationFailure) {
    return { outcome: 'invalid', status: 422, body: { error: 'validation_failed', errors: error.errors } };
  }
  if (error instanceof Denied) {
    return { outcome: 'denied', status: 403, detail: error.reason, body: { error: 'forbidden', detail: error.reason, meta } };
  }
  if (error instanceof NotFound) {
    return { outcome: 'not_found', status: 404, body: { error: error.message || 'not_found' } };
  }
  if (error instanceof BadRequest) {
    return { outcome: 'invalid', status: 400, detail: error.message, body: { error: 'bad_request', detail: error.message } };
  }
  if (error instanceof DecryptionFailure) {
    // Loud and specific server-side; nothing but a code and a request id to the caller.
    console.error(`[${meta.requestId}] DECRYPTION FAILURE model=${error.model} field=${error.field} row=${error.rowId} — ciphertext moved, tampered, or wrong key`);
    return { outcome: 'error', status: 500, body: { error: 'decryption_failed', requestId: meta.requestId } };
  }
  // Anything else is a fault on our side — a handler that threw, a driver error.
  // Log it in full; tell the client nothing about our internals.
  console.error(`[${meta.requestId}] unhandled:`, error);
  return { outcome: 'error', status: 500, body: { error: 'internal_error', requestId: meta.requestId } };
}

export type Attempted = Pick<Envelope, 'actor' | 'op' | 'model' | 'id' | 'data' | 'meta'>;

/**
 * One record per request, written after the transaction has settled so a
 * rollback or a denial still leaves a trace (§6). Best-effort by design: it
 * must never turn a successful request into a failed one, so a failure to
 * write is logged and swallowed.
 */
export function createAuditWriter(db: DBAdapter) {
  return async function audit(entry: {
    envelope: Attempted; error?: unknown; status?: number;
    /**
     * How it ended, when there is no error object to classify.
     *
     * The outbox worker is the caller that needs it (WP-06 W-110): a delivery
     * that failed is a real outcome and must not read as `ok`, but handing
     * `describeError` the handler's exception would log it as an unhandled
     * fault when it is a counted attempt about to be retried.
     */
    outcome?: Outcome;
    /**
     * What to record when the request did NOT fail but the record would
     * otherwise say nothing: fields the write gate dropped (WP-02 H-120), or a
     * batch element that ran and was then rolled back (H-121). An error's own
     * detail always wins — it is the more specific fact.
     */
    detail?: string;
  }) {
    const { envelope, error } = entry;
    const described = describeError(error, envelope.meta);
    // The status actually sent, so the record cannot disagree with the wire.
    const status = entry.status ?? described.status;
    const outcome = entry.outcome ?? described.outcome;
    try {
      await db.systemCreate(AUDIT, {
        orgId: envelope.actor.orgId,
        requestId: envelope.meta.requestId,
        source: envelope.meta.source,
        actorId: envelope.actor.id,
        actorRoles: envelope.actor.roles.join(','),
        op: envelope.op,
        model: envelope.model,
        rowId: envelope.id ?? null,
        // Names only. A value here would undo §8 one row away from the ciphertext.
        fields: Object.keys(envelope.data ?? {}).join(',') || null,
        outcome,
        status,
        detail: described.detail ?? entry.detail ?? null,
        at: envelope.meta.at,
      });
    } catch (auditError) {
      console.error(`[${envelope.meta.requestId}] audit write failed:`, auditError);
    }
  };
}
