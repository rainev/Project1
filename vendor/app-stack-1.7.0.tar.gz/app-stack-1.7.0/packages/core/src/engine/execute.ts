/**
 * The engine: one execution path for every operation (ARCHITECTURE §16).
 *
 * Everything inbound has already been reduced to an envelope by the intake
 * (`http/intake.ts`); this is the only place an operation runs. `ctx.call`
 * re-enters this same function, so a hook composing another operation passes
 * the same gates — there is no privileged internal door.
 */
import type { AggregateSpec, DBAdapter, Row } from '../db/adapter.ts';
import { describeHandler, type HandlerRegistry } from '../handlers/index.ts';
import type { FileAdapter, FileDescriptor } from '../files/adapter.ts';
import { allowsAction, canRead, canWrite, filterWrite, makeView, projectRead, resolveScope, type GateView } from '../gates.ts';
import { assertWithinLimits } from './guards.ts';
import { BUILTIN_OPS, WRITE_OPS, eventFor, hookPoint, type Model } from '../model.ts';
import { deriveSchema, validate } from '../schema.ts';
import type { KeyProvider } from '../crypto/keys.ts';
import { assertAggregatable, decryptRow, encryptInput, rewriteFilters, uniquenessProbe } from '../crypto/pipeline.ts';
import { BadRequest, Denied, NotFound, ValidationFailure } from '../errors.ts';
import { STAGE_PREFIX } from './types.ts';
import { OUTBOX, outboxRow } from '../events/model.ts';
import { AUDIT } from '../auth/system-models.ts';
import { eventListeners } from '../events/outbox.ts';
import type { ActionContext, Actor, EmittedEvent, Envelope, HookResult, StagedFile } from './types.ts';
import type { Query as DeclaredQuery } from '../queries/compile.ts';

export { BUILTIN_OPS };
const MAX_CALL_DEPTH = 5;
/**
 * How much of one row's history comes back.
 *
 * A timeline is for reading, and a row with ten thousand audit entries is a row
 * whose story is told by the first fifty. `systemList` has no ordering or limit
 * of its own — that would be `db/**` — so the cap is applied here, after an
 * equality-filtered read that is already narrow: one org, one model, one row.
 */
const HISTORY_LIMIT = 50;

export interface EngineOptions {
  models: Map<string, Model>;
  /**
   * Where a row written by an actor with no org of their own lands (WP-07).
   *
   * A visitor has no org — that is what makes public reads work — but every row
   * needs one, so an anonymous write has to be told. The DEFAULT org is the
   * answer for a single-tenant deployment and an arbitrary one the day there is
   * a second; that day needs the request's host to name a tenant, which is a
   * larger change than this.
   */
  defaultOrgId?: string;
  /** Declared queries (§7.1). Absent means the app declared none. */
  queries?: Map<string, DeclaredQuery>;
  handlers: HandlerRegistry;
  keys: KeyProvider;
  files?: FileAdapter;
  /**
   * Told that this transaction buffered events, so a worker can look sooner
   * than its interval (WP-06 W-110).
   *
   * Called while the transaction is still open, deliberately: the engine knows
   * what it wrote, not when it commits. So this is a hint and never a delivery
   * signal — a pass that arrives before the commit finds nothing and the next
   * one finds it. Correctness is the worker's interval; this is latency.
   */
  onEmit?: () => void;
}

export interface DispatchOptions extends EngineOptions {
  version: string;
  db: DBAdapter;
  resolveActor: (request: Request) => Promise<Actor | undefined> | Actor | undefined;
}

async function uniquenessErrors(
  keys: KeyProvider, db: DBAdapter, model: Model, scope: Record<string, unknown>, orgId: string, data: Row, exceptId?: string,
) {
  const errors = [];
  for (const field of model.unique) {
    if (data[field] === undefined) continue;
    const probe = await uniquenessProbe(keys, model, orgId, field, data[field]);
    if (await db.existsWith(model, scope, { [probe.field]: probe.value }, exceptId)) {
      errors.push({ path: `/${field}`, keyword: 'unique', message: 'must be unique' });
    }
  }
  return errors;
}

export function createEngine(options: EngineOptions) {
  const { models, handlers, keys } = options;

  /**
   * One transition has authorised exactly one write of the state field.
   *
   * Recorded while the transition's own handler runs and dropped the moment it
   * returns, so the permission is as narrow as it can be: this model, this row,
   * this target state, for the length of this operation. A sibling in the same
   * batch cannot borrow it.
   */
  interface StateWrite { model: string; id?: string; to: unknown }

  /**
   * What every operation on one transaction shares.
   *
   * One object rather than one parameter each, because the list only grows: the
   * events buffered so far, and the state writes a transition has authorised.
   */
  interface Inflight { emitted: EmittedEvent[]; transitions: StateWrite[] }

  /**
   * The state field belongs to the lifecycle, not to the caller (WP-06).
   *
   * A model that declares `x-states` has made that field framework-owned in the
   * same sense `id` and `orgId` are: it has a declared set of legal moves, each
   * with its own `from`, `require` and `access`, and a plain `update` that sets
   * it would go around all three. It did, until this existed — `x-access.write`
   * was the only gate on the update path, so a transition's `access` was worth
   * exactly as much as the weakest way to write the same column, and there is
   * always an update path.
   *
   * So the refusal is here, in the framework, and not per model in
   * `x-field-access`: every lifecycle would otherwise have to remember, and one
   * that forgot would look identical to one that had decided not to.
   *
   * It is a REFUSAL and not a silent drop. A caller who sent the field asked for
   * something, and dropping it would answer 200 while doing something else —
   * the papercut AUD-059 already made the framework stop committing.
   */
  function assertLifecycleWrite(
    model: Model, data: Row, id: string | undefined, inflight: Inflight, op: string,
  ): void {
    const states = model.states;
    if (!states || !(states.field in data)) return;
    const target = data[states.field];
    const authorised = inflight.transitions.some((t) =>
      t.model === model.name && t.to === target && (t.id === undefined || t.id === id));
    if (authorised) return;
    const moves = Object.keys(states.transitions).join(', ');
    throw new ValidationFailure([{
      path: `/${states.field}`,
      keyword: 'state',
      message: op === 'create'
        ? `"${states.field}" starts at "${states.initial}" and changes only through a transition — ${moves}`
        : `"${states.field}" changes only through a transition — ${moves}`,
    }]);
  }

  /**
   * Which event names anything is listening for (`x-events`, W-111/W-112).
   *
   * A builtin event with no listener writes NO outbox row. Emitting one per
   * write regardless would put a row in `_outbox` for every create in the
   * system, forever, so that a worker could discover there is nothing to do —
   * cost with no consumer. An explicit `ctx.emit` from code is different and is
   * always written: that one is an instruction, not a derivation.
   */
  const listeners = eventListeners(models);

  /**
   * Run every handler bound to a lifecycle point. A hook may patch, deny, or
   * skip the rest.
   *
   * A handler is whatever the model declared — a `path#export` string or a
   * declaration object — and the registry hands back a function either way.
   * Nothing here knows which kind it is running (§13, WP-02 H-103).
   */
  async function runHooks(point: string, ctx: ActionContext, target: 'data' | 'result'): Promise<void> {
    for (const declared of ctx.model.hooks[point] ?? []) {
      const handler = handlers.get(declared);
      if (!handler) throw new Error(`handler ${describeHandler(declared)} was not bound at boot`);
      const outcome = (await handler(ctx)) as HookResult;
      if (!outcome) continue;
      if ('deny' in outcome && outcome.deny) throw new Denied(outcome.deny);
      if ('skip' in outcome && outcome.skip) return;
      if ('patch' in outcome && outcome.patch) {
        if (target === 'data') Object.assign(ctx.data, outcome.patch);
        else Object.assign(ctx.result as Row, outcome.patch);
      }
    }
  }

  /**
   * Apply the field-write gate and say what it did (WP-02 H-120, AUD-059).
   *
   * A refused field used to vanish: the write succeeded, the value was not
   * there, and nothing on the wire or in the audit row said why. Now the names
   * are collected on the request — including from a nested `ctx.call`, because
   * a hook's write being trimmed is exactly as invisible — and the intake puts
   * them in `meta.denied`. A field declared `onDenied: reject` fails the
   * request instead, which is a 422 naming the field like any other.
   */
  function applyWriteGate(model: Model, acting: GateView, data: Row, denied?: string[]): Row {
    const filtered = filterWrite(model, acting, data);
    if (filtered.rejected.length) {
      throw new ValidationFailure(filtered.rejected.map((field) => ({
        path: `/${field}`, keyword: 'write', message: 'you may not write this field',
      })));
    }
    for (const field of filtered.denied) if (!denied?.includes(field)) denied?.push(field);
    return filtered.allowed;
  }

  /**
   * The outermost operation of one transaction (W-110).
   *
   * Everything the operation emitted is written to `_outbox` HERE — after the
   * work, still on the caller's transaction handle, so the fact and the intent
   * to act on it commit together or roll back together. That is the whole
   * property: there is no window in which the row exists and the event does
   * not, and none in which the event exists and the row does not.
   *
   * `ctx.call` re-enters `run`, not this, so a nested operation contributes to
   * the same buffer and does not open a second one. A batch calls this per
   * element on the SHARED transaction, so an element that rolls back takes its
   * events with it.
   */
  async function execute(
    envelope: Envelope, tx: DBAdapter, depth: number,
    staged?: StagedFile[], removals?: StagedFile[], denied?: string[],
  ): Promise<unknown> {
    const inflight: Inflight = { emitted: [], transitions: [] };
    const result = await run(envelope, tx, depth, staged, removals, denied, inflight);
    const { emitted } = inflight;
    const at = new Date().toISOString();
    for (const event of emitted) {
      await tx.systemCreate(OUTBOX, outboxRow(event, envelope.actor, envelope.meta, at));
    }
    if (emitted.length) options.onEmit?.();
    return result;
  }

  async function run(
    envelope: Envelope, tx: DBAdapter, depth: number,
    staged: StagedFile[] | undefined, removals: StagedFile[] | undefined, denied: string[] | undefined,
    inflight: Inflight,
  ): Promise<unknown> {
    const { emitted } = inflight;
    if (depth > MAX_CALL_DEPTH) throw new BadRequest(`call depth exceeded ${MAX_CALL_DEPTH}`);

    const model = models.get(envelope.model);
    if (!model) throw new NotFound('unknown_model');

    /**
     * A registered model may still be read-only to the one door. Identity is:
     * its routes re-derive the actor per operation, and `roles` is a writable
     * column, so an ordinary `update` carrying it would be privilege escalation
     * through the generic path. Checked before the gates, because this is a
     * property of the model rather than a question about the actor — no policy
     * an app writes can grant it.
     */
    if (model.dispatch === 'read' && WRITE_OPS.has(envelope.op)) {
      throw new Denied('read_only_model');
    }

    const isCustom = !BUILTIN_OPS.has(envelope.op);
    if (isCustom && !model.actions[envelope.op]) throw new NotFound('unknown_action');

    const view: GateView = makeView(envelope.actor, envelope.op, model, envelope.data);

    // Phase one: no persistence read, hook or side effect before authorization.
    // The row is not known here and must not be — fetching it to decide whether
    // the caller may fetch it is the inversion §16 forbids.
    if (!allowsAction(model, view)) throw new Denied('forbidden');

    const scope = resolveScope(model, view);

    /**
     * Phase two (§11). Once a row has been loaded *within scope*, the gates are
     * re-evaluated against it, so `x-access.write: "row.status != 'locked'"` and
     * row-dependent field policy mean what they say. Reading the row first was
     * already authorised by phase one, so this narrows access and never widens
     * it: a caller who fails phase one never reaches here.
     */
    const withRow = (row: Row): GateView => {
      const rowView = makeView(envelope.actor, envelope.op, model, envelope.data, row);
      if (!allowsAction(model, rowView)) throw new Denied('forbidden_for_this_row');
      /**
       * The lifecycle is part of the SAME gate, not a second one (W-101).
       *
       * A transition is legal only from the states it declares, and whether it
       * is legal depends on the row — which is exactly the question phase two
       * exists to answer, so it is answered here, once, on the row that was
       * already loaded within scope. Nothing has run yet: no hook, no handler,
       * no write. The reason is on the wire because it is a workflow fact about
       * a row this caller may already write, not a hint about one they may not.
       */
      const transition = model.states?.transitions[envelope.op];
      if (transition) {
        const current = row[model.states!.field];
        if (!transition.from.includes(String(current))) {
          throw new Denied(
            `"${envelope.op}" moves ${model.name} from ${transition.from.join(' or ')}, ` +
            `but this row is ${current === undefined || current === null ? 'in no state' : String(current)}`,
          );
        }
      }
      return rowView;
    };

    /**
     * What generic dispatch emits by itself (W-112).
     *
     * After the after-hook and before the result leaves, because an event says
     * something HAPPENED: emitting before the write would be a promise, and
     * emitting before the hook would describe a state the hook can still
     * change. The payload is the row's id and nothing else — `_outbox` is plain
     * text beside ciphertext, and a handler that needs the row fetches it at
     * delivery time, through the gates.
     */
    const emitBuiltin = (event: string, rowId?: string) => {
      const name = `${model.name}.${event}`;
      if (!listeners.has(name)) return;
      emitted.push({ name, payload: rowId ? { id: rowId } : {}, model: model.name, rowId });
    };

    const ctx: ActionContext = {
      actor: envelope.actor,
      op: envelope.op,
      model,
      id: envelope.id,
      data: { ...envelope.data },
      query: envelope.query,
      meta: envelope.meta,
      scope,
      tx,
      call: (op, modelName, input = {}) =>
        run(
          {
            ...envelope, op, model: modelName, id: input.id,
            data: input.data ?? {}, query: input.query ?? {},
            meta: { ...envelope.meta, source: 'call' },
          },
          tx,
          depth + 1,
          staged,
          removals,
          denied,
          // The same buffer, and the same authorisations: a hook's event
          // belongs to the transaction the caller opened, not to one of its own.
          inflight,
        ),
      /**
       * Buffer an event. It reaches `_outbox` when the outermost operation
       * finishes, inside this transaction, and is delivered after it commits.
       */
      emit: (name, payload = {}) => {
        if (typeof name !== 'string' || !name.includes('.')) {
          throw new BadRequest(`an event name is "<model>.<event>", not "${String(name)}"`);
        }
        emitted.push({ name, payload: { ...payload }, model: model.name, rowId: envelope.id });
      },
      log: (...args) => console.log(`[${envelope.meta.requestId}]`, ...args),
      staged: staged ?? [],
      removals: removals ?? [],
    };

    if (isCustom) {
      /**
       * The row is loaded BEFORE validation, when the operation names one.
       *
       * A requirement set may now depend on the stored row (§5's state axis,
       * W-103), and a document that says "a customer is required" cannot be
       * derived without knowing whether the row already has one. Phase one has
       * already allowed the caller, and phase two runs the moment the row
       * arrives — before any hook, handler or write — so the ordering the
       * invariant is about is unchanged. What moved is the cheap shape check,
       * which now happens after the 404 rather than before it.
       */
      let acting = view;
      if (ctx.id) {
        const row = await tx.get(model, scope, ctx.id);
        if (!row) throw new NotFound('not_found');
        ctx.row = await decryptRow(keys, model, envelope.actor.orgId, row);
        acting = withRow(ctx.row);
      }
      const errors = validate(model, envelope.op, ctx.data, ctx.row);
      if (errors.length) throw new ValidationFailure(errors);
      // §16 puts the field-write filter on the one ordered path, so a custom
      // action gets it too: a handler must never see a field this actor may not
      // write, whether it persists through ctx.call or reaches for ctx.tx.
      ctx.data = applyWriteGate(model, acting, ctx.data, denied);
      await runHooks(hookPoint('before', envelope.op), ctx, 'data');
      const handler = handlers.get(model.actions[envelope.op]!)!;
      /**
       * The one window in which the state field may be written.
       *
       * Opened after the phase-two gate has accepted the move and closed the
       * moment the handler returns, so nothing before it and nothing after it
       * can write the field — not a hook on this action, not a sibling in the
       * same batch, not a later `ctx.call`.
       */
      const transition = model.states?.transitions[envelope.op];
      if (transition) inflight.transitions.push({ model: model.name, id: ctx.id, to: transition.to });
      try {
        ctx.result = await handler(ctx);
      } finally {
        if (transition) inflight.transitions.pop();
      }
      /**
       * The declared limit (S-121, AUD-071).
       *
       * After the write and before the commit, on the operation's OWN
       * transaction, so the count and the write it judges are one atomic act —
       * a throw here rolls both back. `guards.ts` has the reasoning; the short
       * version is that counting BEFORE writing leaves a window two concurrent
       * confirmations both fit through.
       */
      await assertWithinLimits(model, envelope.op, acting, scope, tx);
      await runHooks(hookPoint('after', envelope.op), ctx, 'result');
      // A custom action emits its own name, so a declared transition is an
      // event exactly as a create is: `note.start`, not `note.updated`.
      emitBuiltin(envelope.op, ctx.id);
      // A row gets this model's field-read policy applied to it on the way out.
      // An ARRAY does not: it is what a declared `batch` returns, and each of
      // its elements came back through `ctx.call`, which already projected it
      // with its OWN model's policy. Projecting again here would judge another
      // model's row by this one's field names — which silently keeps fields it
      // should drop, and drops fields it should keep.
      return ctx.result && typeof ctx.result === 'object' && !Array.isArray(ctx.result)
        ? projectRead(model, acting, ctx.result as Row)
        : ctx.result;
    }


  /**
   * Turn `stage:<id>` into the descriptor this server recorded when it staged
   * those bytes, and queue them for promotion once the transaction commits.
   *
   * The browser is handed a descriptor by `POST /v0/stage` and could send back
   * any shape it likes — a forged size, checksum or content type would then be
   * what the row records and what every later download claims. So the reference
   * is an id and nothing else, and the values come from the adapter's own copy
   * (WP-02 H-122). An id the tenant has nothing staged under is a 400: it is
   * either expired, already used, or somebody else's.
   *
   * Runs after the access gate and the field-write filter, so an actor who may
   * not write the property never reaches it.
   */
  async function resolveStaged(model: Model, orgId: string, data: Row, ctx: { staged: StagedFile[] }) {
    for (const property of Object.keys(model.uploads)) {
      if (!(property in data)) continue;          // not being written
      const value = data[property];
      if (value === null || value === '') continue;   // clearing the field

      // The ONLY thing a request may say about a file is which staged upload it
      // means. A descriptor sent whole would be believed: its `name`, `size` and
      // `contentType` are what every later download reports, and its `id` is
      // what the download route reads bytes by — so a caller could dress one
      // file up as another, or point a row they may write at a file belonging to
      // a row they may not read. Both upload paths produce a `stage:` reference,
      // so anything else is a caller writing a descriptor by hand.
      if (typeof value !== 'string' || !value.startsWith(STAGE_PREFIX)) {
        throw new BadRequest(`"${property}" must be an upload reference from /v0/stage/${model.name}/${property}`);
      }

      const id = value.slice(STAGE_PREFIX.length);
      const descriptor = await options.files?.describeStaged(orgId, id);
      if (!descriptor) {
        throw new BadRequest(`"${property}" references a staged upload that is not available`);
      }
      data[property] = JSON.stringify(descriptor);
      // The multipart path already queued these bytes for promotion.
      if (!ctx.staged.some((f) => f.id === id && f.orgId === orgId)) ctx.staged.push({ orgId, id });
    }
  }

    switch (envelope.op) {
      /**
       * `GET /v0/schema/<model>?op=<op>` — and, when the operation is about one
       * row, `GET /v0/schema/<model>/<id>?op=<op>`.
       *
       * With an id the derived document is the one the server will validate
       * THAT row's transition against: a requirement the row already satisfies
       * is not asked of the caller twice (W-103). It is an ordinary read — the
       * id resolves within scope, so a row in another tenant is a 404, and the
       * phase-two gate runs before the row informs anything.
       */
      case 'schema': {
        let row: Row | undefined;
        if (ctx.id) {
          const stored = await tx.get(model, scope, ctx.id);
          if (!stored) throw new NotFound('not_found');
          row = await decryptRow(keys, model, envelope.actor.orgId, stored);
          withRow(row);
        }
        return deriveSchema(model, (envelope.query as any).op ?? 'create', {
          row,
          readable: (f) => canRead(model, view, f),
          writable: (f) => canWrite(model, view, f),
        });
      }

      case 'create': {
        const errors = validate(model, 'create', ctx.data);
        if (errors.length) throw new ValidationFailure(errors);
        // Before the write gate, so an attempt is always refused rather than
        // sometimes dropped: field policy must not decide whether the caller
        // hears about it.
        assertLifecycleWrite(model, ctx.data, ctx.id, inflight, 'create');
        ctx.data = applyWriteGate(model, view, ctx.data, denied);
        /**
         * A model with a lifecycle has no stateless rows (W-101).
         *
         * The initial state is assigned AFTER the write gate, because it is the
         * framework's value and not the caller's — the same reason the id is
         * minted rather than accepted. An actor who may not write the state
         * field still gets a row in the initial state; what they cannot do is
         * choose which one.
         */
        if (model.states && ctx.data[model.states.field] === undefined) {
          ctx.data[model.states.field] = model.states.initial;
        }
        await resolveStaged(model, envelope.actor.orgId, ctx.data, ctx);
        await runHooks('beforeCreate', ctx, 'data');
        const conflicts = await uniquenessErrors(keys, tx, model, scope, envelope.actor.orgId, ctx.data);
        if (conflicts.length) throw new ValidationFailure(conflicts);
        // The id is minted here so ciphertext can be bound to the row it lives in.
        const rowId = crypto.randomUUID();
        const stored = await encryptInput(keys, model, envelope.actor.orgId, rowId, ctx.data);
        ctx.result = await decryptRow(keys, model, envelope.actor.orgId,
          await tx.create(model, scope, stored, {
            id: rowId,
            orgId: envelope.actor.orgId || options.defaultOrgId,
          }));
        // After the write, inside this transaction — see `guards.ts`.
        await assertWithinLimits(model, 'create', view, scope, tx);
        await runHooks('afterCreate', ctx, 'result');
        emitBuiltin(eventFor('create')!, String((ctx.result as Row).id));
        return projectRead(model, view, ctx.result as Row);
      }

      case 'update': {
        if (!ctx.id) throw new BadRequest('id required');
        const errors = validate(model, 'update', ctx.data);
        if (errors.length) throw new ValidationFailure(errors);
        assertLifecycleWrite(model, ctx.data, ctx.id, inflight, 'update');
        const existing = await tx.get(model, scope, ctx.id);
        if (!existing) throw new NotFound('not_found');
        ctx.row = await decryptRow(keys, model, envelope.actor.orgId, existing);
        // The stored row decides: a locked or archived row can refuse the write,
        // and field policy can depend on the row's own values.
        const acting = withRow(ctx.row);
        ctx.data = applyWriteGate(model, acting, ctx.data, denied);
        await resolveStaged(model, envelope.actor.orgId, ctx.data, ctx);
        await runHooks('beforeUpdate', ctx, 'data');
        const conflicts = await uniquenessErrors(keys, tx, model, scope, envelope.actor.orgId, ctx.data, ctx.id);
        if (conflicts.length) throw new ValidationFailure(conflicts);
        const stored = await encryptInput(keys, model, envelope.actor.orgId, ctx.id, ctx.data);
        const row = await tx.update(model, scope, ctx.id, stored);
        if (!row) throw new NotFound('not_found');
        ctx.result = await decryptRow(keys, model, envelope.actor.orgId, row);
        // After the write, inside this transaction — see `guards.ts`.
        await assertWithinLimits(model, 'update', acting, scope, tx);
        await runHooks('afterUpdate', ctx, 'result');
        emitBuiltin(eventFor('update')!, ctx.id);
        return projectRead(model, acting, ctx.result as Row);
      }

      case 'delete': {
        if (!ctx.id) throw new BadRequest('id required');
        const existing = await tx.get(model, scope, ctx.id);
        if (!existing) throw new NotFound('not_found');
        // The stored row is what a beforeDelete hook and a row-aware gate judge,
        // so it is decrypted first: a hook refusing to delete a locked record
        // needs to see the record, not its ciphertext.
        ctx.row = await decryptRow(keys, model, envelope.actor.orgId, existing);
        const acting = withRow(ctx.row);
        await runHooks('beforeDelete', ctx, 'data');
        if (!(await tx.delete(model, scope, ctx.id))) throw new NotFound('not_found');
        // The row is gone; its bytes go too, but only once the transaction has
        // committed — a rollback must leave the file exactly where the row is.
        for (const property of Object.keys(model.uploads)) {
          const raw = ctx.row[property];
          if (typeof raw !== 'string') continue;
          try {
            ctx.removals.push({ orgId: envelope.actor.orgId, id: (JSON.parse(raw) as FileDescriptor).id });
          } catch { /* not a descriptor; nothing to remove */ }
        }
        ctx.result = projectRead(model, acting, ctx.row);
        await runHooks('afterDelete', ctx, 'result');
        emitBuiltin(eventFor('delete')!, ctx.id);
        return ctx.result;
      }

      case 'get': {
        if (!ctx.id) throw new BadRequest('id required');
        const row = await tx.get(model, scope, ctx.id);
        if (!row) throw new NotFound('not_found');
        const plain = await decryptRow(keys, model, envelope.actor.orgId, row);
        return projectRead(model, withRow(plain), plain);
      }

      case 'list': {
        const filters = await rewriteFilters(keys, model, envelope.actor.orgId, ctx.query.filters);
        const page = await tx.list(model, scope, { ...ctx.query, filters });
        // Field policy is evaluated per row so it may depend on the row.
        // Access is NOT re-checked per row: dropping rows after the fact is the
        // post-fetch filtering §11 rules out — it breaks paging and counts.
        // Which rows a caller may see is x-scope's job, bound into the query.
        const rows = await Promise.all(page.rows.map(async (r) => {
          const plain = await decryptRow(keys, model, envelope.actor.orgId, r);
          return projectRead(model, makeView(envelope.actor, envelope.op, model, envelope.data, plain), plain);
        }));
        return { rows, nextCursor: page.nextCursor };
      }

      /**
       * `GET /v0/history/<model>/<id>` — what the framework recorded about one
       * row (WP-06 W-122).
       *
       * A generic operation rather than a route, for the reason every other
       * operation is: `_audits` and `_outbox` are `_`-prefixed, so generic
       * dispatch refuses them and a screen has no way to read them — and adding
       * a route for one screen would put a second door beside the one this
       * framework has. As a builtin it is gated by `x-access.READ` like a `get`,
       * scoped like a `get`, and available to every model at once.
       *
       * The row is loaded first, within scope and through the phase-two gate,
       * so a row in another tenant is a 404 and a row this actor may not see has
       * no history either. What comes back carries names, ids and outcomes —
       * never field VALUES, which is the same rule that keeps values out of
       * `_audits.fields` in the first place.
       */
      case 'history': {
        if (!ctx.id) throw new BadRequest('id required');
        const stored = await tx.get(model, scope, ctx.id);
        if (!stored) throw new NotFound('not_found');
        // Two statements, in the order they run: the row is decrypted and then
        // judged. Nesting them reads as if the gate came first.
        const plain = await decryptRow(keys, model, envelope.actor.orgId, stored);
        withRow(plain);

        const where = { orgId: envelope.actor.orgId, model: model.name, rowId: ctx.id };
        const newestFirst = (a: Row, b: Row) => String(b.at ?? '').localeCompare(String(a.at ?? ''));
        const [audits, events] = await Promise.all([
          tx.systemList(AUDIT, where),
          tx.systemList(OUTBOX, where),
        ]);
        return {
          audits: audits.sort(newestFirst).slice(0, HISTORY_LIMIT).map((row) => ({
            at: row.at, requestId: row.requestId, source: row.source, op: row.op,
            outcome: row.outcome, status: row.status, detail: row.detail,
            actorId: row.actorId, actorRoles: row.actorRoles, fields: row.fields,
          })),
          events: events.sort(newestFirst).slice(0, HISTORY_LIMIT).map((row) => ({
            at: row.at, name: row.name, status: row.status, attempts: row.attempts,
            deliveredAt: row.deliveredAt, lastError: row.lastError, requestId: row.requestId,
          })),
        };
      }

      case 'count': {
        const filters = await rewriteFilters(keys, model, envelope.actor.orgId, ctx.query.filters);
        return { count: await tx.count(model, scope, filters) };
      }

      case 'aggregate': {
        const spec = ctx.data as unknown as AggregateSpec;
        if (!Array.isArray(spec?.measures) || spec.measures.length === 0) {
          throw new BadRequest('measures are required');
        }
        assertAggregatable(model, [...(spec.groupBy ?? []), ...spec.measures.map((m) => m.field)]);
        const filters = await rewriteFilters(keys, model, envelope.actor.orgId,
          [...(spec.filters ?? []), ...(ctx.query.filters ?? [])]);
        return tx.aggregate(model, scope, { ...spec, filters });
      }

      default:
        throw new NotFound('unknown_action');
    }
  }

  return { execute };
}
