/**
 * `x-guards` — a declaration can refuse on a count (WP-11 S-121, AUD-071).
 *
 * `GateView` is the whole expression context — `{ actor, op, model, input, row,
 * now }` — with no count, no query and no adapter in it. That is deliberate: a
 * gate expression evaluates against frozen plain data and can therefore do
 * nothing, which is the property §11 rests on. Putting a database handle in it
 * to express "refuse when 30 seats are already confirmed" would give every
 * expression in the system the ability to query, to answer one question.
 *
 * So the count is a KEYWORD rather than a function in the expression language:
 * a scoped equality count with a ceiling, declared, compiled at boot, and
 * evaluated by the engine at one point on the ordered path.
 *
 * ## Why it is checked AFTER the write
 *
 * The item is the concurrency, not the arithmetic. A guard that counts, sees
 * 29, and then writes has a window between the two in which another writer can
 * do exactly the same — and two admins confirming the thirtieth and thirty-first
 * seat at the same moment both pass and the workshop seats 31. The conversion's
 * own SQL avoids this by putting the count inside the UPDATE's own `WHERE`, so
 * the counting and the writing are one atomic act.
 *
 * This is the same thing said with the pieces available above the adapter seam:
 * the count runs INSIDE the operation's transaction, AFTER the write, and a
 * count over the ceiling throws — which rolls that transaction back. The write
 * and the count that judges it commit together or not at all. Two writers at
 * the boundary therefore cannot both commit: whichever transaction commits
 * second either sees the other's row and refuses, or is refused by the store
 * for having written on a stale snapshot. Either way the limit holds, which is
 * what `packages/core/test/guards.test.ts` measures rather than assumes.
 *
 * Checking after also makes the rule honest for a write that does NOT join the
 * counted set: the count simply does not move, so a row at the ceiling can
 * still be edited. A before-check would have had to guess whether the pending
 * write would land inside `where`, and guessing wrong in the permissive
 * direction is the bug, while guessing wrong in the strict direction locks a
 * full workshop out of its own corrections.
 */
import type { DBAdapter, Filter, Scope } from '../db/adapter.ts';
import type { Guard, Model } from '../model.ts';
import { compileExpression, type Compiled } from '../expressions.ts';
import { Denied } from '../errors.ts';
import type { GateView } from '../gates.ts';

interface CompiledGuard {
  guard: Guard;
  /** field -> the expression producing the value that field must equal. */
  terms: [string, Compiled][];
}

const compiledByModel = new WeakMap<Model, CompiledGuard[]>();

/**
 * Compile at boot, beside the gates, so a broken expression fails startup
 * rather than the first request that happens to reach the limit.
 */
export function compileGuards(model: Model): CompiledGuard[] {
  const compiled = model.guards.map((guard) => ({
    guard,
    terms: Object.entries(guard.where).map(([field, expression]): [string, Compiled] => [
      field,
      compileExpression(expression, `${model.name}.x-guards."${guard.name}".where.${field}`),
    ]),
  }));
  compiledByModel.set(model, compiled);
  return compiled;
}

const guardsFor = (model: Model): CompiledGuard[] =>
  compiledByModel.get(model) ?? compileGuards(model);

/**
 * Refuse the operation if a declared limit is now exceeded.
 *
 * Call sites hold this to its contract: `tx` is the operation's OWN
 * transaction, and this runs after the write and before the commit. `view` is
 * the phase-two view, so `row` is the row as the operation loaded it — a guard
 * on `create` therefore has `input` and `actor` and no row, which is what a
 * create has.
 *
 * `scope` is the server-injected scope the operation is already running under,
 * so a count can never reach across a tenant: the adapter adds the same
 * `orgId` term it adds to every other query, and `where` only narrows it.
 */
export async function assertWithinLimits(
  model: Model, op: string, view: GateView, scope: Scope, tx: DBAdapter,
): Promise<void> {
  const guards = guardsFor(model);
  if (!guards.length) return;

  for (const { guard, terms } of guards) {
    if (!guard.on.includes(op)) continue;

    const filters: Filter[] = [];
    let countable = true;
    for (const [field, expression] of terms) {
      const value = expression.evalSync(view);
      // A term that resolves to nothing does not become "match anything" — it
      // means this guard has no cohort to count, and counting the whole table
      // instead would refuse writes that have nothing to do with each other.
      // Same reading `set` gives a value that resolves to nothing.
      if (value === undefined || value === null) { countable = false; break; }
      filters.push({ field, op: 'eq', value });
    }
    if (!countable) continue;

    const count = await tx.count(model, scope, filters);
    if (count > guard.max) throw new Denied(guard.reason);
  }
}
