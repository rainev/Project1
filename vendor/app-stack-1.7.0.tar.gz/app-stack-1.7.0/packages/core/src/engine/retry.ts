/**
 * Retrying a writing request that lost a race with another one (WP-11 S-121).
 *
 * Found while proving the capacity guard. Two writers at the boundary left
 * exactly the limit — and they left exactly the limit with the guard REMOVED
 * too, because sqlite refused the second writer with "database is locked"
 * before the guard was ever consulted. The store's lock was doing the work and
 * the test was green for the wrong reason, which is the shape of failure this
 * package was told twice not to repeat: a check that cannot fail in both
 * directions proves nothing.
 *
 * It is also a defect in its own right, and the more serious half. A store
 * conflict is not a fact about the request: the same request, sent alone, would
 * have succeeded. Surfacing it as a failure makes two admins working at once
 * see errors that are nobody's fault, and it makes every concurrency property
 * of this system untestable, because contention is indistinguishable from
 * refusal.
 *
 * So a writing request that hits a transient store conflict waits a moment and
 * runs again, from the top of its transaction. Safe because the transaction is
 * the unit: it rolled back, so nothing it did survives — no row, no outbox row,
 * no audit row. Staged bytes are handled outside it and are untouched by a
 * retry. What is NOT retried is everything else: a `Denied` from a gate or a
 * guard, a validation failure, a conflict on a unique index. Those are answers,
 * and retrying an answer is how a refusal becomes a spin.
 */

/**
 * How many times a contended transaction runs before the caller hears about it.
 *
 * Sized against what actually contends here, which is not only two requests.
 * The outbox worker delivers on its own transactions in the background, and a
 * single sqlite connection cannot hold two at once — so an ordinary write can
 * collide with a delivery that has nothing to do with it. Measured on the
 * running app: eight attempts over ~300ms was not enough and surfaced as a 500.
 */
const ATTEMPTS = 16;
/** Backoff base. Jittered, so two writers do not retry in lockstep forever. */
const BASE_DELAY_MS = 8;
/** Backoff ceiling, so a long queue does not become a minute-long request. */
const MAX_DELAY_MS = 200;

/**
 * Whether this error says "somebody else was writing", rather than "no".
 *
 * Matched on the message because it arrives from the driver, below the adapter
 * seam this package may not change. Every engine this framework supports is
 * represented: sqlite's lock, PostgreSQL's serialization failure and deadlock,
 * MySQL's lock-wait timeout.
 */
export function isTransientStoreConflict(error: unknown): boolean {
  const message = String((error as { message?: unknown } | undefined)?.message ?? '');
  return /database is locked|database table is locked|SQLITE_BUSY/i.test(message)
    || /cannot start a transaction within a transaction/i.test(message)
    || /could not serialize access|deadlock detected|restart transaction/i.test(message)
    || /lock wait timeout exceeded/i.test(message);
}

const wait = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

/**
 * Run a writing transaction, retrying only a transient store conflict.
 *
 * `run` must be the WHOLE transaction, not a step inside one: a retry starts it
 * again, and a caller that handed over half of one would run that half twice.
 */
export async function withStoreRetry<T>(run: () => Promise<T>, attempts = ATTEMPTS): Promise<T> {
  for (let attempt = 1; ; attempt++) {
    try {
      return await run();
    } catch (error) {
      if (attempt >= attempts || !isTransientStoreConflict(error)) throw error;
      // Exponential, with full jitter: two writers backing off by the same
      // amount collide again, which is the failure this is meant to end.
      const ceiling = Math.min(BASE_DELAY_MS * 2 ** (attempt - 1), MAX_DELAY_MS);
      await wait(Math.random() * ceiling);
    }
  }
}
