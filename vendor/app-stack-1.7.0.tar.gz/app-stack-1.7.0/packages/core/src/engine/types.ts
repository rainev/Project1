/**
 * The envelope and the context (ARCHITECTURE §6).
 *
 * One shape carried throughout: serialisable on the wire, plus in-process
 * capabilities once it becomes a context. Actions never define their own
 * input shape — payload, actor and target are always the same slots.
 */
import type { DBAdapter, Filter, Row, Scope } from '../db/adapter.ts';
import type { Model } from '../model.ts';

/**
 * How a form refers to bytes it staged in an earlier request. An id, never a
 * descriptor: the values a row records come from the file adapter's own copy,
 * not from the caller (WP-02 H-122).
 */
export const STAGE_PREFIX = 'stage:';

export interface Actor {
  id: string;
  roles: string[];
  orgId: string;
}

export interface Query {
  limit?: number;
  sort?: string;
  dir?: 'asc' | 'desc';
  cursor?: string;
  filters?: Filter[];
}

/**
 * How the operation arrived. The envelope is meant to be replayable, so it has
 * to say whether it came off the wire or from a hook re-entering the dispatcher
 * — otherwise an audit trail cannot tell a caller's own delete from one a hook
 * performed on their behalf.
 */
export type Source = 'http' | 'batch' | 'file' | 'call' | 'event' | 'schedule' | 'channel';

export interface Envelope {
  actor: Actor;
  op: string;
  model: string;
  id?: string;
  data: Row;
  query: Query;
  meta: {
    requestId: string;
    at: string;
    source: Source;
    /**
     * How many post-commit deliveries deep this operation is (WP-06 W-110).
     *
     * Absent on anything that arrived over the wire, which is zero. Delivery
     * sets it, and an event emitted by a handler inherits it plus one, so a
     * rule that reacts to its own effect stops instead of looping forever in a
     * background worker nobody is watching.
     */
    chain?: number;
  };
}

/**
 * One thing that happened, buffered until the transaction that caused it is
 * about to close (WP-06 W-110).
 *
 * Buffered rather than written where `ctx.emit` is called so that the write is
 * one place — at the end of the outermost operation, still inside the
 * transaction — rather than scattered through the engine's switch.
 */
export interface EmittedEvent {
  name: string;
  payload: Record<string, unknown>;
  model: string;
  rowId?: string;
}

/** What a hook or action handler receives. Same data as the envelope, plus capability. */
export interface ActionContext {
  actor: Actor;
  op: string;
  model: Model;
  id?: string;
  data: Row;
  query: Query;
  meta: Envelope['meta'];
  scope: Scope;
  row?: Row;
  result?: unknown;
  tx: DBAdapter;
  call(op: string, model: string, input?: { id?: string; data?: Row; query?: Query }): Promise<unknown>;
  /**
   * Record that something happened, to be acted on AFTER this transaction
   * commits (§16, decision 15).
   *
   * It buffers; it does not deliver. The row lands in `_outbox` inside this
   * transaction, so a rollback takes the intent with the fact — and delivery
   * happens later, out of the request's way, where a failure retries instead of
   * undoing a write that already succeeded.
   *
   * The payload should carry ids and names, never row values: it is stored as
   * plain JSON beside ciphertext. A handler that needs the row fetches it at
   * delivery time, through the gates.
   */
  emit(name: string, payload?: Row): void;
  /**
   * Hold a send until this transaction has committed, and run it OUTSIDE it
   * (AUD-087).
   *
   * `notify` reaches the network. Doing that from inside the delivery
   * transaction holds a database write lock open for the length of an SMTP
   * conversation, so a single sqlite connection answers `cannot start a
   * transaction within a transaction` to unrelated writes for the duration of
   * every send — and a retrying backlog keeps it held. The outbox provides this
   * hook so the socket sits outside the transaction; a context without it (a
   * request, a hook) is unchanged, and `notify` is reachable only from
   * `x-events`, which only the outbox runs.
   *
   * The expressions a send needs — the row, the recipients, the body — are
   * still resolved inside the transaction, on the row as it is now. Only the
   * socket moves out.
   */
  deferSend?(fn: () => Promise<void>): void;
  log(...args: unknown[]): void;
  /** Files written to staging by this request, promoted only after commit. */
  staged: StagedFile[];
  /** Files whose rows were deleted, removed only after commit. */
  removals: StagedFile[];
}

export interface StagedFile { orgId: string; id: string }

export type HookResult = void | { patch?: Row } | { deny: string } | { skip: true };
