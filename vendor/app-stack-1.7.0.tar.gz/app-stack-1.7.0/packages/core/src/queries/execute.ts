/**
 * Running a declared query for one actor (ARCHITECTURE §7.1, §11, §22).
 *
 * The order is the one §16 fixes for every other read, and for the same reason:
 *
 *   1. the query's own `x-access.read` — deny by default;
 *   2. the READ gate of EVERY participating model, so a join is never a way
 *      into a model the actor may not list;
 *   3. parameters, validated and coerced against their declared types;
 *   4. each participating model's `x-scope`, evaluated to VALUES and bound —
 *      the root's into WHERE, a joined model's into its JOIN condition;
 *   5. only then the statement;
 *   6. and on the way out, `x-field-access.read` per column.
 *
 * Nothing is read before step 5, and nothing the caller sent becomes an
 * identifier at any step.
 */
import { isPlatform } from '../auth/roles.ts';
import { ORG } from '../auth/system-models.ts';
import {
  CSV_MAX_ROWS, CSV_PAGE_SIZE,
  QUERY_DEFAULT_LIMIT as DEFAULT_LIMIT, QUERY_MAX_LIMIT as MAX_LIMIT,
} from '../limits.ts';
import type { DBAdapter, Row } from '../db/adapter.ts';
import { BadRequest, Denied, NotFound } from '../errors.ts';
import { allowsAction, canRead, makeView, resolveScope } from '../gates.ts';
import type { Actor } from '../engine/types.ts';
import type { ExecutableQuery, QueryPage } from './compiled.ts';
import type { Query, QueryParam } from './compile.ts';
import { widenScope } from '../tenancy.ts';

export interface QueryRequest {
  actor: Actor;
  name: string;
  params: Record<string, unknown>;
  limit?: number;
  cursor?: string;
  /**
   * A reader's sort, named by an OUTPUT KEY the query declared — never a column
   * name. The declared `orderBy` is the default; this replaces it, and the key
   * is resolved back to the model's own column before anything reaches SQL.
   */
  sort?: string;
  dir?: 'asc' | 'desc';
  /**
   * Every tenant this read may span, for a cross-tenant query (Q-123). Read from
   * `_orgs` by `runQuery` and handed in already resolved, so planning stays a
   * pure function and the adapter receives bound values as it always has.
   */
  tenants?: readonly string[];
}

export interface QueryResult {
  rows: Record<string, unknown>[];
  nextCursor?: string;
  /** The columns actually returned, in order — a grid renders from this. */
  columns: { key: string; label: string; model?: string; field?: string }[];
}

/**
 * A generated key read as words: `customer_name` and `customerName` both become
 * "Customer name". A heading is for a reader, and no config should have to
 * spell out what the framework already knows how to say.
 */
const humanize = (key: string): string => {
  const words = key.replace(/[_-]+/g, ' ').replace(/([a-z0-9])([A-Z])/g, '$1 $2').trim().toLowerCase();
  return words.charAt(0).toUpperCase() + words.slice(1);
};


/** A parameter arrives as text on a URL; its declared type is what it must become. */
function coerceParam(name: string, spec: QueryParam, raw: unknown): unknown {
  if (spec.type === 'boolean') {
    if (typeof raw === 'boolean') return raw;
    if (raw === 'true') return true;
    if (raw === 'false') return false;
    throw new BadRequest(`param "${name}" must be a boolean`);
  }
  if (spec.type === 'number' || spec.type === 'integer') {
    const value = typeof raw === 'number' ? raw : Number(String(raw));
    if (String(raw).trim() === '' || Number.isNaN(value)) {
      throw new BadRequest(`param "${name}" must be a ${spec.type}`);
    }
    if (spec.type === 'integer' && !Number.isInteger(value)) {
      throw new BadRequest(`param "${name}" must be an integer`);
    }
    return value;
  }
  return String(raw);
}

function resolveParams(query: Query, supplied: Record<string, unknown>): Record<string, unknown> {
  const params: Record<string, unknown> = {};
  for (const [name, spec] of Object.entries(query.params)) {
    const raw = supplied[name];
    if (raw === undefined || raw === '') {
      if (spec.default !== undefined) { params[name] = spec.default; continue; }
      if (spec.required) throw new BadRequest(`param "${name}" is required`);
      continue;
    }
    params[name] = coerceParam(name, spec, raw);
  }
  // An undeclared parameter is a typo, not an extension point: accepting it
  // silently is how a `where` clause quietly stops filtering.
  for (const name of Object.keys(supplied)) {
    if (!(name in query.params)) {
      throw new BadRequest(`unknown param "${name}" — declared: ${Object.keys(query.params).join(', ') || 'none'}`);
    }
  }
  return params;
}

/** An author writes a measure's label; the plan carries its generated key. */
const measureKey = (query: Query, label?: string) =>
  label === undefined ? undefined : `m${query.measures.findIndex((m) => m.key === label)}`;

/** The reader's own sort, resolved from an output key back to a column. */
function requestedOrder(
  query: Query, request: QueryRequest, views: Map<string, ReturnType<typeof makeView>>,
) {
  if (request.sort === undefined) return undefined;
  const dir = request.dir === 'desc' ? 'desc' as const : 'asc' as const;

  const measure = query.measures.find((m) => m.key === request.sort);
  if (measure) return [{ measure: `m${query.measures.indexOf(measure)}`, dir }];

  const column = (query.aggregate ? query.groupBy : query.select).find((c) => c.key === request.sort)!;
  if (!canRead(column.model, views.get(column.alias)!, column.column)) throw new Denied('forbidden');
  return [{ alias: column.alias, column: column.column, dir }];
}

/**
 * Turn a declared query into the statement one actor may run. Everything that
 * could deny has denied by the time this returns.
 */
export function planQuery(query: Query, request: QueryRequest): ExecutableQuery {
  const { actor } = request;
  const now = new Date().toISOString();
  const params = resolveParams(query, request.params);

  // 1. The query's own gate. Absent means deny, exactly as a model's does.
  const queryView = Object.freeze({
    actor: Object.freeze({ id: actor.id, roles: Object.freeze([...actor.roles]), orgId: actor.orgId }),
    op: 'query',
    query: Object.freeze({ name: query.name }),
    params: Object.freeze({ ...params }),
    now,
  });
  let allowed = false;
  try { allowed = query.access?.evalSync(queryView) === true; } catch { allowed = false; }
  if (!allowed) throw new Denied('forbidden');

  // 1b. A cross-tenant query needs the reserved role AS WELL as the gate above.
  //     Config may narrow what a platform actor reads; it can never widen what a
  //     tenant actor reads, so this check is the framework's and not the app's
  //     (Q-122). A refusal is the same 'forbidden' any other denial gives.
  let tenants: readonly string[] | undefined;
  if (query.crossTenant) {
    if (!isPlatform(actor)) throw new Denied('forbidden');
    // Nothing to widen across is a refusal, not an unscoped read.
    if (!request.tenants?.length) throw new Denied('forbidden');
    tenants = request.tenants;
  }

  // 2. Every participating model's own read gate, and its scope. A join must
  //    never reach further than a list of that model would.
  const views = new Map<string, ReturnType<typeof makeView>>();
  const scopes = new Map<string, Record<string, unknown>>();
  for (const side of query.sides) {
    const view = makeView(actor, 'query', side.model, {});
    if (!allowsAction(side.model, view)) throw new Denied('forbidden');
    const scope = resolveScope(side.model, view);
    if (Object.keys(scope).length === 0) {
      // x-scope is declared (the compiler checked) but evaluated to nothing for
      // this actor. Refusing is the only safe reading.
      throw new Denied('forbidden');
    }
    views.set(side.alias, view);
    // Widen the TENANT key only: every other scope key still narrows, so an
    // `ownerId: actor.id` scope keeps meaning "mine" (Q-124).
    scopes.set(side.alias, tenants ? widenScope(side.model, scope, tenants) : scope);
  }

  // 3. An aggregate hides its rows, so per-row field policy cannot apply to it:
  //    a measure over a column this actor may not read would leak it in a sum.
  //    Refuse the whole query rather than return a number nobody may see.
  for (const column of [...query.groupBy, ...query.measures]) {
    if (!('column' in column) || !column.column || !column.model) continue;
    if (!canRead(column.model, views.get(column.alias!)!, column.column)) throw new Denied('forbidden');
  }

  // 4. `where` values are EXPRESSIONS OVER PARAMS AND ACTOR, evaluated here and
  //    bound below. One that resolves to nothing drops its predicate, which is
  //    how an optional filter is written.
  const where = [];
  for (const predicate of query.where) {
    let value: unknown;
    try {
      value = predicate.value.evalSync({ params, actor: queryView.actor, now });
    } catch (error) {
      throw new BadRequest(`where "${predicate.source}" could not be evaluated: ${(error as Error).message}`);
    }
    if (value === undefined || value === null) continue;
    where.push({ alias: predicate.alias, column: predicate.column, op: predicate.op, value });
  }

  const limit = Math.min(Math.max(1, request.limit ?? DEFAULT_LIMIT), MAX_LIMIT);

  // A reader may re-sort by any column the report already returns — which is
  // the allowlist, and it is the query's own. Sorting by a column this actor
  // may not read is refused: the order of rows is information about it.
  if (request.sort !== undefined) {
    const keys = query.aggregate
      ? [...query.groupBy.map((g) => g.key), ...query.measures.map((m) => m.key)]
      : query.select.map((c) => c.key);
    if (!keys.includes(request.sort)) {
      throw new BadRequest(`"${request.sort}" is not a column of query "${query.name}" — returns: ${keys.join(', ')}`);
    }
  }

  const orderBy = requestedOrder(query, request, views) ?? (query.orderBy.length
    ? query.orderBy.map((o) => ({ alias: o.alias, column: o.column, measure: measureKey(query, o.measure), dir: o.dir }))
    : query.aggregate
      ? query.groupBy.slice(0, 1).map((g) => ({ alias: g.alias, column: g.column, dir: 'asc' as const }))
      : [{ alias: query.root.alias, column: 'createdAt', dir: 'desc' as const }]);

  return {
    name: query.name,
    from: { alias: query.root.alias, table: query.root.model.table },
    joins: query.joins.map((join) => ({
      alias: join.alias, table: join.model.table, kind: join.kind,
      leftAlias: join.leftAlias, leftColumn: join.leftColumn, rightColumn: join.rightColumn,
      scope: scopes.get(join.alias)!,
    })),
    // Output keys are framework-generated; the author's label is mapped back on
    // the way out, so a label never reaches SQL.
    select: [
      ...query.select.map((column, index) => ({ alias: column.alias, column: column.column, as: `c${index}` })),
      // Fetched for the field-policy evaluation below, and dropped before the
      // rows are returned: nobody asked for these.
      ...query.policyColumns.map((column, index) => ({ alias: column.alias, column: column.column, as: `p${index}` })),
    ],
    groupBy: query.groupBy.map((column, index) => ({ alias: column.alias, column: column.column, as: `g${index}` })),
    measures: query.measures.map((measure, index) => ({
      op: measure.op, alias: measure.alias, column: measure.column, as: `m${index}`,
    })),
    where,
    scope: scopes.get(query.root.alias)!,
    orderBy,
    limit,
    cursor: query.aggregate ? undefined : request.cursor,
  };
}

/** Run it, then project every returned column through `x-field-access.read`. */
export async function runQuery(
  queries: Map<string, Query>, db: DBAdapter, request: QueryRequest,
): Promise<QueryResult> {
  const query = queries.get(request.name);
  if (!query) throw new NotFound('unknown_query');

  // A cross-tenant read names its tenants explicitly; `_orgs` is the list, read
  // through the framework-only system path. Resolved here rather than in
  // planning so planning stays pure, and reused by the export, which runs a page
  // at a time through this same function (Q-123).
  const request2 = query.crossTenant && !request.tenants
    ? { ...request, tenants: (await db.systemList(ORG)).map((org) => String(org.id)) }
    : request;

  const plan = planQuery(query, request2);
  const page: QueryPage = await db.query(plan);

  const columns = query.aggregate
    ? [
        ...query.groupBy.map((g, i) => ({ key: g.key, wire: `g${i}`, model: g.model, field: g.column, label: g.label })),
        ...query.measures.map((m, i) => ({ key: m.key, wire: `m${i}`, model: undefined, field: undefined, label: m.label })),
      ]
    : query.select.map((s, i) => ({ key: s.key, wire: `c${i}`, model: s.model, field: s.column, label: s.label }));

  const rows = page.rows.map((row) => {
    const out: Record<string, unknown> = {};
    // Field policy may depend on the row, so it is evaluated per row — the same
    // rule `list` follows. A restricted column is ABSENT, never blank.
    const rowViews = new Map<string, ReturnType<typeof makeView>>();
    if (!query.aggregate) {
      for (const side of query.sides) {
        const owned: Record<string, unknown> = {};
        for (const [index, column] of query.select.entries()) {
          if (column.alias === side.alias) owned[column.column] = row[`c${index}`];
        }
        for (const [index, column] of query.policyColumns.entries()) {
          if (column.alias === side.alias) owned[column.column] = row[`p${index}`];
        }
        rowViews.set(side.alias, makeView(request.actor, 'query', side.model, {}, owned));
      }
    }
    for (const column of columns) {
      if (column.model && column.field && !query.aggregate) {
        const alias = query.select.find((s) => s.key === column.key)!.alias;
        if (!canRead(column.model, rowViews.get(alias)!, column.field)) continue;
      }
      out[column.key] = row[column.wire];
    }
    return out;
  });

  // A column every row dropped is not offered to the grid either.
  const visible = columns.filter((c) => rows.length === 0 || rows.some((r) => c.key in r));

  return {
    rows,
    nextCursor: page.nextCursor,
    columns: visible.map((c) => ({
      key: c.key,
      // The author's own word first; then the label already written on the
      // property, so a report and a form call the same column the same thing;
      // and only then the generated key, made readable.
      label: c.label ?? (c.model && c.field
        ? (c.model.schema as any)?.properties?.[c.field]?.title
        : undefined) ?? humanize(c.key),
      model: c.model?.name,
      field: c.field,
    })),
  };
}

/**
 * CSV of a query result (Q-112).
 *
 * Streamed a page at a time through the SAME `runQuery`, which means the same
 * gates, the same scope and the same per-row field projection: an export is a
 * read that happens to be spelled differently, and it can never return a column
 * the reader could not see on the screen. Nothing is buffered whole — a report
 * of a hundred thousand rows must not become a hundred thousand rows of memory.
 */

/** A ceiling, so an export is bounded work. Beyond it, the report needs params. */

/**
 * Excel and Sheets execute a cell that begins with one of these. The value is
 * data, so it is prefixed to stay data — the spreadsheet equivalent of binding
 * a parameter.
 */
const escapeCell = (value: unknown): string => {
  if (value === null || value === undefined) return '';
  let text = typeof value === 'boolean' ? (value ? 'true' : 'false') : String(value);
  if (/^[=+\-@\t\r]/.test(text)) text = `'${text}`;
  return /["\n\r,]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
};

/**
 * A CSV export streams the reader's **whole scope** (2026-09-14).
 *
 * It is a stream, so total row count costs duration and round trips, never
 * memory: it pages by cursor at `CSV_PAGE_SIZE` and writes each page to the
 * response before asking for the next. There is therefore nothing to protect by
 * stopping early, and `CSV_MAX_ROWS` is unlimited by default.
 *
 * The bound that matters is the one already on the read. Org scope is injected
 * into every page, each model's field policy is applied per row, and the
 * query's own `x-access` ran before the first page — so a row this export
 * reaches is a row that reader could have listed anyway. Truncating at a fixed
 * count did not protect anything; it made the file disagree with the scope,
 * silently, which is the worse failure for an export whose whole purpose is to
 * be the answer.
 *
 * This does not loosen decision 40. Paging is still server-side and the server
 * still mints every cursor — the export is a server-side pager that happens not
 * to stop. `CSV_MAX_ROWS` stays available as an operator's safety valve.
 */
export async function streamQueryCsv(
  queries: Map<string, Query>, db: DBAdapter, request: QueryRequest,
): Promise<{ stream: ReadableStream<Uint8Array>; filename: string }> {
  // A cross-tenant export resolves its tenant list ONCE and carries it through
  // every page: the set a report spans must not change underneath a download.
  const query = queries.get(request.name);
  const ask = query?.crossTenant && !request.tenants
    ? { ...request, tenants: (await db.systemList(ORG)).map((org) => String(org.id)) }
    : request;

  // Run the first page before returning, so a denial is a 403 with a JSON body
  // rather than a 200 whose stream fails halfway through a download.
  const first = await runQuery(queries, db, { ...ask, limit: CSV_PAGE_SIZE });

  const encoder = new TextEncoder();
  const line = (cells: unknown[]) => encoder.encode(`${cells.map(escapeCell).join(',')}\r\n`);

  /**
   * Produced in `pull`, never in `start` — this is what makes "it streams" true
   * rather than aspirational.
   *
   * `enqueue` does not block and backpressure is only advisory, so a loop
   * inside `start()` runs to completion and parks every row in the stream's
   * internal queue: measured, a consumer that read ONE chunk had 50,000 already
   * enqueued behind it. That was survivable only because a fixed
   * `CSV_MAX_ROWS` capped the buffer — which means the cap was load-bearing for
   * memory, not a policy about how much data a reader may have. Removing it
   * without this change would have traded a truncated file for an unbounded
   * one held in RAM.
   *
   * `pull` is called only while the consumer has capacity, so one row is
   * enqueued per unit of demand and the next PAGE is fetched only when the
   * buffered one runs out. Peak memory is one page, whatever the total; a slow
   * reader slows the database walk instead of racing ahead of it; and an
   * abandoned download stops pulling, which stops querying.
   */
  const columns = first.columns;
  let page = first;
  let index = 0;
  let written = 0;
  let headerSent = false;

  const stream = new ReadableStream<Uint8Array>({
    async pull(controller) {
      try {
        if (!headerSent) {
          controller.enqueue(line(columns.map((c) => c.label)));
          headerSent = true;
          return;
        }
        // An operator's optional ceiling, checked per row so it is exact.
        if (written >= CSV_MAX_ROWS) {
          controller.close();
          return;
        }
        if (index >= page.rows.length) {
          if (!page.nextCursor) {
            controller.close();
            return;
          }
          page = await runQuery(queries, db, { ...ask, limit: CSV_PAGE_SIZE, cursor: page.nextCursor });
          index = 0;
          // A cursor that yields nothing ends the walk rather than spinning.
          if (page.rows.length === 0) {
            controller.close();
            return;
          }
        }
        const row = page.rows[index++]!;
        controller.enqueue(line(columns.map((c) => row[c.key])));
        written++;
      } catch (error) {
        controller.error(error);
      }
    },
  });

  return { stream, filename: `${request.name}.csv` };
}
