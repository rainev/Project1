/**
 * The third config family: declared queries (ARCHITECTURE §7.1, decision D-03).
 *
 * A query joins along RELATIONS THE MODELS ALREADY DECLARE (`x-lookup`), filters
 * on values, groups and measures — and nothing else. There is no free-text SQL
 * here and no way to name a table: `from` and `via` resolve through the model
 * registry, so every identifier that reaches a statement is one the codebase
 * owns. That is §22's rule, kept by construction rather than by escaping.
 *
 * Everything this file rejects, it rejects at BOOT, naming the file and the
 * path: an unknown model, a join that no lookup backs, an encrypted column, a
 * parameter used and never declared. A query that loads is a query that runs.
 */
import type { ValidateFunction } from 'ajv';
import jexl from 'jexl';
import { ajv, ConfigError, formatSchemaErrors, loadFamily } from '../config/loader.ts';
import { SYSTEM_FIELDS } from '../config/system-fields.ts';
import type { Model } from '../model.ts';
import type { AggregateFn, FilterOp } from '../db/adapter.ts';
import { TENANT_EXPRESSION, tenancyDerivedScopeKeys, tenantScopeKeys } from '../tenancy.ts';

const IDENTIFIER = /^[A-Za-z_][A-Za-z0-9_]*$/;
/** The same operator set the generic surface allows. One enum, not two. */
const FILTER_OPS: FilterOp[] = ['eq', 'ne', 'gt', 'gte', 'lt', 'lte', 'contains', 'in'];
const AGGREGATE_FNS: AggregateFn[] = ['count', 'sum', 'avg', 'min', 'max'];
const PARAM_TYPES = ['string', 'number', 'integer', 'boolean'] as const;

export type ParamType = (typeof PARAM_TYPES)[number];

type Compiled = { evalSync(context: unknown): unknown };

export interface QueryParam {
  type: ParamType;
  required: boolean;
  default?: unknown;
}

/** One participating model: the root, or something joined to it. */
export interface QuerySide {
  alias: string;
  model: Model;
}

export interface QueryJoinDef extends QuerySide {
  kind: 'inner' | 'left';
  leftAlias: string;
  /** The `x-lookup` field on the left side. */
  leftColumn: string;
  /** Always `id`: a lookup stores the target's id. */
  rightColumn: string;
}

export interface QuerySelectDef {
  alias: string;
  model: Model;
  column: string;
  /** The key this column has in the result rows. */
  key: string;
  /** The heading a reader sees, when the author wrote one. */
  label?: string;
}

export interface QueryPredicateDef {
  alias: string;
  model: Model;
  column: string;
  op: FilterOp;
  /** JEXL over `{ params, actor, now }`, evaluated per request and BOUND. */
  value: Compiled;
  source: string;
}

export interface QueryMeasureDef {
  op: AggregateFn;
  alias?: string;
  model?: Model;
  column?: string;
  key: string;
  /** The heading a reader sees, when the author wrote one. */
  label?: string;
}

export interface QueryOrderDef {
  alias?: string;
  model?: Model;
  column?: string;
  /** The `as` of a measure, when the report is ordered by its own numbers. */
  measure?: string;
  dir: 'asc' | 'desc';
}

export interface Query {
  name: string;
  title?: string;
  description?: string;
  source: string;
  root: QuerySide;
  joins: QueryJoinDef[];
  /** Every participating side, root first. */
  sides: QuerySide[];
  select: QuerySelectDef[];
  /** Fetched so `x-field-access` can be evaluated per row; never returned. */
  policyColumns: QuerySelectDef[];
  where: QueryPredicateDef[];
  groupBy: QuerySelectDef[];
  measures: QueryMeasureDef[];
  orderBy: QueryOrderDef[];
  params: Record<string, QueryParam>;
  /** `x-access.read`, compiled. Absent means deny, exactly as a model's does. */
  access?: Compiled;
  /** True when the query groups or measures: a shape, not a page of rows. */
  aggregate: boolean;
  /**
   * `x-cross-tenant` — this query may read across tenants for an actor holding
   * the reserved `platform` role (Q-122). The flag is a REQUEST to widen, never
   * a grant: the runtime still requires the role and the query's own `x-access`,
   * and the scope is widened to a bound list of orgs rather than emptied (Q-123).
   */
  crossTenant: boolean;
}

const META_SCHEMA = {
  type: 'object',
  required: ['$id', 'from'],
  additionalProperties: false,
  properties: {
    $schema: { type: 'string' },
    $id: { type: 'string', pattern: IDENTIFIER.source },
    title: { type: 'string' },
    description: { type: 'string' },
    from: { type: 'string', pattern: IDENTIFIER.source },
    'x-cross-tenant': { type: 'boolean' },
    join: {
      type: 'array',
      items: {
        type: 'object',
        required: ['via'],
        additionalProperties: false,
        properties: {
          via: { type: 'string' },
          as: { type: 'string', pattern: IDENTIFIER.source },
          kind: { enum: ['inner', 'left'] },
        },
      },
    },
    select: {
      type: 'array',
      items: {
        oneOf: [
          { type: 'string' },
          {
            type: 'object',
            required: ['field'],
            additionalProperties: false,
            properties: {
              field: { type: 'string' },
              as: { type: 'string', pattern: IDENTIFIER.source },
              label: { type: 'string' },
            },
          },
        ],
      },
    },
    where: {
      type: 'array',
      items: {
        type: 'object',
        required: ['field', 'op', 'value'],
        additionalProperties: false,
        properties: {
          field: { type: 'string' },
          op: { enum: FILTER_OPS },
          value: { type: 'string', minLength: 1 },
        },
      },
    },
    groupBy: {
      type: 'array',
      items: {
        oneOf: [
          { type: 'string' },
          {
            type: 'object',
            required: ['field'],
            additionalProperties: false,
            properties: {
              field: { type: 'string' },
              as: { type: 'string', pattern: IDENTIFIER.source },
              label: { type: 'string' },
            },
          },
        ],
      },
    },
    measures: {
      type: 'array',
      items: {
        type: 'object',
        required: ['op', 'as'],
        additionalProperties: false,
        properties: {
          op: { enum: AGGREGATE_FNS },
          field: { type: 'string' },
          as: { type: 'string', pattern: IDENTIFIER.source },
          label: { type: 'string' },
        },
      },
    },
    orderBy: {
      type: 'array',
      items: {
        type: 'object',
        required: ['field'],
        additionalProperties: false,
        properties: { field: { type: 'string' }, dir: { enum: ['asc', 'desc'] } },
      },
    },
    params: {
      type: 'object',
      additionalProperties: {
        type: 'object',
        required: ['type'],
        additionalProperties: false,
        properties: {
          type: { enum: PARAM_TYPES },
          required: { type: 'boolean' },
          default: {},
        },
      },
    },
    'x-access': {
      type: 'object',
      additionalProperties: false,
      properties: { read: { type: 'string', minLength: 1 } },
    },
  },
} as const;

const validateMeta: ValidateFunction = ajv.compile(META_SCHEMA);

/** `params.<name>` as it appears in a `where` value, so an undeclared one is a boot error. */
const PARAM_REFERENCE = /\bparams\.([A-Za-z_][A-Za-z0-9_]*)/g;

/** `row.<field>` as it appears in an `x-field-access` expression (see below). */
const ROW_REFERENCE = /\brow\.([A-Za-z_][A-Za-z0-9_]*)/g;

export function compileQuery(doc: unknown, source: string, models: Map<string, Model>): Query {
  if (!validateMeta(doc)) throw new ConfigError(source, formatSchemaErrors(validateMeta.errors));
  const raw = doc as Record<string, any>;
  const fail = (detail: string) => new ConfigError(source, detail);

  const rootModel = models.get(raw.from);
  if (!rootModel) {
    throw fail(`from: names unknown model "${raw.from}" — known: ${[...models.keys()].join(', ')}`);
  }

  const sides: QuerySide[] = [{ alias: rootModel.name, model: rootModel }];
  const byAlias = new Map<string, QuerySide>([[rootModel.name, sides[0]!]]);

  const joins: QueryJoinDef[] = (raw.join ?? []).map((join: any, index: number) => {
    const where = `join[${index}].via`;
    // A join is only ever a relation the models already declare. `via` names a
    // lookup FIELD, not a table, so there is nothing here to resolve but a
    // key of `model.lookups`.
    const [left, field] = join.via.includes('.')
      ? (join.via.split('.') as [string, string])
      : [rootModel.name, join.via as string];
    const leftSide = byAlias.get(left);
    if (!leftSide) {
      throw fail(`${where}: "${join.via}" joins from "${left}", which is not in this query — available: ${[...byAlias.keys()].join(', ')}`);
    }
    const lookup = leftSide.model.lookups[field];
    if (!lookup) {
      const declared = Object.keys(leftSide.model.lookups);
      throw fail(
        `${where}: "${field}" is not a declared relation on "${leftSide.model.name}" — ` +
        `joins follow x-lookup only${declared.length ? `, and it declares ${declared.join(', ')}` : ' and it declares none'}`,
      );
    }
    const target = models.get(lookup.model);
    if (!target) throw fail(`${where}: "${field}" points at unknown model "${lookup.model}"`);

    const alias: string = join.as ?? target.name;
    if (byAlias.has(alias)) {
      throw fail(`join[${index}].as: "${alias}" is already used in this query — give this join a different \`as\``);
    }
    const side: QuerySide = { alias, model: target };
    sides.push(side);
    byAlias.set(alias, side);
    return {
      alias, model: target, kind: (join.kind ?? 'left') as 'inner' | 'left',
      leftAlias: leftSide.alias, leftColumn: field, rightColumn: 'id',
    };
  });

  /**
   * Every participating model must be scoped. An unscoped model in a join is a
   * cross-tenant read waiting to happen, and the adapter refuses one anyway —
   * better to say so at boot, naming the model, than at the first request.
   */
  for (const side of sides) {
    if (Object.keys(side.model.scope).length === 0) {
      throw fail(`model "${side.model.name}" declares no x-scope, so it cannot take part in a query`);
    }
  }

  const crossTenant: boolean = raw['x-cross-tenant'] === true;
  if (crossTenant) {
    // Every participating model must have a tenant key to widen. A model scoped
    // by something else entirely cannot take part: there would be nothing to
    // widen and the read would silently stay inside one tenant, or worse, the
    // author would assume it had widened (Q-124).
    for (const side of sides) {
      if (tenantScopeKeys(side.model).length === 0) {
        throw fail(
          `x-cross-tenant: "${side.model.name}" has no tenant scope key, so there is nothing to widen — ` +
          `its x-scope declares ${Object.keys(side.model.scope).join(', ')}, and a tenant key is one ` +
          `that reads \`${TENANT_EXPRESSION}\` and nothing else`,
        );
      }
      /**
       * A key that DERIVES from tenancy is the case that slips through a
       * two-way test (Q-124). `{ shard: "actor.orgId + '-eu'" }` cannot be widened — the
       * bound values would be wrong — and cannot be left alone either, because
       * it pins the read to this actor's own tenant while the query claims to
       * span every tenant. The author would get one org's rows back and no
       * indication the widening had not happened.
       */
      const derived = tenancyDerivedScopeKeys(side.model);
      if (derived.length) {
        throw fail(
          `x-cross-tenant: "${side.model.name}" scopes ${derived.map((k) => `"${k}"`).join(', ')} by an ` +
          `expression derived from \`${TENANT_EXPRESSION}\` rather than a bare read of it, so a ` +
          `cross-tenant read of it cannot be honest: widening binds the wrong values, and not widening ` +
          `silently keeps the read inside one tenant — scope by \`${TENANT_EXPRESSION}\` directly, or ` +
          `leave this model out of the query`,
        );
      }
    }
    if (!raw['x-access']?.read) {
      throw fail('x-cross-tenant: a cross-tenant query must declare x-access.read — the platform role is required as well, never instead');
    }
  }

  /** `<alias>.<field>`, resolved to a model-owned column. Encrypted columns are refused. */
  const resolve = (reference: unknown, where: string): { side: QuerySide; column: string } => {
    if (typeof reference !== 'string' || !reference.includes('.')) {
      throw fail(`${where}: "${String(reference)}" must be written <${[...byAlias.keys()].join('|')}>.<field>`);
    }
    const [alias, ...rest] = reference.split('.');
    const field = rest.join('.');
    const side = byAlias.get(alias!);
    if (!side) {
      throw fail(`${where}: "${reference}" names "${alias}", which is not in this query — available: ${[...byAlias.keys()].join(', ')}`);
    }
    const known = [...side.model.columns, ...SYSTEM_FIELDS];
    if (!known.includes(field)) {
      throw fail(`${where}: "${reference}" names unknown field "${field}" on "${side.model.name}" — known: ${known.join(', ')}`);
    }
    /**
     * Every column a query names — select, where, groupBy, orderBy, a measure —
     * arrives here, so one check seals all of them. A report is a read like any
     * other, and an internal field is not readable by anyone.
     */
    if (side.model.props[field]?.internal) {
      throw fail(`${where}: "${reference}" is x-internal on "${side.model.name}" — it is stored and never read, so no query may name it`);
    }
    if (field in side.model.encrypted) {
      throw fail(
        `${where}: "${reference}" is encrypted. Ciphertext does not join, sort, group or aggregate, ` +
        `and a query cannot decrypt it — remove it or drop x-encrypt on "${side.model.name}.${field}"`,
      );
    }
    return { side, column: field };
  };

  // A lookup's own field is the join key; refusing an encrypted one at boot
  // keeps `resolve` the single place that check lives.
  for (const join of joins) {
    resolve(`${join.leftAlias}.${join.leftColumn}`, `join via "${join.leftColumn}"`);
  }

  const params: Record<string, QueryParam> = {};
  for (const [name, def] of Object.entries<any>(raw.params ?? {})) {
    if (!IDENTIFIER.test(name)) throw fail(`params."${name}" is not a safe identifier`);
    params[name] = { type: def.type, required: def.required === true, default: def.default };
  }

  const measures: QueryMeasureDef[] = (raw.measures ?? []).map((measure: any, index: number) => {
    if (measure.op === 'count' && !measure.field) return { op: measure.op, key: measure.as, label: measure.label };
    if (!measure.field) {
      throw fail(`measures[${index}]: ${measure.op} needs a field (only count may omit one)`);
    }
    const { side, column } = resolve(measure.field, `measures[${index}].field`);
    return { op: measure.op, alias: side.alias, model: side.model, column, key: measure.as, label: measure.label };
  });

  const groupBy: QuerySelectDef[] = (raw.groupBy ?? []).map((entry: any, index: number) => {
    const reference = typeof entry === 'string' ? entry : entry.field;
    const { side, column } = resolve(reference, `groupBy[${index}]`);
    return {
      alias: side.alias, model: side.model, column,
      key: (typeof entry === 'string' ? undefined : entry.as) ?? `${side.alias}_${column}`,
      label: typeof entry === 'string' ? undefined : entry.label,
    };
  });

  const aggregate = measures.length > 0 || groupBy.length > 0;

  if (aggregate && raw.select) {
    throw fail('a query either selects columns or groups and measures — not both');
  }
  if (aggregate && measures.length === 0) {
    throw fail('groupBy without measures returns distinct values, not a report — add a measure');
  }

  const select: QuerySelectDef[] = (raw.select ?? []).map((entry: any, index: number) => {
    const reference = typeof entry === 'string' ? entry : entry.field;
    const { side, column } = resolve(reference, `select[${index}]`);
    // The key is the author's `as`, or `<alias>_<field>` — predictable, and
    // never ambiguous between two models that share a field name.
    return {
      alias: side.alias, model: side.model, column,
      key: entry.as ?? `${side.alias}_${column}`,
      label: typeof entry === 'string' ? undefined : entry.label,
    };
  });

  if (!aggregate && select.length === 0) {
    throw fail('select is required — a query must say which columns it returns');
  }

  /**
   * Columns a FIELD POLICY needs, which the query never asked for.
   *
   * `x-field-access.memo.read: "row.ownerId == actor.id"` is evaluated per row,
   * exactly as it is in a list — and a report that selected `memo` but not
   * `ownerId` would evaluate it against an absent value and silently drop the
   * column for everyone. So the policy's own references are fetched alongside,
   * and dropped again before the rows leave the executor: an author writes the
   * report they want, and the policy still means what it says.
   */
  const policyColumns: QuerySelectDef[] = [];
  const seen = new Set(select.map((c) => `${c.alias}.${c.column}`));
  for (const column of select) {
    const policy = column.model.fieldAccess[column.column]?.read;
    if (!policy) continue;
    for (const [, field] of policy.matchAll(ROW_REFERENCE)) {
      const key = `${column.alias}.${field}`;
      if (seen.has(key)) continue;
      seen.add(key);
      const { side, column: resolved } = resolve(key,
        `x-field-access.${column.column}.read on "${column.model.name}"`);
      policyColumns.push({ alias: side.alias, model: side.model, column: resolved, key });
    }
  }
  const keys = new Set<string>();
  for (const column of [...select, ...groupBy]) {
    if (keys.has(column.key)) throw fail(`two columns both land on the key "${column.key}" — give one an \`as\``);
    keys.add(column.key);
  }
  for (const measure of measures) {
    if (keys.has(measure.key)) throw fail(`two columns both land on the key "${measure.key}" — give one an \`as\``);
    keys.add(measure.key);
  }

  const where: QueryPredicateDef[] = (raw.where ?? []).map((predicate: any, index: number) => {
    const { side, column } = resolve(predicate.field, `where[${index}].field`);
    // A parameter used and never declared is the typo this family exists to
    // catch: it would evaluate to undefined and silently drop the predicate.
    for (const [, name] of String(predicate.value).matchAll(PARAM_REFERENCE)) {
      if (!(name in params)) {
        throw fail(
          `where[${index}].value uses params.${name}, which is not declared — ` +
          `declared: ${Object.keys(params).join(', ') || 'none'}`,
        );
      }
    }
    let value: Compiled;
    try {
      value = jexl.compile(predicate.value);
    } catch (error) {
      throw fail(`where[${index}].value: invalid expression "${predicate.value}" — ${(error as Error).message}`);
    }
    return { alias: side.alias, model: side.model, column, op: predicate.op, value, source: predicate.value };
  });

  const orderBy: QueryOrderDef[] = (raw.orderBy ?? []).map((entry: any, index: number) => {
    const dir = entry.dir ?? 'asc';
    // "The top five customers by note count" orders by the measure, not by a
    // column — so a measure's own `as` is a valid thing to order by.
    const measure = measures.find((m) => m.key === entry.field);
    if (measure) return { measure: measure.key, dir };
    const { side, column } = resolve(entry.field, `orderBy[${index}].field`);
    if (aggregate && !groupBy.some((g) => g.alias === side.alias && g.column === column)) {
      throw fail(`orderBy[${index}]: "${entry.field}" is neither grouped nor measured, so it has no value per row`);
    }
    return { alias: side.alias, model: side.model, column, dir };
  });

  if (crossTenant) {
    /**
     * A cross-tenant report must say which tenant each row belongs to (Q-125).
     * Rows from several orgs in one unlabelled grid are not a convenience — they
     * are a mislabelling waiting to be acted on, and the same column is what
     * makes the CSV readable. Checked here rather than above because it is a
     * statement about the OUTPUT, which only exists once select and groupBy are
     * resolved.
     */
    const outputs = [...select, ...groupBy];
    const labelled = outputs.some((output) => tenantScopeKeys(output.model).includes(output.column));
    if (!labelled) {
      const options = sides
        .flatMap((side) => tenantScopeKeys(side.model).map((key) => `${side.alias}.${key}`))
        .join(', ');
      throw fail(
        `x-cross-tenant: a cross-tenant query must return the tenant it is reading from — ` +
        `add one of ${options} to select${aggregate ? ' or groupBy' : ''}`,
      );
    }
  }

  let access: Compiled | undefined;
  const readExpression: string | undefined = raw['x-access']?.read;
  if (readExpression) {
    try {
      access = jexl.compile(readExpression);
    } catch (error) {
      throw fail(`x-access.read: invalid expression "${readExpression}" — ${(error as Error).message}`);
    }
  }

  return {
    name: raw.$id, title: raw.title, description: raw.description, source,
    root: sides[0]!, joins, sides, select, policyColumns, where, groupBy, measures, orderBy,
    params, access, aggregate, crossTenant,
  };
}

export async function loadQueries(dir: string, models: Map<string, Model>): Promise<Map<string, Query>> {
  const queries = new Map<string, Query>();
  const loaded = await loadFamily(dir, {
    meta: validateMeta,
    compile: (doc, source) => compileQuery(doc, source, models),
  });
  for (const { source, value } of loaded) {
    if (queries.has(value.name)) throw new ConfigError(source, `duplicate query "${value.name}"`);
    queries.set(value.name, value);
  }
  return queries;
}
