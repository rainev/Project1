/**
 * What a declared query becomes by the time a storage adapter sees it.
 *
 * This is the seam WP-04 implements for PostgreSQL and MariaDB: it names
 * TABLES and COLUMNS — already resolved from the codebase's own model
 * definitions — and BOUND VALUES, nothing else. An adapter never looks a model
 * up, never sees config text, and never decides policy: the scope values for
 * every participating table are handed to it already evaluated (§11, §22).
 *
 * Query aliases are model names, which the model compiler has already checked
 * against `^[A-Za-z_][A-Za-z0-9_]*$`. Output keys are framework-generated
 * (`c0`, `m0`), so an author's label never reaches SQL either — the same rule
 * `aggregate` follows for measures.
 */
import type { AggregateFn, FilterOp, Row, Scope } from '../db/adapter.ts';

export interface QuerySource {
  /** The model's name, used to qualify columns. */
  alias: string;
  table: string;
}

export interface QueryJoin extends QuerySource {
  kind: 'inner' | 'left';
  /** `<leftAlias>.<leftColumn> = <alias>.<rightColumn>` — a declared `x-lookup`. */
  leftAlias: string;
  leftColumn: string;
  rightColumn: string;
  /**
   * The joined model's own scope, bound into the JOIN condition rather than
   * the WHERE clause. In a LEFT JOIN those are not the same statement: in WHERE
   * it would quietly become an inner join; in ON, another tenant's row simply
   * does not match.
   */
  scope: Scope;
}

export interface QueryColumn {
  alias: string;
  column: string;
  /** Framework-generated output key (`c0`), mapped back to the author's label above. */
  as: string;
}

export interface QueryMeasure {
  op: AggregateFn;
  /** Absent for `count`, which counts rows. */
  alias?: string;
  column?: string;
  as: string;
}

export interface QueryPredicate {
  alias: string;
  column: string;
  op: FilterOp;
  /** Already evaluated. A predicate whose value did not resolve is not here. */
  value: unknown;
}

export interface QueryOrder {
  /** A column of a participating table... */
  alias?: string;
  column?: string;
  /** ...or a measure, by its generated key (`m0`) — "top customers by count". */
  measure?: string;
  dir: 'asc' | 'desc';
}

/** One query, one actor, one request: everything resolved, nothing to interpret. */
export interface ExecutableQuery {
  name: string;
  from: QuerySource;
  joins: QueryJoin[];
  /** Row queries select columns; aggregate queries have measures instead. */
  select: QueryColumn[];
  groupBy: QueryColumn[];
  measures: QueryMeasure[];
  where: QueryPredicate[];
  /** The root model's scope, bound into WHERE. Never empty. */
  scope: Scope;
  orderBy: QueryOrder[];
  limit: number;
  /** Keyset cursor, for row queries only. Aggregate results are not paged. */
  cursor?: string;
}

export interface QueryPage {
  rows: Row[];
  nextCursor?: string;
}
