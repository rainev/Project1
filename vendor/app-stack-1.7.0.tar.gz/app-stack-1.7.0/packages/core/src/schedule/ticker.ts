/**
 * The scheduler: one ticker for every declared schedule (WP-06 W-121).
 *
 * One, not one per schedule: a timer per declaration is a number that grows
 * with the config, and each would have to rediscover the same durable state
 * anyway. This wakes up, asks `_schedule` what is due, and runs it.
 *
 * ## The missed-run policy, stated rather than emergent
 *
 * **A due time that passed while nothing was running fires once, late, and
 * never backfills.**
 *
 * The reasoning, since both answers are defensible. A missed run usually means
 * work is undone and the work still needs doing — a sweep that did not sweep
 * leaves rows in the state the sweep exists to clear — so skipping silently is
 * the worse failure. But firing once per missed interval turns an outage into
 * an amplifier: a five-minute job down for a day would wake up owing 288 runs
 * and spend the recovery hammering the database it just got back. So the next
 * due time is computed from **now**, not from the missed slot, which collapses
 * any backlog into exactly one run.
 *
 * What that costs, said plainly: a schedule meant to fire at a particular time
 * of day will fire at the wrong time of day after downtime. That is the price
 * of `every`-style intervals, and it is why wall-clock scheduling is not built
 * here rather than half-built — see the handoff.
 *
 * A late run is counted in `lateRuns`, so "did we miss any" is a column.
 *
 * **One process.** Like the outbox worker, claiming is "read due, run, advance";
 * correct for one ticker and double-running for two. The same `SELECT … FOR
 * UPDATE SKIP LOCKED` per engine that the outbox wants is what would make two
 * safe, and it is the same single ask against WP-04.
 */
import type { DBAdapter, Filter, Row } from '../db/adapter.ts';
import type { Model, Schedule } from '../model.ts';
import type { Actor, Envelope } from '../engine/types.ts';
import { createAuditWriter, type Attempted } from '../engine/audit.ts';
import { compileExpression, type Compiled } from '../expressions.ts';
import { ORG } from '../auth/system-models.ts';
import { SCHEDULE } from './model.ts';

export type ExecuteFn = (envelope: Envelope, tx: DBAdapter, depth: number) => Promise<unknown>;

export interface SchedulerOptions {
  db: DBAdapter;
  models: Map<string, Model>;
  execute: ExecuteFn;
  /** How often to look for due rows. */
  intervalMs?: number;
  /** Injected so a test can move time without sleeping. */
  now?: () => Date;
}

export interface SchedulerTick {
  /** Schedules whose due time had arrived. */
  due: number;
  /** Of those, how many were already overdue when the ticker reached them. */
  late: number;
  /** Operations actually performed. */
  ran: number;
  failed: number;
}

interface Declared { model: Model; name: string; schedule: Schedule }

/** Compiled once, for the same reason every other expression is: at boot. */
const compiledData = new WeakMap<Schedule, [string, { literal: unknown } | { expression: Compiled }][]>();

function dataOf(schedule: Schedule, where: string): [string, { literal: unknown } | { expression: Compiled }][] {
  const cached = compiledData.get(schedule);
  if (cached) return cached;
  const compiled = Object.entries(schedule.data).map(([field, value]) =>
    [field, typeof value === 'string'
      ? { expression: compileExpression(value, `${where}.data.${field}`) }
      : { literal: value }] as [string, { literal: unknown } | { expression: Compiled }]);
  compiledData.set(schedule, compiled);
  return compiled;
}

/** `field:op:value`, the same spelling the intake parses from a query string. */
function parseFilter(raw: string): Filter {
  const [field, op, ...rest] = raw.split(':');
  const value = rest.join(':');
  const coerced: unknown = op === 'in'
    ? value.split(',')
    : value === 'true' ? true
      : value === 'false' ? false
        : value !== '' && !Number.isNaN(Number(value)) ? Number(value) : value;
  return { field: field!, op: op as Filter['op'], value: coerced };
}

/**
 * The database was busy, as opposed to the work having failed.
 *
 * A worker on its own connection still contends with the request path for the
 * file, and SQLite answers a writer that arrives mid-write by refusing. That is
 * not a result: consuming the run for it would turn a moment's contention into
 * a skipped sweep, and counting it as a failure would put a database condition
 * in an audit row as if the application had done something wrong. So the row is
 * left exactly as it was and the next tick takes it.
 *
 * The lasting answer is a busy timeout on the connection, which lives in
 * `db/**` and is not this package's to write.
 */
const isContention = (error: unknown): boolean =>
  /database is locked|database table is locked|busy|cannot start a transaction/i.test(
    String((error as Error)?.message ?? error),
  );

export function createScheduler(options: SchedulerOptions) {
  const { db, models, execute, intervalMs = 1000, now = () => new Date() } = options;
  const audit = createAuditWriter(db);

  /** Every schedule any model declares, flattened once. */
  const declared: Declared[] = [];
  for (const model of models.values()) {
    for (const [name, schedule] of Object.entries(model.schedules)) {
      declared.push({ model, name, schedule });
      // Compile the data expressions now: a broken one must fail the boot, not
      // the first run, which nobody is watching.
      dataOf(schedule, `${model.name}.x-schedules.${name}`);
    }
  }

  let timer: ReturnType<typeof setTimeout> | undefined;
  let running = false;

  /**
   * Make sure every (org × declared schedule) has a row.
   *
   * First sight of a schedule sets its due time one interval out rather than
   * now: declaring a schedule should not fire it, and a server that restarts
   * often would otherwise run every schedule on every boot.
   */
  async function ensureRows(at: Date): Promise<Row[]> {
    const orgs = await db.systemList(ORG);
    const existing = await db.systemList(SCHEDULE);
    const rows: Row[] = [];

    for (const org of orgs) {
      const orgId = String(org.id);
      for (const { model, name, schedule } of declared) {
        const found = existing.find((r) =>
          String(r.orgId) === orgId && String(r.model) === model.name && String(r.name) === name);
        if (found) {
          rows.push(found);
          continue;
        }
        rows.push(await db.systemCreate(SCHEDULE, {
          orgId, model: model.name, name, every: schedule.every,
          nextRunAt: new Date(at.getTime() + schedule.everyMs).toISOString(),
          lastRunAt: null, lastOutcome: null, lastError: null, lastCount: 0, runs: 0, lateRuns: 0,
        }));
      }
    }
    return rows;
  }

  /** Run one schedule for one org, on its own transaction. */
  async function run(entry: Declared, orgId: string): Promise<number> {
    const { model, name, schedule } = entry;
    const actor: Actor = {
      // Not a user id: nothing can log in as this, and an audit row that named a
      // person for work no person did would be a lie.
      id: `schedule:${model.name}.${name}`,
      roles: [...schedule.roles],
      orgId,
    };
    const at = now().toISOString();
    const meta: Envelope['meta'] = { requestId: crypto.randomUUID(), at, source: 'schedule' };

    const data: Row = {};
    for (const [field, value] of dataOf(schedule, `${model.name}.x-schedules.${name}`)) {
      const resolved = 'literal' in value ? value.literal : value.expression.evalSync({ actor, now: at });
      if (resolved !== undefined && resolved !== null) data[field] = resolved;
    }

    return db.tx(async (tx) => {
      // No `where` means the operation is not about existing rows — a schedule
      // that creates something. One run, no id.
      if (schedule.where.length === 0) {
        await execute({ actor, op: schedule.op, model: model.name, data, query: {}, meta }, tx, 0);
        return 1;
      }

      /**
       * Which rows, decided by the ENGINE and not by this file.
       *
       * The list goes through `execute` like any other read, so org scope is
       * injected, the filter is resolved against the model's own allowlist, and
       * a schedule sees exactly the rows an operator with these roles would.
       */
      const page = await execute({
        actor, op: 'list', model: model.name, data: {},
        query: { limit: schedule.limit, filters: schedule.where.map(parseFilter) },
        meta,
      }, tx, 0) as { rows: Row[] };

      for (const row of page.rows) {
        await execute({
          actor, op: schedule.op, model: model.name, id: String(row.id), data: { ...data }, query: {}, meta,
        }, tx, 0);
      }
      return page.rows.length;
    });
  }

  async function tick(): Promise<SchedulerTick> {
    const result: SchedulerTick = { due: 0, late: 0, ran: 0, failed: 0 };
    if (running || declared.length === 0) return result;
    running = true;
    try {
      const at = now();
      const iso = at.toISOString();
      const rows = await ensureRows(at);

      for (const row of rows) {
        const dueAt = String(row.nextRunAt ?? '');
        if (dueAt > iso) continue;
        const entry = declared.find((d) => d.model.name === String(row.model) && d.name === String(row.name));
        if (!entry) continue;   // a schedule that was removed from the config

        result.due++;
        // Late means the due time had already passed by more than one interval:
        // the ticker was not running, or was busy. One run, not a backlog.
        const late = at.getTime() - Date.parse(dueAt) > entry.schedule.everyMs;
        if (late) result.late++;

        const attempted: Attempted = {
          actor: { id: `schedule:${entry.model.name}.${entry.name}`, roles: [...entry.schedule.roles], orgId: String(row.orgId) },
          op: `schedule:${entry.name}`,
          model: entry.model.name,
          data: {},
          meta: { requestId: crypto.randomUUID(), at: iso, source: 'schedule' },
        };

        try {
          const count = await run(entry, String(row.orgId));
          result.ran += count;
          await db.systemUpdate(SCHEDULE, String(row.id), {
            // From NOW, not from the slot that was missed: a backlog collapses
            // into one run rather than becoming a queue of them.
            nextRunAt: new Date(at.getTime() + entry.schedule.everyMs).toISOString(),
            lastRunAt: iso, lastOutcome: 'ok', lastError: null, lastCount: count,
            runs: Number(row.runs ?? 0) + 1,
            lateRuns: Number(row.lateRuns ?? 0) + (late ? 1 : 0),
          });
          /**
           * Audited only when it DID something.
           *
           * A five-second sweep over a quiet database would otherwise write a
           * row every five seconds saying nothing happened, which grows
           * `_audits` faster than the application does and buries the rows that
           * matter. That the ticker is alive is `_schedule.lastRunAt`'s job —
           * a heartbeat belongs in the heartbeat table. A run that touched a
           * row, or ran late, is a fact about the application and is recorded.
           */
          if (count > 0 || late) {
            await audit({
              envelope: attempted, status: 200,
              detail: `${count} row(s)${late ? ', ran late' : ''}`,
            });
          }
        } catch (error) {
          if (isContention(error)) {
            // Untouched: still due, still owed, and the next tick takes it.
            continue;
          }
          const detail = (error as Error).message ?? String(error);
          result.failed++;
          await db.systemUpdate(SCHEDULE, String(row.id), {
            // Still advanced: a schedule that fails must not spin on every tick.
            nextRunAt: new Date(at.getTime() + entry.schedule.everyMs).toISOString(),
            lastRunAt: iso, lastOutcome: 'error', lastError: detail,
            runs: Number(row.runs ?? 0) + 1,
            lateRuns: Number(row.lateRuns ?? 0) + (late ? 1 : 0),
          });
          await audit({ envelope: attempted, status: 500, outcome: 'error', detail });
          console.error(`[schedule] ${entry.model.name}.${entry.name} failed: ${detail}`);
        }
      }
    } finally {
      running = false;
    }
    return result;
  }

  function arm(delay: number) {
    clearTimeout(timer);
    timer = setTimeout(() => {
      tick().catch((error) => console.error('[schedule] tick failed:', error)).finally(() => arm(intervalMs));
    }, delay);
    (timer as { unref?: () => void }).unref?.();
  }

  return {
    tick,
    /** What the app declared, for a boot line and for tests. */
    declared: declared.map((d) => `${d.model.name}.${d.name} every ${d.schedule.every}`),
    start() { if (declared.length) arm(intervalMs); },
    stop() { clearTimeout(timer); timer = undefined; },
  };
}

export type Scheduler = ReturnType<typeof createScheduler>;
