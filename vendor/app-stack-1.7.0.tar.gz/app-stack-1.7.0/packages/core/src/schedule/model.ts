/**
 * `_schedule` — when each declared schedule is next due (WP-06 W-121).
 *
 * One row per (org, model, schedule). Durable, because the whole question a
 * scheduler has to answer is "what should have happened while nothing was
 * running", and an in-memory timer cannot answer it: it starts counting from
 * the moment the process did.
 *
 * Framework-owned and `_`-prefixed, so generic dispatch refuses it — when the
 * next sweep runs is not something a tenant reads, writes or lists.
 */
import { compileModel, type Model } from '../model.ts';

export const SCHEDULE: Model = compileModel({
  $id: 'schedule',
  /**
   * When each declared schedule last ran, how it went, and how often it ran
   * late. Operational metadata only — it carries no payload, so nothing here
   * needs sealing.
   */
  'x-dispatch': 'read',
  'x-access': { read: "'admin' in actor.roles || 'platform' in actor.roles" },
  'x-scope': { orgId: 'actor.orgId' },
  type: 'object',
  properties: {
    /** The model the schedule is declared on, and the schedule's own name. */
    model: { type: 'string' },
    name: { type: 'string' },
    /** The declared interval, so a changed `every` is visible in the row. */
    every: { type: 'string' },
    /** ISO. The row is due when this is in the past. */
    nextRunAt: { type: 'string' },
    lastRunAt: { type: 'string' },
    /** 'ok' | 'error' — the last run's outcome, for reading the table by eye. */
    lastOutcome: { type: 'string' },
    lastError: { type: 'string' },
    /** How many rows the last run touched. */
    lastCount: { type: 'integer' },
    /** How many times it has run, ever. */
    runs: { type: 'integer' },
    /**
     * How many times a run started late — a due time that had already passed
     * when the ticker got to it, which is what a restart after downtime looks
     * like. Counted rather than inferred, so "did we miss any" is a column and
     * not an archaeology exercise.
     */
    lateRuns: { type: 'integer' },
  },
  'x-storage': { table: '_schedule', notNull: ['model', 'name'] },
}, 'framework:schedule');
