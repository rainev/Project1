/**
 * Two YAML shapes that this framework's config hits often, that the parser
 * accepts, and that the meta-schema then reports as something else entirely.
 * Both are checked against the raw text, because parsing is what destroys the
 * evidence: by the time there is a document to validate, the truncated value
 * and the split key look exactly like what the author wrote.
 *
 *  - **An unquoted `#` after a space starts a comment.** `background: linear-
 *    gradient(90deg, #f43f5e, #f59e0b)` parses to `linear-gradient(90deg,` and
 *    the document is valid. Nothing fails, and a page ships with the value
 *    missing.
 *  - **An unquoted colon in a list item makes the string a mapping.**
 *    `- Build safely: build smart` is a one-key mapping, not a sentence. It
 *    parses, it validates, and view props are passed to components untyped, so
 *    it renders on screen as `{ "Build safely": "build smart" }`.
 *  - **A comma inside a flow mapping ends the entry.** `{ text: One session,
 *    two outcomes }` is a mapping of two keys, the second of which is
 *    `two outcomes: null`. The meta-schema rejects it as
 *    "must NOT have additional properties", which names neither the comma nor
 *    the line.
 *
 * Both rules are written to be quiet: each names a shape that is essentially
 * never intentional, rather than a shape that is merely suspicious.
 */
import { ConfigError } from './loader.ts';

/** A `#` opening a comment: preceded by whitespace and outside any quote. */
function commentStarts(line: string): number[] {
  const out: number[] = [];
  let quote: string | null = null;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (quote) {
      if (c === quote) quote = null;
      continue;
    }
    if (c === '"' || c === "'") quote = c;
    else if (c === '#' && i > 0 && /\s/.test(line[i - 1]!)) out.push(i);
  }
  return out;
}

/** Unclosed `(` or `[` in the text before a comment means the value was cut. */
function unclosed(text: string): boolean {
  let round = 0;
  let square = 0;
  let quote: string | null = null;
  for (const c of text) {
    if (quote) {
      if (c === quote) quote = null;
      continue;
    }
    if (c === '"' || c === "'") quote = c;
    else if (c === '(') round++;
    else if (c === ')') round--;
    else if (c === '[') square++;
    else if (c === ']') square--;
  }
  return round > 0 || square > 0;
}

/**
 * Split a flow-mapping body on its OWN commas — never on one inside a nested
 * sequence, a nested mapping, a quoted scalar or a function call. `{row: [name,
 * email]}` and `{color: "rgba(255, 255, 255, 0.4)"}` are both ordinary config;
 * a rule that splits naively reports every one of them.
 */
function topLevelParts(body: string): string[] {
  const parts: string[] = [];
  let depth = 0;
  let quote: string | null = null;
  let start = 0;
  for (let i = 0; i < body.length; i++) {
    const c = body[i];
    if (quote) {
      if (c === quote) quote = null;
      continue;
    }
    if (c === '"' || c === "'") quote = c;
    else if (c === '[' || c === '{' || c === '(') depth++;
    else if (c === ']' || c === '}' || c === ')') depth--;
    else if (c === ',' && depth === 0) {
      parts.push(body.slice(start, i));
      start = i + 1;
    }
  }
  parts.push(body.slice(start));
  return parts.map((p) => p.trim()).filter(Boolean);
}

/** A colon that belongs to this mapping, not to a nested or quoted one. */
function hasTopLevelColon(part: string): boolean {
  let depth = 0;
  let quote: string | null = null;
  for (let i = 0; i < part.length; i++) {
    const c = part[i];
    if (quote) {
      if (c === quote) quote = null;
      continue;
    }
    if (c === '"' || c === "'") quote = c;
    else if (c === '[' || c === '{' || c === '(') depth++;
    else if (c === ']' || c === '}' || c === ')') depth--;
    else if (c === ':' && depth === 0) return true;
  }
  return false;
}

const HEX = /^#(?:[0-9a-fA-F]{3,4}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})\b/;
/** A key line or a list item — somewhere a value can be truncated. */
const VALUE_LINE = /^\s*(?:-\s+)?(?:[\w.$-]+|"[^"]*"|'[^']*')\s*:|^\s*-\s+\S/;

export interface YamlTrap {
  line: number;
  detail: string;
}

/** Every trap in a YAML source, as `{ line, detail }`. */
export function findYamlTraps(text: string): YamlTrap[] {
  const found: YamlTrap[] = [];
  text.split('\n').forEach((raw, i) => {
    const line = i + 1;
    if (!VALUE_LINE.test(raw)) return;

    // The FIRST `#` is where the value was cut; the ones after it are already
    // inside the comment. One problem, one message.
    for (const at of commentStarts(raw).slice(0, 1)) {
      const rest = raw.slice(at);
      const before = raw.slice(0, at);
      if (HEX.test(rest)) {
        found.push({
          line,
          detail:
            `an unquoted "#" starts a YAML comment, so this value is truncated to ` +
            `"${before.trim()}" — quote the whole value: '${(before.split(':').slice(1).join(':') + rest).trim()}'`,
        });
      } else if (unclosed(before)) {
        found.push({
          line,
          detail:
            `an unquoted "#" starts a YAML comment part-way through a value — ` +
            `"${before.trim()}" is left with an unclosed bracket. Quote the whole value.`,
        });
      }
    }

    // A list item that became a one-key mapping. The tell is a key containing a
    // SPACE: real keys here are identifiers (`type`, `text`, `props`, `x-access`),
    // so a spaced key is prose that lost its quotes. Anything after `#` is a
    // comment and cannot be part of the key.
    const item = /^(\s*)-\s+(?!-)(.*)$/.exec(raw);
    if (item && !item[2]!.trimStart().startsWith('{') && !item[2]!.trimStart().startsWith('[')) {
      const body = item[2]!.split(/\s#/)[0]!;
      const colon = /^([^:'"#]+?):(\s|$)/.exec(body);
      if (colon && /\s/.test(colon[1]!.trim())) {
        found.push({
          line,
          detail:
            `an unquoted ":" makes this list item a mapping, not a string — ` +
            `"${colon[1]!.trim()}" becomes a key and the rest its value. ` +
            `Quote the whole item: '${body.trim()}'`,
        });
      }
    }

    // A flow mapping whose entries do not all carry a colon. It has to be the
    // WHOLE value — `{name}, your seat is confirmed — {reference}` is a
    // template string with two placeholders, not a mapping.
    const flow = /(?::|^\s*-)\s*\{(.*)\}\s*$/.exec(raw);
    if (flow && flow[1]!.includes(',')) {
      const parts = topLevelParts(flow[1]!);
      const bare = parts.filter((p) => !hasTopLevelColon(p));
      if (bare.length > 0) {
        found.push({
          line,
          detail:
            `a comma inside the flow mapping "{${flow[1]!.trim()}}" ends the entry, so ` +
            `"${bare[0]}" is read as a key, not as part of the value before it. ` +
            `Write the mapping in block style, or quote the value containing the comma.`,
        });
      }
    }
  });
  return found;
}

/** Refuse a document whose raw text carries either trap. */
export function assertNoYamlTraps(text: string, source: string): void {
  const traps = findYamlTraps(text);
  if (traps.length === 0) return;
  throw new ConfigError(source, traps.map((t) => `line ${t.line}: ${t.detail}`).join('; '));
}
