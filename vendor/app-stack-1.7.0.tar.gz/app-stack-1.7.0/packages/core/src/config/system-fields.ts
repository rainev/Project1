/** Framework-owned on every model: never author-declared, never client-writable. */
export const SYSTEM_FIELDS = ['id', 'orgId', 'createdAt', 'updatedAt'] as const;
