/**
 * One loader for every config family (ARCHITECTURE §3.1, batch 08 AUD-045/046).
 *
 * A family is a directory of YAML documents, each validated against a
 * meta-schema and compiled into a typed runtime value. This file owns the
 * three things every family needs and none should re-implement: the Ajv
 * instance, the directory scan with the literal-secret guard, and the
 * cross-reference check that turns a typo'd field name into a boot error
 * naming the file, the path and the valid alternatives.
 */
import Ajv, { type ValidateFunction } from 'ajv';
import addFormats from 'ajv-formats';
import { assertNoLiteralSecrets } from '../secrets.ts';
import { assertNoYamlTraps } from './yaml-traps.ts';
import type { Model } from '../model.ts';
import { SYSTEM_FIELDS } from './system-fields.ts';

/** The one Ajv instance: meta-schemas and derived-schema validators alike. */
export const ajv = new Ajv({ allErrors: true, strict: false });
addFormats(ajv);

export class ConfigError extends Error {
  constructor(source: string, detail: string) {
    super(`config error in ${source}: ${detail}`);
    this.name = 'ConfigError';
  }
}

/** Ajv's error list as one line naming each path, for a boot message. */
export function formatSchemaErrors(errors: ValidateFunction['errors']): string {
  return (errors ?? []).map((e) => `${e.instancePath || '/'} ${e.message}`).join('; ');
}

export interface LoadedDocument<T> {
  /** `<dir>/<file>.yaml` — the last two path segments, as boot messages name it. */
  source: string;
  value: T;
}

export interface FamilyOptions<T> {
  /** Compiled meta-schema every document must satisfy. */
  meta: ValidateFunction;
  /** Turns a validated document into its typed runtime value. */
  compile: (doc: any, source: string) => T;
  /**
   * Runs before the meta-schema, so a family can refuse a document with a
   * better message than the schema's. A strict schema rejects a renamed
   * keyword as "must NOT have additional properties", which names neither the
   * keyword nor its replacement.
   */
  preflight?: (doc: unknown, source: string) => void;
  /** Wraps the meta-schema failure; defaults to ConfigError. */
  error?: (source: string, detail: string) => Error;
}

/**
 * Scan a directory of `*.yaml`, guard each document against literal secrets,
 * validate it against the family's meta-schema, and compile it. Directory
 * order is filesystem-dependent; callers that need a stable order sort the
 * result themselves and say so.
 */
export async function loadFamily<T>(dir: string, options: FamilyOptions<T>): Promise<LoadedDocument<T>[]> {
  const out: LoadedDocument<T>[] = [];
  const glob = new Bun.Glob('*.yaml');
  const fail = options.error ?? ((source, detail) => new ConfigError(source, detail));

  for await (const file of glob.scan({ cwd: dir, absolute: true })) {
    const source = file.split('/').slice(-2).join('/');
    const text = await Bun.file(file).text();
    // Before the parse, which is what destroys the evidence.
    assertNoYamlTraps(text, source);
    const doc = Bun.YAML.parse(text);
    // Config names secrets, it never carries them (§10).
    assertNoLiteralSecrets(doc, source);
    options.preflight?.(doc, source);
    if (!options.meta(doc)) throw fail(source, formatSchemaErrors(options.meta.errors));
    out.push({ source, value: options.compile(doc, source) });
  }
  return out;
}

/**
 * A field name written in config must exist on the model it is written
 * against. The message names what was written, where, and what exists — the
 * difference between a boot error and a form that silently does nothing.
 */
export function crossRef(
  field: unknown,
  model: Model,
  where: string,
  options: { system?: boolean; error?: (detail: string, where: string) => Error } = {},
): string {
  const fail = (detail: string) => (options.error ? options.error(detail, where) : new ConfigError(where, detail));
  if (typeof field !== 'string') throw fail(`field name must be a string, got ${JSON.stringify(field)}`);
  const known = [...Object.keys(model.props), ...(options.system === false ? [] : SYSTEM_FIELDS)];
  if (!known.includes(field)) {
    throw fail(`names unknown field "${field}" on model "${model.name}" — known: ${known.join(', ')}`);
  }
  /**
   * Every view that names a field — a grid column, a form field, a layout row,
   * a rule — comes through here. An internal field has no value to draw and no
   * box to fill, so naming one is refused where it is written rather than
   * rendering an empty column for everyone.
   */
  if (model.props[field]?.internal) {
    throw fail(`names "${field}" on model "${model.name}", which is x-internal — it is stored and never read, so nothing can display or edit it`);
  }
  return field;
}
