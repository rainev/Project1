/**
 * Derived schemas (ARCHITECTURE §5).
 *
 * The base schema carries no `required` and is never used directly. The framework
 * mints a plain, standard JSON Schema per operation/role/state, so `x-require` is
 * the SOURCE of standard `required` rather than a competing keyword. Ajv validates
 * that document; a JSON Schema form renderer renders the same document.
 */
import type { ValidateFunction } from 'ajv';
import { ajv } from './config/loader.ts';
import type { GateView } from './gates.ts';
import type { Model } from './model.ts';

export interface DerivedSchema {
  $id: string;
  type: 'object';
  properties: Record<string, Record<string, unknown>>;
  required?: string[];
  additionalProperties: false;
}


/**
 * Keyed by the Model OBJECT, not by its name.
 *
 * A name-keyed cache makes two models sharing an `$id` share a compiled
 * validator — impossible inside one app, since `loadModels` rejects duplicates,
 * but not across two `createApp` instances in one process. The consequence is
 * that one app validates against another's schema, which with
 * `additionalProperties: false` both rejects valid fields and admits foreign
 * ones. Identity keying makes that unrepresentable; `gates.ts` keys its compiled
 * expressions the same way.
 */
const validators = new WeakMap<Model, Map<string, ValidateFunction>>();

const CREATE_LIKE = new Set(['create']);

/**
 * What a derived schema may carry to the client, by ALLOWLIST (§19).
 *
 * The previous shape copied every keyword and skipped those starting with `x-`,
 * which is the blacklist §19 warns about by name: it holds only while every
 * framework keyword happens to be `x-` prefixed, and leaks the first time one
 * is not. A keyword absent from this list is absent from the wire.
 */
export const PUBLIC_KEYWORDS = new Set([
  'type', 'format', 'enum', 'const',
  'minLength', 'maxLength', 'pattern',
  'minimum', 'maximum', 'exclusiveMinimum', 'exclusiveMaximum', 'multipleOf',
  'items', 'minItems', 'maxItems', 'uniqueItems',
  'title', 'description', 'default', 'examples', 'readOnly', 'writeOnly',
]);

/**
 * Already on the row, and therefore not something the payload has to carry.
 *
 * Empty is missing — the same stance the `minLength: 1` injection below takes
 * and the same one the secret resolver takes, because a requirement satisfied
 * by `""` is a requirement that is not doing anything.
 */
const satisfiedByRow = (row: Record<string, unknown> | undefined, field: string): boolean => {
  if (!row) return false;
  const value = row[field];
  return value !== undefined && value !== null && value !== '';
};

/**
 * Which requirement set applies to this operation — the third axis of §5.
 *
 * With a `row`, a requirement the STORED row already satisfies is not asked of
 * the payload: "a note may only be finished once it has a customer" is one
 * rule, and it holds whether the customer arrives with this request or arrived
 * with an earlier one (AUD-005, W-103). Without a row — the plain
 * `GET /v0/schema/<model>?op=<op>` — the whole set applies, because nothing is
 * known to be satisfied yet.
 */
export function requirementSet(model: Model, op: string, row?: Record<string, unknown>): string[] {
  const declared = model.require[op] ?? (CREATE_LIKE.has(op) ? model.require.create ?? [] : []);
  return row ? declared.filter((field) => !satisfiedByRow(row, field)) : declared;
}

export interface DeriveOptions {
  /** Evaluate field policy for this actor. Omitted -> no field policy applied. */
  view?: GateView;
  readable?: (field: string) => boolean;
  writable?: (field: string) => boolean;
  /**
   * The stored row this operation is about, when there is one. Only the
   * requirement set reads it: the shape of a model does not depend on a row,
   * but what is still MISSING from one does.
   */
  row?: Record<string, unknown>;
}

export function deriveSchema(model: Model, op: string, options: DeriveOptions = {}): DerivedSchema {
  const base = model.schema as Record<string, any>;
  const properties: Record<string, Record<string, unknown>> = {};

  for (const [name, def] of Object.entries<any>(base.properties)) {
    /**
     * Absent only when the actor can neither read the property NOR write it.
     *
     * Dropping on unreadability alone makes a **write-only field
     * unexpressible**: a contact form whose `name`, `email` and `message` are
     * marked admin-read-only loses the three fields it exists to submit,
     * because the visitor's `?op=create` schema drops them (WP-07).
     *
     * Presence answers "may I send this", which is a question about WRITING.
     * Readability still governs what comes back — `projectRead` drops an
     * unreadable field from every response, including the row a create returns —
     * so a write-only field is now exactly that: you may fill it in, and you may
     * not read it back, not even your own.
     */
    /**
     * An internal field is absent from every derived schema, for every actor
     * and every operation — before readability or writability is consulted,
     * because those are questions about policy and this is not one. Absent from
     * the schema is what makes it unnameable: a form cannot offer it, a create
     * cannot carry it, and validation rejects it as an unknown property.
     */
    if (model.props[name]?.internal) continue;
    const mayRead = !options.readable || options.readable(name);
    const mayWrite = !options.writable || options.writable(name);
    if (!mayRead && !mayWrite) continue;
    const clean: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(def)) {
      if (!PUBLIC_KEYWORDS.has(key)) continue;                   // allowlist, never a blacklist
      clean[key] = value;
    }
    if (!mayWrite) clean.readOnly = true;
    /**
     * The lifecycle field is never part of a payload (WP-06).
     *
     * A model that declares `x-states` has made that field the lifecycle's: it
     * moves through a declared transition and no other way, and the engine
     * refuses a create or an update that carries it. Saying so in the derived
     * schema is what stops a form offering an input the server will reject —
     * `readOnly` is the same word the framework already uses for "you may see
     * this and may not write it", so no renderer has to learn a new one.
     */
    if (model.states && name === model.states.field) clean.readOnly = true;
    properties[name] = clean;
  }

  const required = requirementSet(model, op, options.row).filter((f) => f in properties);

  // A required string with no minLength is satisfied by "", which is never what
  // "required" means to an author. Same stance as the secret resolver: empty is missing.
  for (const name of required) {
    const property = properties[name]!;
    if (property.type === 'string' && property.minLength === undefined) property.minLength = 1;
  }

  const schema: DerivedSchema = {
    $id: `${model.name}.${op}`,
    type: 'object',
    properties,
    additionalProperties: false,
  };
  if (required.length) schema.required = required;
  return schema;
}

/**
 * Compiled validator for the shape of this operation, cached per model and per
 * DERIVED requirement set.
 *
 * The op alone stopped being a key once a requirement could depend on the row
 * (W-103): `finish` asks for a customer on a row that has none and asks for
 * nothing on a row that has one, and those are two different documents. The
 * remaining part of the key is therefore what actually varies — the required
 * names — which is bounded by the declared set and identical for every row in
 * the same condition, so the cache still holds.
 */
let compiled = 0;

export function validatorFor(model: Model, op: string, row?: Record<string, unknown>): ValidateFunction {
  let perOp = validators.get(model);
  if (!perOp) { perOp = new Map(); validators.set(model, perOp); }

  const required = requirementSet(model, op, row);
  const key = `${op}|${required.join(',')}`;
  let validate = perOp.get(key);
  if (!validate) {
    // Validation uses the full property set; field-write policy is enforced
    // separately by the gate, so an unwritable field is a policy decision, not a
    // shape error. The `$id` only has to be unique within this Ajv instance.
    validate = ajv.compile({ ...deriveSchema(model, op, { row }), $id: `v:${model.name}:${op}:${compiled++}` });
    perOp.set(key, validate);
  }
  return validate;
}

export interface FieldError {
  path: string;
  keyword: string;
  message: string;
}

/** Ajv reports `instancePath` as a JSON Pointer; form renderers address by JSON Pointer. */
export function validate(
  model: Model, op: string, data: Record<string, unknown>, row?: Record<string, unknown>,
): FieldError[] {
  const validateFn = validatorFor(model, op, row);
  if (validateFn(data)) return [];
  return (validateFn.errors ?? []).map((error) => ({
    path: error.instancePath || (error.params as any)?.missingProperty
      ? error.instancePath || `/${(error.params as any).missingProperty}`
      : '/',
    keyword: error.keyword,
    message: error.message ?? 'is invalid',
  }));
}
