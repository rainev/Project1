import { ConfigError } from './model.ts';
import { assertNoYamlTraps } from './config/yaml-traps.ts';

/**
 * The application's icon vocabulary: a name to the shapes that draw it.
 *
 * Icons are app assets, like a logo. A framework-owned set means an app that
 * needs one more has to change the framework, which is the failure this file
 * exists to remove. The components ship; the vocabulary is declared.
 *
 * An icon is a **list of shapes**, not a path. Nine of the sixteen icons on
 * the reference page are drawn with a circle, a rect or an ellipse, and an
 * approximation of those in path data is a different drawing — a redrawn
 * sparkle or bot is a visible parity defect, not a rounding error.
 *
 * A value may be written either way:
 *
 *   check: M20 6 9 17l-5-5                       # path data, one or more `M` runs
 *   target: <circle cx="12" cy="12" r="10"/>…    # the shapes themselves
 *
 * The second form is parsed, not passed through. Every tag and every attribute
 * is checked against the allowlists below and anything else is refused at boot,
 * so a declared icon can draw and can do nothing else.
 */
export type IconShape = { tag: string; attrs: Record<string, string> };
export type Icons = Record<string, IconShape[]>;

const NAME = /^[a-zA-Z][a-zA-Z0-9]*$/;
/** `M`/`m` move, then the commands and numbers an SVG `d` is made of. */
const PATH = /^[MmLlHhVvCcSsQqTtAaZz0-9 .,\-eE]+$/;

/** What a drawing is allowed to be. Nothing here can script, fetch or style. */
const SHAPES: Record<string, readonly string[]> = {
  path: ['d'],
  circle: ['cx', 'cy', 'r'],
  ellipse: ['cx', 'cy', 'rx', 'ry'],
  rect: ['x', 'y', 'width', 'height', 'rx', 'ry'],
  line: ['x1', 'y1', 'x2', 'y2'],
  polyline: ['points'],
  polygon: ['points'],
};
/** Geometry is numbers and separators; `d` and `points` carry path commands. */
const NUMBER = /^-?[0-9.]+$/;
const POINTS = /^[0-9 .,\-eE]+$/;

const TAG = /<\s*([a-zA-Z]+)([^>]*?)\/?\s*>/g;
const ATTR = /([a-zA-Z-]+)\s*=\s*"([^"]*)"/g;

function parseShapes(name: string, value: string, source: string): IconShape[] {
  const shapes: IconShape[] = [];
  let consumed = 0;
  for (const match of value.matchAll(TAG)) {
    const [whole, tag, rest] = match;
    const allowed = SHAPES[tag];
    if (!allowed) {
      throw new ConfigError(source, `icons.${name} draws with <${tag}>, which is not a shape — ${Object.keys(SHAPES).join(', ')}`);
    }
    const attrs: Record<string, string> = {};
    for (const [, key, val] of rest.matchAll(ATTR)) {
      if (!allowed.includes(key)) {
        throw new ConfigError(source, `icons.${name}: <${tag}> has no ${key} — ${allowed.join(', ')}`);
      }
      const ok = key === 'd' ? PATH.test(val) : key === 'points' ? POINTS.test(val) : NUMBER.test(val);
      if (!ok) throw new ConfigError(source, `icons.${name}: ${key}=${JSON.stringify(val)} is not geometry`);
      attrs[key] = val;
    }
    if (!Object.keys(attrs).length) {
      throw new ConfigError(source, `icons.${name}: <${tag}> draws nothing`);
    }
    shapes.push({ tag, attrs });
    consumed += whole.length;
  }
  // Text between or around the tags would be rendered by nothing, so it is a
  // mistake worth naming rather than dropping in silence.
  if (!shapes.length || value.replace(/\s+/g, '').length > consumed) {
    const stray = value.replace(TAG, '').trim();
    throw new ConfigError(source, `icons.${name} is not a drawing${stray ? ` — ${JSON.stringify(stray.slice(0, 40))}` : ''}`);
  }
  return shapes;
}

export function compileIcons(raw: unknown, source: string): Icons {
  if (raw === null || typeof raw !== 'object' || Array.isArray(raw)) {
    throw new ConfigError(source, 'icons must be a mapping of name to a drawing');
  }
  const icons: Icons = {};
  for (const [name, value] of Object.entries(raw as Record<string, unknown>)) {
    if (!NAME.test(name)) {
      throw new ConfigError(source, `${name} is not an icon name — letters and digits, starting with a letter`);
    }
    if (typeof value !== 'string' || !value.trim()) {
      throw new ConfigError(source, `icons.${name} must be path data or a list of shapes`);
    }
    const text = value.trim();
    if (text.includes('<')) {
      icons[name] = parseShapes(name, text, source);
      continue;
    }
    // Refused at boot rather than injected: path data reaches an SVG `d`, and a
    // value carrying anything else is a config mistake or an attempt.
    if (!PATH.test(text)) {
      throw new ConfigError(source, `icons.${name} is not SVG path data — ${JSON.stringify(text.slice(0, 40))}`);
    }
    icons[name] = text.split(' M').map((d, i) => ({ tag: 'path', attrs: { d: i ? `M${d}` : d } }));
  }
  return icons;
}

export async function loadIcons(configDir: string): Promise<Icons | undefined> {
  const file = Bun.file(`${configDir}/icons.yaml`);
  if (!(await file.exists())) return undefined;
  const text = await file.text();
  assertNoYamlTraps(text, 'icons.yaml');
  return compileIcons(Bun.YAML.parse(text), 'icons.yaml');
}
