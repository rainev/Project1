/**
 * Key rotation as a migration (WP-04 E-122, ARCHITECTURE §8).
 *
 * An envelope names the key that wrote it (`v1:<kid>:<iv>:<ciphertext>`), so a
 * second key can be added and everything already written still decrypts. That
 * is what makes rotation POSSIBLE; it is not rotation. Until every row has been
 * re-sealed, the old key is still load-bearing and cannot be retired — which is
 * the whole reason one rotates.
 *
 * So this runs at boot, next to the schema migration and recorded in the same
 * ledger: walk every tenant, every model with encrypted fields, every row, and
 * rewrite any envelope that names something other than the active kid.
 *
 * Three things it is careful about:
 *
 *   - **Blind indexes go with it.** `indexKey` derives from the ACTIVE kid, so
 *     the moment a new key becomes active every `<field>_bidx` is stale and
 *     equality search on an encrypted field silently stops matching. Re-sealing
 *     recomputes the index from the plaintext it already has in hand. This is
 *     also why rotation must finish before the server accepts a request, not in
 *     the background.
 *   - **`updatedAt` does not move.** Re-sealing is not an edit; see
 *     `DBAdapter.reseal`.
 *   - **Scope is never emptied.** The pass iterates the `_orgs` table and
 *     issues one scoped read per tenant, so the adapter's refusal of an
 *     unscoped query stays exactly where it is (§22). A framework job gets no
 *     cross-tenant shortcut.
 *
 * Idempotence comes from the ledger rather than from the data: a completed pass
 * writes `rotate:kid:<active>`, and a boot that finds it does no reading at
 * all. A pass that dies half-way writes nothing, and the next boot repeats it —
 * rows already re-sealed are simply skipped, because their envelopes already
 * name the active kid.
 *
 * **Why paging here is safe.** It reads with `list`'s default sort, `createdAt`,
 * which `migrate` declares NOT NULL on every table — so the keyset cursor's
 * known truncation past a NULL (backlog) cannot skip a row, and `reseal` moves
 * neither `createdAt` nor `id`, so the cursor stays valid under its own writes.
 * A rotation that silently missed rows would be worse than no rotation: it
 * would report success and leave the old key load-bearing.
 *
 * An envelope naming a kid with no key material stops the boot, from
 * `dataKey`'s own `unknown key id` — which is the right answer. Rotation is the
 * one place that reads every envelope, so it is where a key removed too early
 * is found, loudly, instead of on some request months later.
 */
import { MAX_LIMIT, type DBAdapter, type Row } from './adapter.ts';
import { MIGRATION } from './migrate.ts';
import type { Model } from '../model.ts';
import { aad, decryptValue, isEnvelope } from '../crypto/field.ts';
import { encryptInput } from '../crypto/pipeline.ts';
import type { KeyProvider } from '../crypto/keys.ts';
import type { FileAdapter, FileDescriptor } from '../files/adapter.ts';

/** The kid an envelope names, or undefined when the value is not one. */
export function envelopeKid(value: unknown): string | undefined {
  return isEnvelope(value) ? value.split(':')[1] : undefined;
}

export interface RotationReport {
  /** The kid everything now names. */
  kid: string;
  /** Rows rewritten. Zero on a boot that had nothing to do. */
  rows: number;
  /** Uploaded files re-sealed on disk. */
  files: number;
  /** False when the ledger said a previous boot had already finished. */
  ran: boolean;
}

/** The descriptor an upload column stores, or undefined if it holds anything else. */
function describe(value: unknown): FileDescriptor | undefined {
  if (typeof value !== 'string' || !value.startsWith('{')) return undefined;
  try {
    const parsed = JSON.parse(value) as FileDescriptor;
    return typeof parsed?.id === 'string' ? parsed : undefined;
  } catch {
    return undefined;
  }
}

/**
 * @param orgIds every tenant whose rows may hold ciphertext. The caller passes
 *   them because "what is a tenant" is the auth package's question, not the
 *   adapter's — and `_orgs` is complete only after `ensureOrgs`.
 */
export async function rotateEncryptedFields(
  db: DBAdapter, models: Iterable<Model>, keys: KeyProvider, orgIds: readonly string[],
  files?: FileAdapter,
): Promise<RotationReport> {
  const kid = keys.activeKid;
  // Uploaded bytes carry a kid on their descriptor exactly as a field does, so
  // a model with an `x-upload` property is in the pass whether or not it
  // declares an encrypted field.
  const encrypting = [...models].filter((m) =>
    Object.keys(m.encrypted).length > 0 || (files && Object.keys(m.uploads).length > 0));
  if (encrypting.length === 0) return { kid, rows: 0, files: 0, ran: false };

  const key = `rotate:kid:${kid}`;
  if (await db.systemFind(MIGRATION, { key })) return { kid, rows: 0, files: 0, ran: false };

  let rows = 0;
  let resealedFiles = 0;
  for (const model of encrypting) {
    const fields = Object.keys(model.encrypted);
    const uploads = files ? Object.keys(model.uploads) : [];
    for (const orgId of orgIds) {
      const scope = { orgId };
      let cursor: string | undefined;
      do {
        const page = await db.list(model, scope, { limit: MAX_LIMIT, cursor });
        for (const row of page.rows) {
          const stale = fields.filter((f) => {
            const named = envelopeKid(row[f]);
            return named !== undefined && named !== kid;
          });
          // An upload column holds a descriptor naming the key its BYTES were
          // sealed with. Re-seal the file first, then write the descriptor it
          // reports — never the other way round: a descriptor claiming a kid
          // the bytes do not carry is an unreadable file.
          const moved: Row = {};
          for (const property of uploads) {
            const descriptor = describe(row[property]);
            if (!descriptor || descriptor.kid === kid) continue;
            // No kid at all means the bytes predate encryption and are stored
            // plaintext (`FileDescriptor.kid`). There is no key to retire, and
            // decrypting them would fail; encrypting them is a different job
            // from rotating a key, so it is not this pass's to do.
            if (!descriptor.kid) continue;
            const now = await files!.reseal(orgId, descriptor.id, descriptor.kid);
            if (!now) continue;
            moved[property] = JSON.stringify({ ...descriptor, kid: now });
            resealedFiles++;
          }

          if (stale.length === 0 && Object.keys(moved).length === 0) continue;

          // Decrypt under the kid each envelope names; the AAD is unchanged,
          // because the value stays in the same field of the same row of the
          // same tenant — which is exactly what the AAD asserts.
          const plain: Row = {};
          for (const field of stale) {
            plain[field] = await decryptValue(
              keys, orgId, row[field] as string, aad(model.name, field, orgId, String(row.id)),
            );
          }
          // The ordinary write path: same envelope format, same blind index,
          // same code the request pipeline uses — under the active key.
          const sealed = await encryptInput(keys, model, orgId, String(row.id), plain);
          await db.reseal(model, scope, String(row.id), { ...sealed, ...moved });
          rows++;
        }
        cursor = page.nextCursor;
      } while (cursor);
    }
  }

  await db.systemCreate(MIGRATION, {
    key, table: '*', kind: 'rotate',
    detail: `re-sealed ${rows} row(s) and ${resealedFiles} file(s) under key id "${kid}"`,
    at: new Date().toISOString(),
  });
  return { kid, rows, files: resealedFiles, ran: true };
}
