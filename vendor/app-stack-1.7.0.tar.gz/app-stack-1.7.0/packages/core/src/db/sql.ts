/**
 * The SQL adapter, on Kysely's query builder (decision D-01, WP-03 Q-101a).
 *
 * ONE implementation, three engines (WP-04 E-110/E-111). Everything that
 * differs between sqlite, PostgreSQL and MariaDB is an `EngineProfile` in
 * `engines.ts`; nothing below this line branches on the engine except by
 * reading that record. A fourth engine is a fourth profile.
 *
 * Kysely owns SQL assembly: placeholders, quoting, RETURNING, LIMIT, the schema
 * builder and the introspector. The framework keeps everything security-relevant
 * and keeps it in the same place it was before the port:
 *
 *   - identifiers resolve through `column` / `allowedColumn` to the MODEL'S OWN
 *     strings before the builder ever sees them (§22);
 *   - values are always bound, never formatted;
 *   - every tenant-facing statement goes through `#scoped`, which refuses an
 *     unscoped query rather than returning another tenant's rows;
 *   - operators and aggregate functions are framework enums, never request text.
 *
 * What the builder replaced is 35 hand-assembled SQL strings. What it did not
 * replace is any of the above: this file resolves identifiers exactly where it
 * used to, and `packages/core/test/db-contract` is green either side of the port.
 */
import { sql, Kysely, type ExpressionBuilder, type SelectQueryBuilder } from 'kysely';
import { BadRequest } from '../errors.ts';
import { allowedColumn, column, type Model } from '../model.ts';
import type { EngineProfile } from './engines.ts';
import {
  MIGRATION, diffTable, planSteps, refusalError, type ExistingColumn,
} from './migrate.ts';
import {
  DEFAULT_LIMIT, MAX_LIMIT, isScopeList,
  type AggregateSpec, type DBAdapter, type Filter, type ListOptions, type ListPage, type Row, type Scope,
} from './adapter.ts';
import type { ExecutableQuery, QueryPage, QueryPredicate } from '../queries/compiled.ts';

/** Comparison operators are a framework enum — never assembled from request text. */
const OPERATOR = {
  eq: '=', ne: '!=', gt: '>', gte: '>=', lt: '<', lte: '<=',
} as const;

const AGGREGATE_FN = new Set(['count', 'sum', 'avg', 'min', 'max']);

/**
 * Not a backslash: MySQL/MariaDB treat backslash as an escape inside string
 * literals too, so `ESCAPE '\\'` means different things depending on a server
 * setting. `!` means one thing everywhere.
 */
const LIKE_ESCAPE = '!';

/** A user's search term, made literal: its wildcards match themselves. */
const likePattern = (value: unknown) =>
  `%${String(value).replace(/[!%_]/g, (c) => `${LIKE_ESCAPE}${c}`)}%`;

interface Cursor { sort: string; dir: string; value: unknown; id: string }

/**
 * Paging machinery a declared query carries but never declared: the root row's
 * id as the tie-breaker, and the value the order compares on. Both are stripped
 * before the rows leave the adapter.
 */
const CURSOR_ID = '__cursorId';
const CURSOR_VALUE = '__cursorValue';

const encodeCursor = (cursor: Cursor) =>
  Buffer.from(JSON.stringify(cursor)).toString('base64url');

function decodeCursor(raw: string): Cursor {
  try {
    const parsed = JSON.parse(Buffer.from(raw, 'base64url').toString('utf8'));
    if (typeof parsed?.sort !== 'string' || typeof parsed?.id !== 'string') throw new Error('shape');
    return parsed as Cursor;
  } catch {
    throw new BadRequest('invalid cursor');
  }
}

type Q = SelectQueryBuilder<any, any, any>;

export class SqlAdapter implements DBAdapter {
  readonly dialect: EngineProfile['dialect'];
  #engine: EngineProfile;
  #sql: any;
  #db: Kysely<any>;
  #owned: boolean;
  /** Kept so a migration can reopen the pool; undefined for a `tx` handle. */
  #url?: string;
  /** Did the current migration ALTER anything (as opposed to creating it)? */
  #altered = false;

  /** A URL opens a connection; a handle wraps an existing one (used by `tx`). */
  constructor(engine: EngineProfile, source: string | { handle: unknown }) {
    this.#engine = engine;
    this.dialect = engine.dialect;
    if (typeof source === 'string') {
      this.#url = source;
      this.#sql = engine.open(source);
      this.#owned = true;
    } else {
      this.#sql = source.handle;
      this.#owned = false;
    }
    this.#db = new Kysely<any>({ dialect: engine.kysely(this.#sql) });
  }

  /**
   * Create what is missing, evolve what has drifted, refuse what would destroy
   * (WP-04 E-120/E-121). The reasoning lives in `migrate.ts`; this method is
   * the part that has to touch a connection.
   *
   * The ledger goes first and is not part of the caller's model list: it has to
   * exist before the first change can be recorded, including the change that
   * creates the caller's first table.
   */
  async migrate(models: Iterable<Model>): Promise<string[]> {
    const applied: string[] = [];
    this.#altered = false;
    await this.#ensureTable(MIGRATION);
    await this.#evolve(MIGRATION);
    for (const model of models) {
      if (model.table !== MIGRATION.table) await this.#ensureTable(model);
      await this.#evolve(model);
      applied.push(model.table);
    }
    // A statement prepared before an ALTER can outlive its own plan; where the
    // engine says so, the pool starts again rather than serving the error.
    if (this.#altered && !this.#engine.plansSurviveDdl) await this.#reconnect();
    return applied;
  }

  /**
   * Reopen the pool, discarding every prepared statement on it.
   *
   * Only reachable from `migrate`, and only on an adapter that owns its
   * connection — a `tx` handle is somebody else's, and runs no DDL.
   */
  async #reconnect() {
    if (!this.#url) return;
    await this.#sql.close();
    this.#sql = this.#engine.open(this.#url);
    this.#db = new Kysely<any>({ dialect: this.#engine.kysely(this.#sql) });
  }

  /** `CREATE TABLE IF NOT EXISTS` plus the tenant index. Unchanged since E-110. */
  async #ensureTable(model: Model) {
    const key = sql.raw(this.#collated(this.#engine.keyType));
    const stamp = sql.raw(this.#collated(this.#engine.stampType));
    let table = this.#db.schema.createTable(model.table).ifNotExists()
      .addColumn('id', key, (c) => c.primaryKey())
      .addColumn('orgId', key, (c) => c.notNull())
      .addColumn('createdAt', stamp, (c) => c.notNull())
      .addColumn('updatedAt', stamp, (c) => c.notNull());
    for (const name of model.columns) {
      // A framework enum resolved from the model's DECLARED type — `sql.raw`
      // here never sees config text.
      const type = sql.raw(this.#collated(this.#engine.type(model.props[name]!.type)));
      table = model.notNull.includes(name)
        ? table.addColumn(name, type, (c) => c.notNull())
        : table.addColumn(name, type);
    }
    await table.execute();
    await this.#createIndex(`${model.table}_org_created`, model.table, ['orgId', 'createdAt']);
  }

  /** Columns of one table, as this engine's introspector reports them. */
  async #columnsOf(table: string): Promise<ExistingColumn[]> {
    const info = (await this.#db.introspection.getTables()).find((t) => t.name === table);
    return (info?.columns ?? []).map((c) => ({
      name: c.name, dataType: c.dataType, isNullable: c.isNullable,
    }));
  }

  /**
   * Declared steps, then the additive diff, then a refusal if anything is left.
   *
   * The order matters: a rename looks exactly like "one column appeared and
   * another vanished" until it has been applied, so the diff must run after.
   */
  async #evolve(model: Model) {
    let existing = await this.#columnsOf(model.table);

    const planned = planSteps(model, existing);
    if (planned.refusals.length) throw refusalError(model, planned.refusals);

    for (const step of planned.steps) {
      // Every identifier below was reported by the introspector a moment ago —
      // the database's own spelling, not config text (see `migrate.ts`).
      const named = new Set(existing.map((c) => c.name));
      if (step.kind === 'rename') {
        if (!named.has(step.from)) continue;
        await this.#db.schema.alterTable(model.table).renameColumn(step.from, step.to).execute();
        this.#altered = true;
        await this.#record(step.key, model.table, 'rename', `${step.from} -> ${step.to}`);
      } else {
        if (!named.has(step.column)) continue;
        await this.#db.schema.alterTable(model.table).dropColumn(step.column).execute();
        this.#altered = true;
        await this.#record(step.key, model.table, 'drop', step.column);
      }
      existing = await this.#columnsOf(model.table);
    }

    const diff = diffTable(model, this.#engine, existing);
    if (diff.refusals.length) throw refusalError(model, diff.refusals);

    for (const column of diff.add) {
      // Nullable by construction (`diffTable` refuses the alternative), so
      // every row written before this boot reads the new column back as null.
      await this.#db.schema.alterTable(model.table)
        .addColumn(column.name, sql.raw(this.#collated(column.ddl)))
        .execute();
      this.#altered = true;
      await this.#record(
        `${model.table}:add:${column.name}`, model.table, 'add', `${column.name} ${column.ddl}`,
      );
    }
  }

  /**
   * A ledger row, written once. The key is deterministic, so a boot that
   * changes nothing writes nothing — and the ledger stays a history of what
   * happened rather than a second, drifting copy of the schema.
   */
  async #record(key: string, table: string, kind: string, detail: string) {
    if (await this.systemFind(MIGRATION, { key })) return;
    await this.systemCreate(MIGRATION, { key, table, kind, detail, at: new Date().toISOString() });
  }

  /**
   * A DDL type, carrying this engine's text collation when it needs telling.
   * Only text columns collate; a `double` has no such thing.
   */
  #collated(type: string): string {
    const collation = this.#engine.textCollation;
    if (!collation || !/^(text|varchar)/.test(type)) return type;
    return `${type} collate ${collation}`;
  }

  /**
   * `CREATE INDEX IF NOT EXISTS` where the engine has that form. MySQL and
   * MariaDB do not, so the equivalent is to create it and forgive the server's
   * "duplicate key name" — the only outcome `IF NOT EXISTS` would have hidden.
   */
  async #createIndex(name: string, table: string, columns: string[]) {
    const builder = this.#db.schema.createIndex(name).on(table).columns(columns);
    if (this.#engine.indexIfNotExists) return void await builder.ifNotExists().execute();
    try {
      await builder.execute();
    } catch (error) {
      if (!/duplicate key name/i.test(String((error as Error).message))) throw error;
    }
  }

  /**
   * One ORDER BY term, placed the same way on every engine.
   *
   * The framework's reading is sqlite's and MariaDB's: NULL sorts below every
   * value, so it leads an ascending page and trails a descending one. Where an
   * engine disagrees, it is told. The tie-breaking `id` never needs this — it is
   * a primary key — so only declared sort columns go through here.
   */
  #ordered(qb: Q, target: unknown, dir: 'asc' | 'desc'): Q {
    if (!this.#engine.explicitNullOrder) return qb.orderBy(target as any, dir);
    return qb.orderBy(target as any, (ob: any) =>
      (dir === 'asc' ? ob.asc().nullsFirst() : ob.desc().nullsLast()));
  }

  /**
   * A measure comes back as whatever the engine's own type system says: sqlite
   * counts in an integer, PostgreSQL counts in a bigint, MariaDB hands back a
   * decimal. The caller declared `count`, `sum` or `avg` over a declared
   * numeric, so the answer is a JS number on every engine.
   */
  #measureValue(op: string, declared: string | undefined, value: unknown): unknown {
    if (value == null) return value;
    const numeric = op === 'count' || declared === 'number' || declared === 'integer';
    return numeric ? Number(value) : value;
  }

  /** A declared boolean, spelled the way this engine stores one. */
  #encode(model: Model, name: string, value: unknown): unknown {
    if (model.props[name]?.type !== 'boolean' || value == null) return value;
    return this.#engine.encodeBoolean(Boolean(value));
  }

  /** ...and decode it back on the way out, so nothing above this seam sees a 1. */
  #decode(model: Model, row: Row | undefined): Row | undefined {
    if (!row) return undefined;
    const out: Row = { ...row };
    for (const name of model.columns) {
      if (model.props[name]!.type === 'boolean' && out[name] != null) {
        out[name] = Boolean(out[name]);
      }
    }
    return out;
  }

  /** A scope-less statement would touch every tenant's rows; refuse rather than leak. */
  #assertScoped(model: Model, scope: Scope) {
    if (Object.keys(scope).length === 0) {
      throw new Error(`${model.name}: refusing an unscoped query`);
    }
  }

  /**
   * A list scope widens a READ across tenants (Q-123). On a write there is no
   * such thing: a row is created, updated or deleted in one tenant, so the list
   * form is refused here rather than silently applied to the first entry.
   */
  #assertNarrow(model: Model, scope: Scope, operation: string) {
    for (const [selector, value] of Object.entries(scope)) {
      if (isScopeList(value)) {
        throw new Error(`${model.name}: refusing a cross-tenant scope on ${operation} — "${selector}" is a list`);
      }
    }
  }

  /**
   * One scope key, bound. A value binds with `=`; a list binds with `IN`, and an
   * EMPTY list matches nothing — the same reading `#filtered` gives an empty
   * `in`, because "no tenants" must never compile to "every tenant".
   */
  #scopeWhere<B extends { where: any }>(qb: B, col: string, value: unknown): B {
    if (!isScopeList(value)) return qb.where(col, '=', value);
    const list = [...value.in];
    return list.length === 0 ? qb.where(sql`1 = 0`) : qb.where(col, 'in', list);
  }

  /**
   * Every scope key is resolved to a model-owned identifier before the builder
   * sees it, and the value is bound. The one place tenant isolation is applied.
   */
  #scoped<B extends { where: any }>(qb: B, model: Model, scope: Scope): B {
    this.#assertScoped(model, scope);
    for (const [selector, value] of Object.entries(scope)) {
      qb = this.#scopeWhere(qb, column(model, selector), value);
    }
    return qb;
  }

  /** Filter identifiers resolve from the model's allowlist; values are always bound. */
  #filtered(qb: Q, model: Model, filters: Filter[] = []): Q {
    for (const filter of filters) {
      const col = allowedColumn(model, filter.field, model.filterable, 'a filterable field');
      if (filter.op === 'in') {
        const list = Array.isArray(filter.value) ? filter.value : [filter.value];
        // An empty `in` matches nothing. Saying so explicitly beats emitting
        // `IN ()`, which is a syntax error in sqlite and `false` in PostgreSQL.
        qb = list.length === 0 ? qb.where(sql`1 = 0`) : qb.where(col, 'in', list);
      } else if (filter.op === 'contains') {
        // `contains` is a SUBSTRING search, so the wildcards LIKE gives meaning
        // to are literal characters in the needle: searching for "50%" must not
        // match "500". Escape them and declare the escape character, which every
        // engine spells the same way (AUD-025).
        qb = qb.where(sql`${sql.ref(col)} like ${likePattern(filter.value)} escape ${sql.lit(LIKE_ESCAPE)}`);
      } else if (filter.op in OPERATOR) {
        qb = qb.where(col, OPERATOR[filter.op as keyof typeof OPERATOR], filter.value);
      } else {
        throw new BadRequest(`${model.name}: unsupported filter operator`);
      }
    }
    return qb;
  }

  async create(model: Model, scope: Scope, input: Row, options: { id?: string; orgId?: string } = {}): Promise<Row> {
    this.#assertScoped(model, scope);
    this.#assertNarrow(model, scope, 'create');
    const now = new Date().toISOString();
    // The caller may supply the id so ciphertext can be bound to the row it lives in.
    const id = options.id ?? crypto.randomUUID();
    const values: Row = { id, createdAt: now, updatedAt: now };

    // Scope values are server-owned and overwrite anything the caller sent.
    for (const [selector, value] of Object.entries(scope)) {
      values[column(model, selector)] = value;
    }

    /**
     * Which org the row belongs to, when the read scope did not say.
     *
     * For a tenant-scoped model `orgId` is a scope key and the loop above has
     * already written it; this is the other case. A PUBLIC model is scoped by a
     * property of the row (`{ published: true }`) so that a visitor — who has no
     * org — can be judged by it, and without this such a model would be readable
     * and not writable: `orgId` is NOT NULL on every table (WP-07 S-101).
     *
     * Refused rather than defaulted. An empty org would satisfy the column and
     * mean nothing, and a row nobody owns is not a row this framework knows how
     * to answer questions about.
     */
    if (!('orgId' in values)) {
      if (!options.orgId) {
        throw new Error(
          `${model.name}: create has no org to write — the model's x-scope names no tenant key ` +
          'and the caller supplied no orgId. Every row belongs to an org, including a public one.',
        );
      }
      values.orgId = options.orgId;
    }

    // Only declared, non-transient properties are persisted, and the column
    // name written into SQL is the model's own string — never the input key.
    for (const own of model.columns) {
      if (!Object.prototype.hasOwnProperty.call(input, own) || own in values) continue;
      values[own] = this.#encode(model, own, input[own]);
    }

    await this.#db.insertInto(model.table).values(values).execute();
    return (await this.get(model, scope, id))!;
  }

  async get(model: Model, scope: Scope, id: string): Promise<Row | undefined> {
    const row = await this
      .#scoped(this.#db.selectFrom(model.table).selectAll().where('id', '=', id), model, scope)
      .executeTakeFirst();
    return this.#decode(model, row as Row | undefined);
  }

  async list(model: Model, scope: Scope, options: ListOptions = {}): Promise<ListPage> {
    const sort = options.sort
      ? allowedColumn(model, options.sort, model.sortable, 'a sortable field')
      : 'createdAt';
    const ascending = options.dir === 'asc';
    const dir = ascending ? 'ASC' : 'DESC';
    const limit = Math.min(Math.max(1, options.limit ?? DEFAULT_LIMIT), MAX_LIMIT);

    let qb = this.#filtered(
      this.#scoped(this.#db.selectFrom(model.table).selectAll(), model, scope),
      model, options.filters,
    );

    // Keyset pagination: the cursor carries the sort value and the id tie-breaker.
    if (options.cursor) {
      const mark = decodeCursor(options.cursor);
      if (mark.sort !== sort || mark.dir !== dir) {
        throw new BadRequest(`${model.name}: cursor does not match this sort order`);
      }
      const comparison = ascending ? '>' : '<';
      qb = qb.where((eb: ExpressionBuilder<any, any>) => eb.or([
        eb(sort, comparison, mark.value),
        eb.and([eb(sort, '=', mark.value), eb('id', comparison, mark.id)]),
      ]));
    }

    const rows = await this.#ordered(qb, sort, ascending ? 'asc' : 'desc')
      .orderBy('id', ascending ? 'asc' : 'desc')
      .limit(limit + 1)
      .execute() as Row[];

    const page = rows.slice(0, limit).map((r) => this.#decode(model, r)!);
    const nextCursor = rows.length > limit && page.length
      ? encodeCursor({ sort, dir, value: page[page.length - 1]![sort], id: String(page[page.length - 1]!.id) })
      : undefined;
    return { rows: page, nextCursor };
  }

  /**
   * A declared query (§7.1). Everything here arrived resolved: `plan.from.table`
   * and every column are model-owned strings, every value is bound, and each
   * participating table carries its own evaluated scope. This method therefore
   * decides nothing — it assembles what it was given, and refuses a plan with
   * no root scope the same way every other read does.
   *
   * A joined table's scope goes in its JOIN condition, not the WHERE clause.
   * For a LEFT JOIN those differ: in WHERE, a NULL from a non-matching row
   * fails the comparison and the root row disappears, quietly turning the join
   * inner. In ON, another tenant's row simply does not match.
   */
  async query(plan: ExecutableQuery): Promise<QueryPage> {
    if (Object.keys(plan.scope).length === 0) {
      throw new Error(`${plan.name}: refusing an unscoped query`);
    }

    const ref = (alias: string, column: string) => `${alias}.${column}`;

    let qb: Q = this.#db.selectFrom(`${plan.from.table} as ${plan.from.alias}`);

    for (const join of plan.joins) {
      const build = (on: any) => {
        let next = on.onRef(ref(join.leftAlias, join.leftColumn), '=', ref(join.alias, join.rightColumn));
        // The joined model's tenancy, bound, inside the ON clause. A cross-tenant
        // read widens this to a list (Q-123); an empty list still matches nothing.
        for (const [column, value] of Object.entries(join.scope)) {
          const target = ref(join.alias, column);
          if (!isScopeList(value)) { next = next.on(target, '=', value); continue; }
          const list = [...value.in];
          next = list.length === 0 ? next.on(sql`1 = 0`) : next.on(target, 'in', list);
        }
        return next;
      };
      qb = join.kind === 'inner'
        ? qb.innerJoin(`${join.table} as ${join.alias}`, build)
        : qb.leftJoin(`${join.table} as ${join.alias}`, build);
    }

    // The root model's tenancy, bound as a value or — for a cross-tenant read —
    // as a bound list. Never absent: the refusal above is unchanged.
    for (const [column, value] of Object.entries(plan.scope)) {
      qb = this.#scopeWhere(qb, ref(plan.from.alias, column), value);
    }

    for (const predicate of plan.where) qb = this.#predicate(qb, predicate);

    const aggregate = plan.measures.length > 0;
    if (aggregate) {
      for (const group of plan.groupBy) qb = qb.select(`${ref(group.alias!, group.column!)} as ${group.as}`);
      for (const measure of plan.measures) {
        qb = measure.column && measure.alias
          ? qb.select((eb) => eb.fn(measure.op, [ref(measure.alias!, measure.column!)]).as(measure.as))
          : qb.select((eb) => eb.fn.countAll().as(measure.as));
      }
      if (plan.groupBy.length) {
        qb = qb.groupBy(plan.groupBy.map((g) => ref(g.alias!, g.column!)));
      }
      for (const order of plan.orderBy) {
        // A measure is ordered by its generated alias — the same framework
        // string the SELECT gave it, never a caller's label.
        qb = order.measure
          ? this.#ordered(qb, sql.ref(order.measure), order.dir)
          : this.#ordered(qb, ref(order.alias!, order.column!), order.dir);
      }
      const rows = await qb.limit(plan.limit).execute() as Row[];
      // A plan names no declared types (`compiled.ts`), so only `count` — which
      // is a row count whatever the columns are — can be normalised here.
      return {
        rows: rows.map((row) => {
          const out: Row = { ...row };
          for (const measure of plan.measures) {
            out[measure.as] = this.#measureValue(measure.op, undefined, row[measure.as]);
          }
          return out;
        }),
      };
    }

    for (const column of plan.select) qb = qb.select(`${ref(column.alias, column.column)} as ${column.as}`);
    // The root row's id rides along as the keyset tie-breaker, and is dropped
    // before the rows leave this method: it is a paging mechanism, not a column
    // the query declared.
    qb = qb.select(`${ref(plan.from.alias, 'id')} as ${CURSOR_ID}`);

    // ...as does the value the cursor compares on, which a query need not have
    // selected: "order by createdAt, show title" is an ordinary report.
    const primary = plan.orderBy[0]!;
    if (!primary.column || !primary.alias) {
      // Only an aggregate has measures to order by, and an aggregate is not paged.
      throw new BadRequest(`${plan.name}: a row query orders by a column, not a measure`);
    }
    qb = qb.select(`${ref(primary.alias, primary.column)} as ${CURSOR_VALUE}`);
    const ascending = primary.dir === 'asc';
    const signature = `${primary.alias}.${primary.column}:${primary.dir}`;

    if (plan.cursor) {
      const mark = decodeCursor(plan.cursor);
      if (mark.sort !== signature) {
        throw new BadRequest(`${plan.name}: cursor does not match this sort order`);
      }
      const comparison = ascending ? '>' : '<';
      const sorted = ref(primary.alias, primary.column);
      const tie = ref(plan.from.alias, 'id');
      qb = qb.where((eb: ExpressionBuilder<any, any>) => eb.or([
        eb(sorted, comparison, mark.value),
        eb.and([eb(sorted, '=', mark.value), eb(tie, comparison, mark.id)]),
      ]));
    }

    for (const order of plan.orderBy) qb = this.#ordered(qb, ref(order.alias!, order.column!), order.dir);
    qb = qb.orderBy(ref(plan.from.alias, 'id'), primary.dir);

    const rows = await qb.limit(plan.limit + 1).execute() as Row[];
    const page = rows.slice(0, plan.limit);
    const last = page[page.length - 1];
    const nextCursor = rows.length > plan.limit && last
      ? encodeCursor({
          sort: signature, dir: primary.dir,
          value: last[CURSOR_VALUE], id: String(last[CURSOR_ID]),
        })
      : undefined;

    return {
      rows: page.map((row) => {
        const { [CURSOR_ID]: _id, [CURSOR_VALUE]: _value, ...rest } = row;
        return rest;
      }),
      nextCursor,
    };
  }

  /** One predicate of a declared query: identifier qualified, value bound. */
  #predicate(qb: Q, predicate: QueryPredicate): Q {
    const target = `${predicate.alias}.${predicate.column}`;
    if (predicate.op === 'in') {
      const list = Array.isArray(predicate.value) ? predicate.value : [predicate.value];
      return list.length === 0 ? qb.where(sql`1 = 0`) : qb.where(target, 'in', list);
    }
    if (predicate.op === 'contains') {
      return qb.where(sql`${sql.ref(target)} like ${likePattern(predicate.value)} escape ${sql.lit(LIKE_ESCAPE)}`);
    }
    if (predicate.op in OPERATOR) {
      return qb.where(target, OPERATOR[predicate.op as keyof typeof OPERATOR], predicate.value);
    }
    throw new BadRequest(`${target}: unsupported filter operator`);
  }

  async count(model: Model, scope: Scope, filters: Filter[] = []): Promise<number> {
    const row = await this
      .#filtered(this.#scoped(this.#db.selectFrom(model.table), model, scope), model, filters)
      .select((eb) => eb.fn.countAll().as('n'))
      .executeTakeFirst() as Row | undefined;
    return Number(row?.n ?? 0);
  }

  async aggregate(model: Model, scope: Scope, spec: AggregateSpec): Promise<Row[]> {
    const groups = (spec.groupBy ?? []).map((g) =>
      allowedColumn(model, g, model.filterable, 'a groupable field'));

    let qb = this.#filtered(this.#scoped(this.#db.selectFrom(model.table), model, scope), model, spec.filters);
    qb = qb.select(groups);

    // Caller labels never enter SQL: measures use framework-generated aliases.
    spec.measures.forEach((measure, index) => {
      if (!AGGREGATE_FN.has(measure.op)) {
        throw new BadRequest(`${model.name}: unsupported aggregate function`);
      }
      const alias = `m${index}`;
      qb = measure.field
        ? qb.select((eb) => eb.fn(
            measure.op,
            [allowedColumn(model, measure.field, model.filterable, 'an aggregable field')],
          ).as(alias))
        : qb.select((eb) => eb.fn.countAll().as(alias));
    });
    if (groups.length) qb = this.#ordered(qb.groupBy(groups), groups[0]!, 'asc');

    const rows = await qb.execute() as Row[];

    // Map framework aliases back to the caller's labels only when shaping JSON.
    return rows.map((row) => {
      const out: Row = {};
      for (const group of groups) {
        const value = row[group];
        // Group values carry the model's declared type, not sqlite's storage type.
        out[group] = model.props[group]?.type === 'boolean' && value != null ? Boolean(value) : value;
      }
      spec.measures.forEach((measure, index) => {
        const declared = measure.field ? model.props[measure.field]?.type : undefined;
        out[measure.as] = this.#measureValue(measure.op, declared, row[`m${index}`]);
      });
      return out;
    });
  }

  async update(model: Model, scope: Scope, id: string, input: Row): Promise<Row | undefined> {
    this.#assertNarrow(model, scope, 'update');
    const existing = await this.get(model, scope, id);
    if (!existing) return undefined;

    const patch: Row = {};
    for (const own of model.columns) {
      if (!Object.prototype.hasOwnProperty.call(input, own)) continue;
      patch[own] = this.#encode(model, own, input[own]);
    }
    patch.updatedAt = new Date().toISOString();

    await this.#scoped(this.#db.updateTable(model.table).set(patch).where('id', '=', id), model, scope).execute();
    return this.get(model, scope, id);
  }

  async delete(model: Model, scope: Scope, id: string): Promise<boolean> {
    this.#assertNarrow(model, scope, 'delete');
    // Scoped like every other statement: a row belonging to another tenant is
    // simply not matched, so a caller cannot probe for its existence.
    const statement = this.#scoped(this.#db.deleteFrom(model.table).where('id', '=', id), model, scope);
    // `RETURNING id` where the engine has it; where it does not, the count of
    // rows the statement touched answers the same question — and answers it
    // from the scoped DELETE itself, never from a second, racy read.
    if (this.#engine.deleteReturning) return (await statement.returning('id').execute()).length > 0;
    const result = await statement.executeTakeFirst();
    return Number(result?.numDeletedRows ?? 0) > 0;
  }

  /** As `update`, minus the `updatedAt` stamp — see the interface for why. */
  async reseal(model: Model, scope: Scope, id: string, values: Row): Promise<void> {
    this.#assertNarrow(model, scope, 'reseal');
    const patch: Row = {};
    for (const own of model.columns) {
      if (!Object.prototype.hasOwnProperty.call(values, own)) continue;
      patch[own] = this.#encode(model, own, values[own]);
    }
    if (Object.keys(patch).length === 0) return;
    await this.#scoped(this.#db.updateTable(model.table).set(patch).where('id', '=', id), model, scope)
      .execute();
  }

  async existsWith(model: Model, scope: Scope, where: Row, exceptId?: string): Promise<boolean> {
    // `x-unique` asks "is this value taken in THIS tenant"; across tenants the
    // question has no answer a caller could act on.
    this.#assertNarrow(model, scope, 'existsWith');
    let qb = this.#scoped(this.#db.selectFrom(model.table).select('id'), model, scope);
    for (const [key, value] of Object.entries(where)) {
      const col = column(model, key);
      qb = qb.where(col, '=', this.#encode(model, col, value));
    }
    if (exceptId) qb = qb.where('id', '!=', exceptId);
    return (await qb.limit(1).execute()).length > 0;
  }

  /** One transaction per action. The nested adapter issues every statement on the
   *  transaction handle, so a throw anywhere rolls the whole action back. */
  async tx<T>(fn: (adapter: DBAdapter) => Promise<T>): Promise<T> {
    return this.#sql.begin(async (handle: unknown) => fn(new SqlAdapter(this.#engine, { handle })));
  }

  #assertSystem(model: Model) {
    // A property, not a prefix: `user` is the framework's and does not carry one.
    if (!model.framework) {
      throw new Error(`${model.name} is not a system model; use the scoped operations`);
    }
  }

  /**
   * Encode on the way in, as `create` does, so a caller above this seam never
   * has to know that sqlite spells `true` as `1`.
   */
  #whereAll(qb: Q, model: Model, where: Row): Q {
    for (const [key, value] of Object.entries(where)) {
      const col = column(model, key);
      qb = qb.where(col, '=', this.#encode(model, col, value));
    }
    return qb;
  }

  async systemFind(model: Model, where: Row): Promise<Row | undefined> {
    this.#assertSystem(model);
    const row = await this.#whereAll(this.#db.selectFrom(model.table).selectAll(), model, where)
      .limit(1).executeTakeFirst();
    return this.#decode(model, row as Row | undefined);
  }

  async systemList(model: Model, where: Row = {}): Promise<Row[]> {
    this.#assertSystem(model);
    const rows = await this.#whereAll(this.#db.selectFrom(model.table).selectAll(), model, where)
      .execute() as Row[];
    return rows.map((r) => this.#decode(model, r)!);
  }

  async systemCreate(model: Model, input: Row): Promise<Row> {
    this.#assertSystem(model);
    const now = new Date().toISOString();
    const values: Row = {
      id: input.id ?? crypto.randomUUID(),
      orgId: input.orgId ?? '_system',
      createdAt: now, updatedAt: now,
    };
    for (const own of model.columns) {
      if (!Object.prototype.hasOwnProperty.call(input, own)) continue;
      values[own] = this.#encode(model, own, input[own]);
    }
    await this.#db.insertInto(model.table).values(values).execute();
    return (await this.systemFind(model, { id: values.id }))!;
  }

  async systemUpdate(model: Model, id: string, patch: Row): Promise<Row | undefined> {
    this.#assertSystem(model);
    const set: Row = {};
    for (const own of model.columns) {
      if (!Object.prototype.hasOwnProperty.call(patch, own)) continue;
      set[own] = this.#encode(model, own, patch[own]);
    }
    set.updatedAt = new Date().toISOString();
    await this.#db.updateTable(model.table).set(set).where('id', '=', id).execute();
    return this.systemFind(model, { id });
  }

  async close() {
    if (this.#owned) await this.#sql.close();
  }
}
