/** The sqlite binding of the one SQL adapter. Behaviour lives in `sql.ts`. */
import { PROFILES } from './engines.ts';
import { SqlAdapter } from './sql.ts';

export class DBSqliteImpl extends SqlAdapter {
  constructor(source: string | { handle: unknown }) {
    super(PROFILES.sqlite, typeof source === 'string' ? `sqlite://${source}` : source);
  }
}
