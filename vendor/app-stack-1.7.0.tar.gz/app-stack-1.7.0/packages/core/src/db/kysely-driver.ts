/**
 * Kysely's connection contract over a `Bun.SQL` handle (decision D-01).
 *
 * Bun.SQL already speaks sqlite, PostgreSQL and MySQL/MariaDB, and Kysely
 * already owns the per-dialect compiler — placeholders, quoting, RETURNING,
 * LIMIT. That leaves this: hand the compiled SQL and its bound parameters to the
 * handle. No third-party glue, and an engine is a `EngineProfile` in
 * `engines.ts` rather than a second adapter.
 *
 * Transactions are deliberately NOT driven through Kysely's own transaction
 * support — see the driver below, which refuses them rather than issuing a
 * `BEGIN` the pool would scatter.
 */
import type { CompiledQuery, DatabaseConnection, Driver, QueryResult } from 'kysely';

class BunSqlConnection implements DatabaseConnection {
  constructor(readonly handle: any) {}

  async executeQuery<R>(query: CompiledQuery): Promise<QueryResult<R>> {
    const result = await this.handle.unsafe(query.sql, [...query.parameters]);
    const rows = Array.isArray(result) ? result : [];
    // Bun decorates the result array with the statement's metadata. It is the
    // only answer an engine without `RETURNING` can give to "did a row match?".
    const affected = (result as { affectedRows?: number | null })?.affectedRows;
    return {
      rows: rows as R[],
      ...(affected == null ? {} : { numAffectedRows: BigInt(affected) }),
    };
  }

  async *streamQuery(): AsyncIterableIterator<QueryResult<never>> {
    // Streaming belongs to the export path (WP-03 Q-112), which reads pages
    // through `list` rather than holding a cursor open.
    throw new Error('streaming is not supported by this driver');
  }
}

/**
 * A `Bun.SQL` handle is a POOL, and this driver deliberately does not reserve
 * from it: outside a transaction every statement stands alone, so connection
 * affinity buys nothing and a reserve/release round-trip per `get` would cost
 * something. `DBAdapter.tx` supplies the affinity a transaction does need, by
 * wrapping `Bun.SQL`'s `begin` and building a nested adapter over the
 * transaction-bound handle it yields.
 *
 * Which makes Kysely's own transaction support unusable here, and silently so:
 * `BEGIN`, the statements and `COMMIT` would each take whatever connection the
 * pool handed out, and the result would not be a transaction and would not
 * raise. So these three refuse. An adapter that would rather fail loudly than
 * return another tenant's rows should not quietly drop a rollback either.
 */
const NO_KYSELY_TX = 'transactions are driven by DBAdapter.tx through Bun.SQL\'s begin, not by Kysely: '
  + 'this driver pools per statement, so BEGIN here would land on an arbitrary connection';

class BunSqlDriver implements Driver {
  constructor(readonly handle: any) {}
  async init() {}
  async acquireConnection() { return new BunSqlConnection(this.handle); }
  async beginTransaction(): Promise<never> { throw new Error(NO_KYSELY_TX); }
  async commitTransaction(): Promise<never> { throw new Error(NO_KYSELY_TX); }
  async rollbackTransaction(): Promise<never> { throw new Error(NO_KYSELY_TX); }
  async releaseConnection() {}
  async destroy() {}
}

export const bunDriver = (handle: unknown): Driver => new BunSqlDriver(handle);
