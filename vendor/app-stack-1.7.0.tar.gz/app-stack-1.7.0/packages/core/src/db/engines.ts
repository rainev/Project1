/**
 * What actually differs between SQLite, PostgreSQL and MariaDB (WP-04 E-110/E-111).
 *
 * There is one adapter (`sql.ts`). An engine is not a second implementation of
 * it: it is this record — a Kysely dialect, a Bun.SQL connection, a DDL type per
 * declared property type, how the engine spells a boolean, and the two grammar
 * facts (`DELETE … RETURNING`, `CREATE INDEX IF NOT EXISTS`) that are not
 * universal. Everything security-relevant — model-owned identifiers, bound
 * values, the scope gate — lives above this file and is identical per engine.
 *
 * The spike behind decision D-01 predicted two branches, column types and
 * boolean storage. Adding MariaDB cost three more: a key column needs a length,
 * it has no `DELETE … RETURNING`, and `count(*)` comes back as something other
 * than a JS number. Each one is named here rather than smeared through the
 * adapter.
 */
import {
  MysqlAdapter, MysqlIntrospector, MysqlQueryCompiler,
  PostgresAdapter, PostgresIntrospector, PostgresQueryCompiler,
  SqliteAdapter, SqliteIntrospector, SqliteQueryCompiler,
  type Dialect,
} from 'kysely';
import { bunDriver } from './kysely-driver.ts';

export type Engine = 'sqlite' | 'postgres' | 'maria';

export interface EngineProfile {
  readonly dialect: Engine;
  /** Opens the connection this engine's URL names. */
  open(url: string): unknown;
  /** Kysely's compiler/adapter/introspector trio over an open Bun.SQL handle. */
  kysely(handle: unknown): Dialect;
  /** DDL type for a declared property type (`model.props[name].type`). */
  type(declared: string): string;
  /**
   * How this engine's INTROSPECTOR spells back a type this profile emitted.
   *
   * Every engine renames what you wrote: PostgreSQL reports `double precision`
   * as `float8`, MariaDB drops the length from `varchar(64)`, sqlite hands back
   * the declared string in upper case. Comparing a model's declared type with a
   * live column means knowing the round trip, and the round trip is a property
   * of the engine — so it lives here with the rest of them (WP-04 E-120).
   * Compared case-insensitively.
   */
  reportedType(ddl: string): string;
  /** DDL type for `id` and `orgId` — indexed, so MySQL wants a length. */
  readonly keyType: string;
  /** DDL type for the ISO-8601 timestamps the framework owns. */
  readonly stampType: string;
  /** How this engine stores a declared boolean. */
  encodeBoolean(value: boolean): unknown;
  /** `DELETE … RETURNING id`, or count the affected rows instead. */
  readonly deleteReturning: boolean;
  /** `CREATE INDEX IF NOT EXISTS`; MySQL/MariaDB has no such form. */
  readonly indexIfNotExists: boolean;
  /**
   * Whether a statement prepared before a DDL change survives it.
   *
   * PostgreSQL caches a PLAN per prepared statement and refuses to re-plan one
   * whose result type changed: `select *` on a table that has since gained a
   * column fails with `0A000 cached plan must not change result type`, and goes
   * on failing. `DEALLOCATE ALL` does not help — the driver's own name cache
   * then points at statements the server has forgotten. So the pool is
   * reopened after a migration alters anything (`SqlAdapter#reconnect`).
   *
   * sqlite and MariaDB re-plan on their own and need none of this. Found by
   * running the evolution cases on all three, not by reading (WP-04 E-120).
   */
  readonly plansSurviveDdl: boolean;
  /**
   * Where this engine sorts NULL, and whether it has to be told.
   *
   * sqlite and MariaDB sort NULL below every value. PostgreSQL sorts it above —
   * `NULLS LAST` on ASC, `NULLS FIRST` on DESC — which is exactly inverted, so a
   * report declared once in config shows a different first page depending on the
   * engine underneath. This flag says "spell the ordering out": true only for
   * PostgreSQL, because MySQL has no `NULLS` clause to spell it with and does
   * not need one.
   */
  readonly explicitNullOrder: boolean;
  /**
   * The collation every text column is CREATED with, or undefined where the
   * engine's default is already byte order.
   *
   * Collation is a property of the column, not of the query, so this is the
   * only place it can be settled. Left to their defaults the three engines sort
   * text three different ways — MariaDB case-insensitively, PostgreSQL however
   * the server happened to be `initdb`'d, sqlite by byte — and a report declared
   * once in config shows a different page on each. sqlite offers only BINARY and
   * NOCASE, so byte order is the one reading all three can guarantee, and it is
   * the one the application was built on.
   *
   * The cost is that ordering is case-sensitive and not locale-aware: "Zebra"
   * precedes "apple", and "ä" follows "z". Making that an author's choice means
   * an `x-storage` keyword, which belongs to the integrator (WP-04 asks).
   */
  readonly textCollation?: string;
}

const sqliteProfile: EngineProfile = {
  dialect: 'sqlite',
  open: (url) => new Bun.SQL({ adapter: 'sqlite', filename: url.slice('sqlite://'.length) }),
  kysely: (handle) => ({
    createDriver: () => bunDriver(handle),
    createQueryCompiler: () => new SqliteQueryCompiler(),
    createAdapter: () => new SqliteAdapter(),
    createIntrospector: (db) => new SqliteIntrospector(db),
  }),
  // sqlite has storage classes, not types: `real` is a double, `integer` is
  // 64-bit, and a boolean has nowhere to live but an integer.
  type: (declared) => ({ string: 'text', number: 'real', integer: 'integer', boolean: 'integer' })[declared]!,
  // sqlite stores the declared string verbatim and reports it back upper-cased.
  reportedType: (ddl) => ddl,
  keyType: 'text',
  stampType: 'text',
  encodeBoolean: (value) => (value ? 1 : 0),
  deleteReturning: true,
  indexIfNotExists: true,
  plansSurviveDdl: true,
  explicitNullOrder: false,
  // sqlite's default is BINARY.
};

const postgresProfile: EngineProfile = {
  dialect: 'postgres',
  open: (url) => new Bun.SQL(url),
  kysely: (handle) => ({
    createDriver: () => bunDriver(handle),
    createQueryCompiler: () => new PostgresQueryCompiler(),
    createAdapter: () => new PostgresAdapter(),
    createIntrospector: (db) => new PostgresIntrospector(db),
  }),
  // `double precision`, not `real`: a declared `number` is a JS double, and
  // `real` would quietly round 1.25e-40 on the way back out.
  type: (declared) => ({
    string: 'text', number: 'double precision', integer: 'integer', boolean: 'boolean',
  })[declared]!,
  reportedType: (ddl) => ({
    text: 'text', 'double precision': 'float8', integer: 'int4', boolean: 'bool',
  })[ddl] ?? ddl,
  keyType: 'text',
  stampType: 'text',
  encodeBoolean: (value) => value,
  deleteReturning: true,
  indexIfNotExists: true,
  plansSurviveDdl: false,
  explicitNullOrder: true,
  // Not the server's `initdb` locale: the same config must page the same way on
  // a C-locale container and an en_US.UTF-8 cluster.
  textCollation: '"C"',
};

const mariaProfile: EngineProfile = {
  dialect: 'maria',
  open: (url) => new Bun.SQL(url),
  kysely: (handle) => ({
    createDriver: () => bunDriver(handle),
    createQueryCompiler: () => new MysqlQueryCompiler(),
    createAdapter: () => new MysqlAdapter(),
    createIntrospector: (db) => new MysqlIntrospector(db),
  }),
  type: (declared) => ({
    string: 'text', number: 'double', integer: 'int', boolean: 'tinyint(1)',
  })[declared]!,
  // MariaDB reports a type without its length, and `tinyint(1)` as `tinyint`.
  reportedType: (ddl) => ddl.replace(/\(\d+\)$/, ''),
  // A `text` column cannot be a primary key or carry an index without a prefix
  // length, and both `id` and `orgId` are indexed on every table.
  keyType: 'varchar(64)',
  stampType: 'varchar(32)',
  encodeBoolean: (value) => (value ? 1 : 0),
  // MariaDB has DELETE … RETURNING, MySQL does not; `affectedRows` is the
  // answer on both, and the question — "did a row match?" — is the same.
  deleteReturning: false,
  indexIfNotExists: false,
  plansSurviveDdl: true,
  explicitNullOrder: false,
  textCollation: 'utf8mb4_bin',
};

/** Scheme → engine. The only place a URL decides anything. */
const SCHEMES: Record<string, EngineProfile> = {
  'sqlite:': sqliteProfile,
  'postgres:': postgresProfile,
  'postgresql:': postgresProfile,
  'mysql:': mariaProfile,
  'mariadb:': mariaProfile,
};

export function profileFor(url: string): EngineProfile {
  const scheme = `${url.split('://')[0]}:`;
  const profile = SCHEMES[scheme];
  if (!profile) {
    throw new Error(
      `unsupported database url: ${scheme}// (expected one of ${Object.keys(SCHEMES).map((s) => `${s}//`).join(', ')})`,
    );
  }
  return profile;
}

export const PROFILES = { sqlite: sqliteProfile, postgres: postgresProfile, maria: mariaProfile };
