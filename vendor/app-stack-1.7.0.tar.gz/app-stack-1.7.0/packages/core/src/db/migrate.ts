/**
 * Schema evolution (WP-04 E-120/E-121, DEF-004).
 *
 * `CREATE TABLE IF NOT EXISTS` is what the adapter did before this file: it
 * made a table that did not exist and then refused to boot if the one that did
 * had the wrong shape. That is correct and useless — the only remedy it named
 * was "drop the database".
 *
 * What replaces it:
 *
 *   - **Additive changes apply themselves.** A property added to a model
 *     becomes a nullable column on the next boot, and rows written before it
 *     read back as `null`.
 *   - **Destructive or ambiguous changes refuse to boot**, naming the change
 *     and the declaration that would authorise it. A column that disappeared
 *     from a model either moved or was meant to go, and nothing in the config
 *     says which — so the framework does not guess.
 *   - **`x-storage.migrations` declares the intent** it will not guess: a
 *     rename or a drop, applied in order before the diff.
 *
 * **Where truth lives.** The diff is computed against the DATABASE, by
 * introspection — never against the ledger. A ledger that disagreed with the
 * schema would be believed, and this project has already paid once for
 * believing a record over the running thing. `_migrations` is therefore
 * history, not state: it says what was applied and when, and idempotence comes
 * from the schema itself (a rename whose `from` column is gone is a no-op
 * because the column is gone, not because a row says so).
 *
 * **Identifiers.** A migration step names a column the model no longer
 * declares, so it cannot resolve through `column()`. Two things stand in for
 * that: the meta-schema admits only `[A-Za-z_][A-Za-z0-9_]*`, and every name
 * reaching DDL here is matched against the set the INTROSPECTOR reported, so
 * the string that lands in `ALTER TABLE` is one the database itself named.
 */
import { compileModel, SYSTEM_FIELDS, type MigrationStep, type Model } from '../model.ts';
import type { EngineProfile } from './engines.ts';

/**
 * The ledger. Framework-owned like `_users`, and created by `migrate` itself
 * rather than by the caller's model list, because it has to exist before the
 * first model is looked at.
 */
export const MIGRATION: Model = compileModel({
  $id: '_migration',
  type: 'object',
  properties: {
    /** Deterministic, so the same change is one row however often it boots. */
    key: { type: 'string' },
    table: { type: 'string' },
    /** 'create' | 'add' | 'rename' | 'drop' | 'index' */
    kind: { type: 'string' },
    /** Human-readable: what actually ran. */
    detail: { type: 'string' },
    at: { type: 'string' },
  },
  'x-storage': { table: '_migrations', notNull: ['key', 'table', 'kind'] },
}, 'framework:_migration');

/** One column as the engine's introspector reports it. */
export interface ExistingColumn {
  name: string;
  dataType: string;
  isNullable: boolean;
}

/** One column as the model declares it, in this engine's spelling. */
export interface DesiredColumn {
  name: string;
  /** DDL type, without the collation clause the adapter appends. */
  ddl: string;
  notNull: boolean;
}

/**
 * The columns a table must have: the four framework-owned ones, then every
 * persisted property in declaration order (blind-index shadows included — they
 * are in `model.columns` like any other).
 */
export function desiredColumns(model: Model, engine: EngineProfile): DesiredColumn[] {
  const out: DesiredColumn[] = [
    { name: 'id', ddl: engine.keyType, notNull: true },
    { name: 'orgId', ddl: engine.keyType, notNull: true },
    { name: 'createdAt', ddl: engine.stampType, notNull: true },
    { name: 'updatedAt', ddl: engine.stampType, notNull: true },
  ];
  for (const name of model.columns) {
    out.push({
      name,
      ddl: engine.type(model.props[name]!.type),
      notNull: model.notNull.includes(name),
    });
  }
  return out;
}

export interface TableDiff {
  /** Columns to add. Always nullable — see `refusals` for why. */
  add: DesiredColumn[];
  /** Changes the framework will not make. Non-empty means: do not boot. */
  refusals: string[];
}

const lower = (value: string) => value.toLowerCase();

/**
 * What separates this table from its model.
 *
 * Additive is exactly: a declared column the table does not have, and which the
 * model does not declare NOT NULL. Everything else is a refusal, because
 * everything else either destroys data or asks the framework to invent some.
 */
export function diffTable(
  model: Model,
  engine: EngineProfile,
  existing: readonly ExistingColumn[],
): TableDiff {
  const desired = desiredColumns(model, engine);
  const have = new Map(existing.map((c) => [c.name, c]));
  const want = new Map(desired.map((c) => [c.name, c]));

  const add: DesiredColumn[] = [];
  const refusals: string[] = [];
  const missing: string[] = [];
  const extra = existing.filter((c) => !want.has(c.name)).map((c) => c.name);

  for (const column of desired) {
    const actual = have.get(column.name);
    if (!actual) {
      missing.push(column.name);
      if (column.notNull) {
        // sqlite cannot ADD a NOT NULL column at all without a default, and on
        // a table with rows neither can the others without inventing a value.
        // Refusing on every engine keeps one answer rather than three.
        refusals.push(
          `add NOT NULL column "${column.name}" — a column added to an existing table must be nullable. ` +
          `Remove "${column.name}" from x-storage.notNull, or recreate the table.`,
        );
      } else {
        add.push(column);
      }
      continue;
    }
    if (lower(actual.dataType) !== lower(engine.reportedType(column.ddl))) {
      refusals.push(
        `change the type of "${column.name}" from ${actual.dataType} to ${column.ddl} — ` +
        `a type change needs a per-engine cast and is not declarable`,
      );
    }
    // sqlite reports a TEXT primary key as nullable (it permits NULL there
    // unless told otherwise), so the framework-owned `id` is exempt from the
    // nullability comparison rather than refusing every sqlite boot.
    if (column.name !== 'id' && actual.isNullable === column.notNull) {
      refusals.push(
        `make "${column.name}" ${column.notNull ? 'NOT NULL' : 'nullable'} — ` +
        `changing the nullability of an existing column is not declarable`,
      );
    }
  }

  for (const name of extra) {
    const hint = missing.length
      ? `If it was renamed, declare x-storage.migrations: [{ rename: { from: ${name}, to: <${missing.join('|')}> } }]. ` +
        `If it is no longer wanted, declare [{ drop: ${name} }].`
      : `Declare x-storage.migrations: [{ drop: ${name} }] to remove it.`;
    refusals.push(`drop column "${name}", which the model no longer declares — ${hint}`);
  }

  return { add, refusals };
}

/** The ledger key for a step: deterministic, and readable in a `select *`. */
export function stepKey(model: Model, step: MigrationStep): string {
  return step.rename
    ? `${model.table}:rename:${step.rename.from}>${step.rename.to}`
    : `${model.table}:drop:${step.drop}`;
}

export type PlannedStep =
  | { kind: 'rename'; key: string; from: string; to: string }
  | { kind: 'drop'; key: string; column: string };

/**
 * Which declared steps still have work to do, given what the table looks like
 * now. A step whose source column is gone has already run — on this database or
 * on the `CREATE TABLE` that made it — and is skipped without complaint.
 *
 * A rename whose `from` AND `to` both exist is the one case that cannot be
 * resolved: renaming would collide, skipping would leave two columns where the
 * model declares one. It refuses.
 */
export function planSteps(
  model: Model,
  existing: readonly ExistingColumn[],
): { steps: PlannedStep[]; refusals: string[] } {
  const present = new Set(existing.map((c) => c.name));
  const steps: PlannedStep[] = [];
  const refusals: string[] = [];

  for (const step of model.migrations) {
    const key = stepKey(model, step);
    if (step.rename) {
      const { from, to } = step.rename;
      if (!present.has(from)) continue;
      if (present.has(to)) {
        refusals.push(
          `rename "${from}" to "${to}": both columns exist. Drop one by hand and restart — ` +
          `the framework will not choose which of two populated columns to keep.`,
        );
        continue;
      }
      if ((SYSTEM_FIELDS as readonly string[]).includes(from)) {
        refusals.push(`rename "${from}": it is framework-owned`);
        continue;
      }
      steps.push({ kind: 'rename', key, from, to });
      present.delete(from);
      present.add(to);
    } else {
      const column = step.drop!;
      if (!present.has(column)) continue;
      if ((SYSTEM_FIELDS as readonly string[]).includes(column)) {
        refusals.push(`drop "${column}": it is framework-owned`);
        continue;
      }
      steps.push({ kind: 'drop', key, column });
      present.delete(column);
    }
  }

  return { steps, refusals };
}

/** The boot refusal, with every problem at once rather than one per restart. */
export function refusalError(model: Model, refusals: string[]): Error {
  return new Error(
    `model "${model.name}" (table "${model.table}") asks for a change the framework will not make:\n` +
    refusals.map((r) => `  - ${r}`).join('\n') +
    `\nThe database was left untouched.`,
  );
}
