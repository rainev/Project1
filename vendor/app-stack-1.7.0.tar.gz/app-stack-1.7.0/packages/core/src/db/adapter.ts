/**
 * The storage seam. The generic surface deliberately exposes no joins and no
 * raw predicates, so a document adapter can arrive later without the interface
 * lying. `query` is the one exception, and it is not an escape hatch: it takes
 * a plan the framework compiled from declared models and relations, never text.
 */
import type { Model } from '../model.ts';
import type { ExecutableQuery, QueryPage } from '../queries/compiled.ts';

export type Row = Record<string, unknown>;

/** Column -> value, contributed by the scope gate and bound into every query. */
/**
 * A cross-tenant READ's scope value: a bound list instead of a bound value
 * (WP-03 Q-123). Scope is never emptied to widen it — `{ orgId: { in: [...] } }`
 * says "these tenants" where `{ orgId: 'o1' }` says "this one", so the
 * empty-scope refusal that every operation performs stays exactly as it was and
 * forgetting the mechanism is a refusal rather than a leak.
 *
 * Write paths refuse it: widening is a statement about what may be READ, and
 * there is no such thing as creating a row in several tenants at once.
 */
export interface ScopeList {
  in: readonly unknown[];
}

export type Scope = Record<string, unknown | ScopeList>;

export const isScopeList = (value: unknown): value is ScopeList =>
  typeof value === 'object' && value !== null && Array.isArray((value as ScopeList).in);

export type FilterOp = 'eq' | 'ne' | 'gt' | 'gte' | 'lt' | 'lte' | 'contains' | 'in';

export interface Filter {
  field: string;
  op: FilterOp;
  value: unknown;
}

export interface ListOptions {
  limit?: number;
  sort?: string;
  dir?: 'asc' | 'desc';
  filters?: Filter[];
  /** Opaque cursor from a previous page. */
  cursor?: string;
}

export interface ListPage {
  rows: Row[];
  nextCursor?: string;
}

export interface DBAdapter {
  readonly dialect: 'sqlite' | 'postgres' | 'maria';
  migrate(models: Iterable<Model>): Promise<string[]>;
  /**
   * A declared query (§7.1). The only operation that joins, and it joins
   * nothing it was not handed: `ExecutableQuery` carries tables, columns and
   * bound values that the framework already resolved from its own model
   * definitions, plus one evaluated scope per participating table. An adapter
   * neither reads config nor decides policy.
   */
  query(plan: ExecutableQuery): Promise<QueryPage>;
  /**
   * `orgId` is framework-owned and NOT NULL on every table, so a row needs one
   * whether or not the model's READ scope mentions tenancy (WP-07 S-101). A
   * public model is scoped by a property of the row — `{ published: true }` —
   * and would otherwise be readable by a visitor and writable by nobody.
   */
  create(model: Model, scope: Scope, input: Row, options?: { id?: string; orgId?: string }): Promise<Row>;
  get(model: Model, scope: Scope, id: string): Promise<Row | undefined>;
  list(model: Model, scope: Scope, options?: ListOptions): Promise<ListPage>;
  count(model: Model, scope: Scope, filters?: Filter[]): Promise<number>;
  aggregate(model: Model, scope: Scope, spec: AggregateSpec): Promise<Row[]>;
  update(model: Model, scope: Scope, id: string, input: Row): Promise<Row | undefined>;
  /** Scoped delete. False when no row matched, so another tenant's id is a miss, not a lie. */
  delete(model: Model, scope: Scope, id: string): Promise<boolean>;
  /**
   * Rewrite framework-owned bytes without touching the row (WP-04 E-122).
   *
   * Key rotation re-seals ciphertext under a new key id. The plaintext is the
   * same, nobody edited anything, and `updatedAt` must not move — a rotation
   * that made every row look freshly edited would corrupt every "recently
   * changed" sort and report in the application above it. Scoped like any other
   * write, so a rotation still walks one tenant at a time.
   */
  reseal(model: Model, scope: Scope, id: string, values: Row): Promise<void>;
  /** Scoped existence check backing `x-unique`. */
  existsWith(model: Model, scope: Scope, where: Row, exceptId?: string): Promise<boolean>;
  /** One transaction per action; a throw rolls everything back. */
  tx<T>(fn: (adapter: DBAdapter) => Promise<T>): Promise<T>;

  /**
   * Framework-only access to system models (`_user`, `_session`, ...), which are
   * not tenant-scoped and are unreachable from generic dispatch. Implementations
   * must refuse a model whose name does not begin with `_`.
   */
  systemFind(model: Model, where: Row): Promise<Row | undefined>;
  /** Every row of a system model. Framework-only, and system models stay small. */
  systemList(model: Model, where?: Row): Promise<Row[]>;
  systemCreate(model: Model, input: Row): Promise<Row>;
  systemUpdate(model: Model, id: string, patch: Row): Promise<Row | undefined>;
  close(): Promise<void>;
}

export type AggregateFn = 'count' | 'sum' | 'avg' | 'min' | 'max';

export interface AggregateMeasure {
  op: AggregateFn;
  field?: string;
  as: string;
}

export interface AggregateSpec {
  groupBy?: string[];
  measures: AggregateMeasure[];
  filters?: Filter[];
}

/**
 * Re-exported from `limits.ts`, which reads them from the environment at boot.
 * Kept on this module because `db/sql.ts` and every adapter reach for them
 * here, and the clamp they feed is the invariant (§22): a caller's `limit` is
 * forced into `[1, MAX_LIMIT]` and an absent one becomes `DEFAULT_LIMIT`.
 */
export { LIST_MAX_LIMIT as MAX_LIMIT, LIST_DEFAULT_LIMIT as DEFAULT_LIMIT } from '../limits.ts';
