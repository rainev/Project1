/** The MariaDB/MySQL binding of the one SQL adapter. Behaviour lives in `sql.ts`. */
import { PROFILES } from './engines.ts';
import { SqlAdapter } from './sql.ts';

export class DBMariaImpl extends SqlAdapter {
  constructor(source: string | { handle: unknown }) {
    super(PROFILES.maria, source);
  }
}
