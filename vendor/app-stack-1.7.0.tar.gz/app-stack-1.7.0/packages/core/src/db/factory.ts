/**
 * URL scheme → engine (WP-04 E-112). The connection string itself resolves
 * through the secret seam (§10), so a password reaches the process as a mounted
 * file rather than an environment variable a process listing would show.
 */
import { secret } from '../secrets.ts';
import type { DBAdapter } from './adapter.ts';
import { profileFor } from './engines.ts';
import { SqlAdapter } from './sql.ts';

/** Chooses the engine implementation from the URL's scheme. */
export function createAdapter(url: string): DBAdapter {
  return new SqlAdapter(profileFor(url), url);
}

/**
 * The configured database URL, or the given default. `DATABASE_URL_FILE` wins
 * the same way every other secret's file form does — a connection string with a
 * password in it is a secret, and §10 is where secrets come from.
 */
export function resolveDatabaseUrl(fallback: string): string {
  return secret('DATABASE_URL', { optional: true }) ?? fallback;
}
