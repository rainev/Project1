/**
 * Which roles exist, and who may hand them out (WP-03 Q-121).
 *
 * Tenant roles are assigned by the server, per org: the first account in an org
 * founds it (`admin`), everyone after holds the join code (`staff`). Those are
 * ASSIGNABLE — a registration path may grant them.
 *
 * `platform` is RESERVED, because it is the one role that reads across tenants
 * (§22's single carve-out, WP-03 Phase 3). Two rules keep it out of reach, and
 * the second is the one that matters:
 *
 *  1. No request-reachable path may assign it. `assertAssignable` is the one
 *     place that refuses, so a future path that writes roles — WP-05 letting an
 *     org administer its own — inherits the refusal instead of repeating it.
 *
 *  2. STORAGE IS NOT A SOURCE FOR IT. `storedRoles` strips every reserved name
 *     off a row on the way out, so a `roles` column containing `platform` —
 *     written by a defect, a migration, a direct SQL session or a restored
 *     backup — grants nothing. The claim comes from server configuration alone.
 *
 * Issuance is therefore deliberately outside the database: `PLATFORM_ADMINS`
 * names the accounts, the same way `JWT_SECRET_FILE` names a secret, and it is
 * evaluated every time a token is issued — so removing an address revokes the
 * claim at the next refresh rather than whenever a row is next written. WP-05
 * owns the real admin surface; this is the bootstrap it replaces.
 */

/** The role that reads across tenants. Never assignable, never read from a row. */
export const PLATFORM_ROLE = 'platform';

/** Roles a registration path may grant. `customer` is a participant identity:
 *  it reads only the rows it owns, never the org's (WB-001). */
export const ASSIGNABLE_ROLES = ['admin', 'staff', 'customer'] as const;

/** Names no request may put on an identity. */
export const RESERVED_ROLES: readonly string[] = [PLATFORM_ROLE];

export class ReservedRoleError extends Error {
  constructor(where: string, role: string) {
    super(
      `${where}: "${role}" is a reserved role and cannot be assigned — ` +
        `assignable roles are ${ASSIGNABLE_ROLES.join(', ')}`,
    );
    this.name = 'ReservedRoleError';
  }
}

/**
 * Refuse a reserved role before it is written. Called by every path that assigns
 * roles; `where` names the caller so the error says which one tried.
 */
export function assertAssignable(roles: readonly string[], where: string): void {
  for (const role of roles) {
    if (RESERVED_ROLES.includes(role)) throw new ReservedRoleError(where, role);
  }
}

/**
 * The roles a stored row actually confers. Reserved names are stripped rather
 * than rejected: a row is data, and the safe reading of unexpected data is to
 * grant less, not to refuse a login nobody can fix.
 */
export function storedRoles(value: unknown): string[] {
  return String(value ?? '')
    .split(',')
    .map((role) => role.trim())
    .filter(Boolean)
    .filter((role) => !RESERVED_ROLES.includes(role));
}

/**
 * The platform accounts named by server configuration. Addresses are compared
 * the way registration stores them: trimmed and lower-cased.
 */
export function platformAdmins(value: string | undefined): ReadonlySet<string> {
  return new Set(
    String(value ?? '')
      .split(',')
      .map((email) => email.trim().toLowerCase())
      .filter(Boolean),
  );
}

/** The roles a token carries: what the row confers, plus the configured claim. */
export function rolesFor(
  user: { email?: unknown; roles?: unknown },
  admins: ReadonlySet<string> = new Set(),
): string[] {
  const roles = storedRoles(user.roles);
  const email = String(user.email ?? '').trim().toLowerCase();
  if (email && admins.has(email)) roles.push(PLATFORM_ROLE);
  return roles;
}

/** Whether an actor holds the cross-tenant claim. */
export const isPlatform = (actor: { roles?: readonly string[] }): boolean =>
  (actor.roles ?? []).includes(PLATFORM_ROLE);
