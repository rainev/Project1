/**
 * HS256 JWT. The token dictates its expiry; it never dictates its algorithm.
 * Trusting the `alg` header is the alg-confusion class (ARCHITECTURE §15).
 */
const PINNED_ALG = 'HS256';
const encoder = new TextEncoder();

const b64url = (bytes: ArrayBuffer | Uint8Array): string =>
  Buffer.from(bytes as ArrayBuffer).toString('base64url');

const fromB64url = (text: string): Uint8Array => new Uint8Array(Buffer.from(text, 'base64url'));

export interface Claims {
  sub: string;
  org: string;
  roles: string[];
  ver: number;
  iat: number;
  exp: number;
  /** Optional: a token that is not valid yet. Honoured with skew (P-112). */
  nbf?: number;
}

async function key(secret: string): Promise<CryptoKey> {
  return crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign', 'verify']);
}

export async function signJwt(claims: Omit<Claims, 'iat' | 'exp'>, secret: string, ttlSeconds: number, kid = 'k1'): Promise<string> {
  const now = Math.floor(Date.now() / 1000);
  const header = b64url(encoder.encode(JSON.stringify({ alg: PINNED_ALG, typ: 'JWT', kid })));
  const payload = b64url(encoder.encode(JSON.stringify({ ...claims, iat: now, exp: now + ttlSeconds })));
  const body = `${header}.${payload}`;
  const signature = await crypto.subtle.sign('HMAC', await key(secret), encoder.encode(body));
  return `${body}.${b64url(signature)}`;
}

export type VerifyResult =
  | { ok: true; claims: Claims }
  | { ok: false; reason: string };

/** Verify order: pin the algorithm, resolve the key, check the signature, THEN read claims. */
export async function verifyJwt(token: string, keys: Record<string, string>, skewSeconds = 60): Promise<VerifyResult> {
  const parts = token.split('.');
  if (parts.length !== 3) return { ok: false, reason: 'malformed' };
  const [header, payload, signature] = parts as [string, string, string];

  let head: { alg?: string; typ?: string; kid?: string };
  try {
    head = JSON.parse(Buffer.from(header, 'base64url').toString('utf8'));
  } catch {
    return { ok: false, reason: 'malformed_header' };
  }

  // Never take the algorithm from the token.
  if (head.alg !== PINNED_ALG) return { ok: false, reason: `algorithm_not_allowed:${head.alg}` };
  if (head.typ && head.typ !== 'JWT') return { ok: false, reason: 'type_not_allowed' };

  // `kid` selects from an allowlist; it never supplies a key.
  const secret = keys[head.kid ?? 'k1'];
  if (!secret) return { ok: false, reason: 'unknown_kid' };

  const valid = await crypto.subtle.verify(
    'HMAC',
    await key(secret),
    fromB64url(signature),
    encoder.encode(`${header}.${payload}`),
  );
  if (!valid) return { ok: false, reason: 'bad_signature' };

  let claims: Claims;
  try {
    claims = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
  } catch {
    return { ok: false, reason: 'malformed_claims' };
  }

  const now = Math.floor(Date.now() / 1000);
  if (typeof claims.exp !== 'number' || now > claims.exp + skewSeconds) return { ok: false, reason: 'expired' };

  /**
   * `nbf` and `iat` (P-112, AUD-023).
   *
   * Nothing this server signs carries an `nbf` today, which is exactly why it
   * is checked: an unchecked claim is one an attacker gets to choose the
   * meaning of, and a token minted for later must not work now. Both are
   * allowed the same clock skew `exp` already gets — the two machines in a
   * deployment do not agree to the second, and refusing a token a second early
   * is as wrong as honouring one a minute late.
   *
   * `iat` is a sanity check rather than a security boundary: a token claiming
   * to have been issued in the future is malformed, and saying so beats
   * silently accepting it.
   */
  if (typeof claims.nbf === 'number' && now + skewSeconds < claims.nbf) {
    return { ok: false, reason: 'not_yet_valid' };
  }
  if (typeof claims.iat === 'number' && claims.iat > now + skewSeconds) {
    return { ok: false, reason: 'issued_in_the_future' };
  }

  return { ok: true, claims };
}
