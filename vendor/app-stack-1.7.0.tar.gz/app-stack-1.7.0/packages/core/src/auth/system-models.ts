import { compileModel, type Model } from '../model.ts';

/**
 * Framework-owned models. They use the same adapter and the same migrations —
 * auth state is durable, never in-memory maps that vanish on restart.
 * Names begin with `_`, which generic dispatch refuses.
 */
/**
 * The account, as a model an application may READ.
 *
 * It is registered under its own name rather than hidden behind the reserved
 * prefix, because a domain model has to be able to point at it: a ticket's
 * agent, an order's rep, a payslip's employee. While it was unregistered,
 * `x-lookup: { model: user }` and `from: user` were both refused at boot, and
 * an app's only option was an opaque id with no referential integrity and no
 * way to report across the two.
 *
 * Three things keep that safe, and none of them is an expression an app owns:
 *
 *  - `x-dispatch: read` — no `create`, `update` or `delete` through the one
 *    door. `roles` is a writable column, so a generic update carrying it would
 *    be privilege escalation. Writes stay on `/v0/auth/`, where each route
 *    re-derives the actor and decides for itself.
 *  - `x-internal` on the credential and the revocation counter — absent from
 *    every derived schema, every response, every query and every sort.
 *  - `x-scope` on the org, so one tenant never reads another's members.
 *
 * `x-access.read` admits any actor that is not a visitor. A colleague's name is
 * what makes a relation label render, and scope already confines it to the org;
 * the
 * ADMINISTRATION of members — who may invite, change a role, deactivate — is a
 * different question and stays on the routes, which are admin-only.
 *
 * The table keeps its `_users` name. Storage is not what config addresses, and
 * renaming it would be a migration every existing deployment had to run for no
 * behavioural gain.
 */
export const USER: Model = compileModel({
  $id: 'user',
  type: 'object',
  'x-dispatch': 'read',
  'x-access': { read: "!('anonymous' in actor.roles)" },
  'x-scope': { orgId: 'actor.orgId' },
  properties: {
    email: { type: 'string' },
    passwordHash: { type: 'string', 'x-internal': true },
    roles: { type: 'string' },
    tokenVersion: { type: 'integer', 'x-internal': true },
    /**
     * A deactivated member keeps their row — an audit trail points at it, and
     * deleting the row would orphan every `_audits.actorId` that names them.
     * Login refuses them and their sessions are revoked, so the row is a
     * tombstone rather than a credential (WP-05 P-103).
     */
    deactivated: { type: 'boolean' },
  },
  'x-storage': { table: '_users', notNull: ['email', 'passwordHash'] },
}, 'framework:user');

/**
 * An invitation to join a specific org with a specific role (WP-05 P-102).
 *
 * The token is stored **hashed**, like a refresh token and for the same reason:
 * it is a bearer credential that admits its holder to a tenant, so a database
 * read must not yield something that can be presented. It is shown once, when
 * the invite is created, and never again.
 *
 * `roles` is written by an admin, so it passes `assertAssignable` on the way in
 * AND on the way out — a reserved role must not be reachable by storing it here
 * and redeeming it later (§22, Q-121).
 */
export const INVITE: Model = compileModel({
  $id: 'invite',
  type: 'object',
  // Who has been asked to join, and whether they came. Administrative, so the
  // read is admin-only — the same actor the routes admit.
  'x-dispatch': 'read',
  'x-access': { read: "'admin' in actor.roles || 'platform' in actor.roles" },
  'x-scope': { orgId: 'actor.orgId' },
  properties: {
    email: { type: 'string' },
    roles: { type: 'string' },
    tokenHash: { type: 'string', 'x-internal': true },
    expiresAt: { type: 'string' },
    /** Set when redeemed. A spent invite is refused rather than deleted. */
    acceptedAt: { type: 'string' },
    invitedBy: { type: 'string' },
  },
  'x-storage': { table: '_invites', notNull: ['email', 'tokenHash', 'expiresAt'] },
}, 'framework:invite');

export const SESSION: Model = compileModel({
  $id: 'session',
  type: 'object',
  /**
   * An actor reads their OWN sessions; an admin reads the org's. That is what
   * makes "sign out my other devices" expressible without a route of its own.
   *
   * `familyId` is internal alongside the hash: it links a rotation chain, so
   * exposing it would let one session's holder recognise another's lineage.
   */
  'x-dispatch': 'read',
  'x-access': { read: "!('anonymous' in actor.roles)" },
  'x-scope': {
    orgId: 'actor.orgId',
    userId: "'admin' in actor.roles ? null : actor.id",
  },
  properties: {
    userId: { type: 'string' },
    familyId: { type: 'string', 'x-internal': true },
    tokenHash: { type: 'string', 'x-internal': true },
    expiresAt: { type: 'string' },
    revoked: { type: 'boolean' },
    usedAt: { type: 'string' },
  },
  'x-storage': { table: '_sessions', notNull: ['userId', 'familyId', 'tokenHash', 'expiresAt'] },
}, 'framework:session');


/**
 * An organisation is created by the system, never named by a client.
 *
 * `joinCode` is a high-entropy secret an org hands out to let someone register
 * straight into it. It is deliberately NOT the orgId: the orgId travels in every
 * row, every token and every API response, so it can be neither secret nor
 * rotatable. The join code is both.
 */
export const ORG: Model = compileModel({
  $id: 'org',
  type: 'object',
  /**
   * Scoped by its own `id`, not by `orgId`: this model IS the tenant, so the
   * question "which rows are mine" has a different answer here than anywhere
   * else. The join code is a bearer secret shown once, so it never leaves
   * through a read — the settings route already withheld it, and `x-internal`
   * is what makes that a property rather than a habit.
   */
  'x-dispatch': 'read',
  'x-access': { read: "!('anonymous' in actor.roles)" },
  'x-scope': { id: 'actor.orgId' },
  properties: {
    name: { type: 'string' },
    joinCode: { type: 'string', 'x-internal': true },
    isDefault: { type: 'boolean' },
    /**
     * Per-org settings (WP-05 P-120).
     *
     * Discrete typed columns rather than the `settings` JSON blob the handoff
     * sketched: every other system model is typed, the boot drift check can see
     * a column and cannot see inside a string, and WP-04 made adding one an
     * additive ALTER at boot. A blob would trade that for the freedom to store
     * a setting nothing validates.
     *
     * `displayName` is what the org calls itself; `name` stays the unique key.
     * `defaultRole` is what a JOIN-CODE registration grants — an invite always
     * names its own. `accessTtlSeconds` narrows the access-token lifetime for
     * this tenant, clamped into bounds and applying to newly issued tokens
     * only, because a token already minted carries its own `exp` (§15).
     */
    displayName: { type: 'string' },
    defaultRole: { type: 'string' },
    accessTtlSeconds: { type: 'integer' },
  },
  'x-storage': { table: '_orgs', notNull: ['name', 'joinCode'] },
}, 'framework:org');

/**
 * The audit record: the envelope, plus how it ended (§6).
 *
 * It records WHAT was attempted and by whom — never the payload or the result.
 * §8 is explicit that audit takes the projected view and cannot leak plaintext,
 * and the simplest way to guarantee that is to store no values at all: field
 * NAMES are enough to reconstruct intent, and a decrypted `adminOnlyNote` written
 * here would defeat the encryption it sits next to.
 *
 * Written outside the request's transaction, so a rollback or a denial still
 * leaves a trace — a refused request is the one most worth having.
 */
export const AUDIT: Model = compileModel({
  $id: 'audit',
  type: 'object',
  // Every field is already value-free by design, so nothing here is internal.
  // Administrative to read: it is the record of what everyone attempted.
  'x-dispatch': 'read',
  'x-access': { read: "'admin' in actor.roles || 'platform' in actor.roles" },
  'x-scope': { orgId: 'actor.orgId' },
  properties: {
    requestId: { type: 'string' },
    source: { type: 'string' },
    actorId: { type: 'string' },
    actorRoles: { type: 'string' },
    op: { type: 'string' },
    model: { type: 'string' },
    rowId: { type: 'string' },
    /** Field names present in the payload. Names only, never values. */
    fields: { type: 'string' },
    /** 'ok' | 'denied' | 'not_found' | 'invalid' | 'error' */
    outcome: { type: 'string' },
    status: { type: 'integer' },
    detail: { type: 'string' },
    at: { type: 'string' },
  },
  'x-storage': { table: '_audits', notNull: ['requestId', 'op', 'outcome'] },
}, 'framework:audit');

export const SYSTEM_MODELS: Model[] = [USER, SESSION, ORG, INVITE, AUDIT];

/**
 * The framework's models, added to an application's registry at boot.
 *
 * Every one is readable under its own policy, write-sealed against generic
 * dispatch, scoped, and carries `x-internal` on anything that must not leave:
 * a password hash, a revocation counter, a join code, two token hashes and a
 * session's family id.
 *
 * **These five names are reserved.** An application declaring `user`, `org`,
 * `invite`, `session` or `audit` is refused at boot naming the clash, because
 * silently letting either side win would mean a lookup resolving against
 * something other than the document its author read.
 */
export const REGISTERED_SYSTEM_MODELS: Model[] = [USER, ORG, INVITE, SESSION, AUDIT];

/**
 * `outbox` and `schedule` live with the machinery that writes them, and join
 * the registry the same way — see `app.ts`, which assembles the full list.
 */
