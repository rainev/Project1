/**
 * Auth routes. Tokens are cookies, not headers: the UI is same-origin, so the
 * access token is unreachable from JavaScript (ARCHITECTURE §15).
 */
import type { DBAdapter, Row } from '../db/adapter.ts';
import type { Actor } from '../engine/types.ts';
import { json } from '../server.ts';
import { signJwt, verifyJwt } from './jwt.ts';
import { assertAssignable, ASSIGNABLE_ROLES, rolesFor, storedRoles } from './roles.ts';
import { INVITE, ORG, SESSION, USER } from './system-models.ts';
import { createAdminRoutes, ORG_ACCESS_TTL_MAX, ORG_ACCESS_TTL_MIN } from './admin.ts';
import { createGuard, type Client } from './rate-limit.ts';

export const ACCESS_TTL_SECONDS = 15 * 60;
export const REFRESH_TTL_SECONDS = 30 * 24 * 60 * 60;

const ACCESS_COOKIE = 'as_at';
const REFRESH_COOKIE = 'as_rt';
const REFRESH_PATH = '/v0/auth/refresh';
/**
 * The access cookie is scoped to the whole origin, not to `/v0`.
 *
 * The document at `/` carries this actor's projection (§19), and a cookie scoped
 * to `/v0` is never sent with that request — so the server could not tell who
 * was asking for the page it was about to personalise. The narrow path that
 * matters is the REFRESH cookie's: that one is the long-lived credential, and it
 * still travels only to `/v0/auth/refresh`.
 *
 * The cost is that the access token now accompanies static asset requests too.
 * It stays HttpOnly, Secure and same-origin, so this widens where it appears in
 * request logs, not who can read it.
 */
const ACCESS_PATH = '/';

export interface AuthConfig {
  db: DBAdapter;
  keys: Record<string, string>;
  activeKid: string;
  /** Argon2 cost; tests and local verification lower it deliberately. */
  argon: { memoryCost: number; timeCost: number };
  /**
   * Accounts that hold the reserved `platform` role, from server configuration
   * (`PLATFORM_ADMINS`) — never from a row and never from a request. Evaluated
   * at every issuance, so removing an address revokes the claim on refresh.
   */
  platformAdmins?: ReadonlySet<string>;
  /** Injectable so a test can drive the window without sleeping. */
  rateLimit?: import('./rate-limit.ts').Guard;
}

const sha256 = async (value: string) =>
  Buffer.from(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value))).toString('hex');

const opaqueToken = () => Buffer.from(crypto.getRandomValues(new Uint8Array(32))).toString('base64url');

function cookie(name: string, value: string, opts: { path: string; maxAge: number; sameSite: 'Lax' | 'Strict' }) {
  return `${name}=${value}; HttpOnly; Secure; SameSite=${opts.sameSite}; Path=${opts.path}; Max-Age=${opts.maxAge}`;
}

const clear = (name: string, path: string) =>
  `${name}=; HttpOnly; Secure; SameSite=Lax; Path=${path}; Max-Age=0`;

export function readCookie(request: Request, name: string): string | undefined {
  const header = request.headers.get('cookie');
  if (!header) return undefined;
  for (const part of header.split(';')) {
    const [k, ...rest] = part.trim().split('=');
    if (k === name) return rest.join('=');
  }
  return undefined;
}

async function issue(config: AuthConfig, user: Row, familyId: string): Promise<Headers> {
  // What the row confers, with reserved names stripped, plus the configured
  // cross-tenant claim if this account is one of the platform accounts.
  const roles = rolesFor(user, config.platformAdmins);

  /**
   * The org may narrow the access-token lifetime (P-120).
   *
   * Read at ISSUANCE, which is what makes §15's promise true: a token already
   * minted carries its own `exp` and is unaffected, so a change applies to
   * newly issued tokens only. Clamped on the way out as well as on the way in —
   * a value written before the bounds existed, or straight into the database,
   * must not become an eight-hour session because nobody re-validated it.
   */
  const org = await config.db.systemFind(ORG, { id: String(user.orgId) });
  const requested = org?.accessTtlSeconds == null ? undefined : Number(org.accessTtlSeconds);
  const accessTtl = requested === undefined || !Number.isInteger(requested)
    ? ACCESS_TTL_SECONDS
    : Math.min(Math.max(requested, ORG_ACCESS_TTL_MIN), ORG_ACCESS_TTL_MAX);

  const access = await signJwt(
    { sub: String(user.id), org: String(user.orgId), roles, ver: Number(user.tokenVersion ?? 0) },
    config.keys[config.activeKid]!,
    accessTtl,
    config.activeKid,
  );

  const refresh = opaqueToken();
  await config.db.systemCreate(SESSION, {
    orgId: String(user.orgId),
    userId: String(user.id),
    familyId,
    tokenHash: await sha256(refresh),   // stored hashed; high entropy, so SHA-256 not Argon2
    expiresAt: new Date(Date.now() + REFRESH_TTL_SECONDS * 1000).toISOString(),
    revoked: false,
  });

  const headers = new Headers();
  headers.append('set-cookie', cookie(ACCESS_COOKIE, access, { path: ACCESS_PATH, maxAge: accessTtl, sameSite: 'Lax' }));
  headers.append('set-cookie', cookie(REFRESH_COOKIE, refresh, { path: REFRESH_PATH, maxAge: REFRESH_TTL_SECONDS, sameSite: 'Strict' }));
  return headers;
}

const withCookies = (body: unknown, headers: Headers, status = 200) => {
  headers.set('content-type', 'application/json');
  return new Response(JSON.stringify(body), { status, headers });
};

/** Revokes every session in a family — used on reuse detection and logout. */
async function revokeFamily(db: DBAdapter, familyId: string) {
  let session: Row | undefined;
  // systemFind returns one row; loop until no live session remains in the family.
  while ((session = await db.systemFind(SESSION, { familyId, revoked: false }))) {
    await db.systemUpdate(SESSION, String(session.id), { revoked: true });
  }
}


/**
 * Cut a user off **now**: every refresh family revoked, and `tokenVersion`
 * bumped so outstanding ACCESS tokens stop verifying (AUD-011).
 *
 * Revoking the families alone is not enough, and believing otherwise was a real
 * bug: an access token is self-contained and good for its full 15 minutes, so a
 * demoted admin kept administering — including re-promoting themselves — until
 * it expired. Caught 2026-09-14 by probing exactly that. The `ver` claim is
 * what closes the window, and `resolveActorFromRequest` is where it is checked.
 */
async function revokeUser(db: DBAdapter, userId: string) {
  for (const session of await db.systemList(SESSION, { userId })) {
    if (session.revoked === true || session.revoked === 1) continue;
    await db.systemUpdate(SESSION, String(session.id), { revoked: true });
  }
  const user = await db.systemFind(USER, { id: userId });
  if (user) {
    await db.systemUpdate(USER, userId, { tokenVersion: Number(user.tokenVersion ?? 0) + 1 });
  }
}

/** A join code is a shared secret, so it is sized like one. */
const joinCode = () => Buffer.from(crypto.getRandomValues(new Uint8Array(24))).toString('base64url');

/** The role a registration is granted. Never read from the request. */
const FOUNDER_ROLE = 'admin';
const JOINER_ROLE = 'staff';

/**
 * Every org exists as a row before anyone can be in it. Called at boot, so a
 * fresh database has somewhere for the first registration to land, and an
 * existing one keeps working: orgIds already present on users are adopted.
 */
export async function ensureOrgs(db: DBAdapter): Promise<Row> {
  let fallback = await db.systemFind(ORG, { isDefault: true });
  if (!fallback) {
    fallback = await db.systemCreate(ORG, {
      name: 'Default', joinCode: joinCode(), isDefault: true,
    });
  }

  // Adopt orgIds that predate this table so existing users are not orphaned.
  for (const orgId of await distinctUserOrgs(db)) {
    if (await db.systemFind(ORG, { id: orgId })) continue;
    await db.systemCreate(ORG, { id: orgId, name: orgId, joinCode: joinCode(), isDefault: false });
  }
  return fallback;
}

/** Distinct orgIds already carried by user rows. */
async function distinctUserOrgs(db: DBAdapter): Promise<string[]> {
  const seen = new Set<string>();
  for (const row of await db.systemList(USER)) seen.add(String(row.orgId));
  return [...seen];
}

export function createAuthRoutes(config: AuthConfig) {
  /**
   * Orgs, invites and members live in `admin.ts`. They are the same hand-routed
   * surface — not generic dispatch, by design (§15) — but they are a different
   * concern from issuing and refreshing a session, and keeping them here would
   * have turned this function into the `if` chain the handoff warned about.
   */
  const admin = createAdminRoutes({
    db: config.db,
    resolveActor: (request) => resolveActorFromRequest(request, config),
    revokeUser: (userId) => revokeUser(config.db, userId),
  });

  /**
   * One limiter for the life of the server, shared by every credential route
   * (§22, P-111). In process: nothing here runs more than one.
   */
  const guard = config.rateLimit ?? createGuard();

  return async (request: Request, url: URL, client?: Client): Promise<Response | undefined> => {
    const route = url.pathname.replace(/^\/v0\/auth\/?/, '');
    const body = request.method === 'POST' && request.headers.get('content-type')?.includes('json')
      ? ((await request.json().catch(() => ({}))) as Row)
      : {};

    const administered = await admin(route, request, body);
    if (administered) return administered;

    if ((route === 'register' || route === 'participant') && request.method === 'POST') {
      const email = String(body.email ?? '').trim().toLowerCase();
      const password = String(body.password ?? '');
      // Counted on every attempt, success included: the threat here is the
      // VOLUME of accounts created, so a success is exactly what needs bounding.
      const limited = guard.check('register', client, email);
      if (limited) return limited;
      guard.attempt('register', client, email);
      if (!email || password.length < 8) {
        return json({ error: 'invalid_registration', detail: 'email and an 8+ character password are required' }, 400);
      }
      if (await config.db.systemFind(USER, { email })) {
        return json({ error: 'email_taken' }, 409);
      }
      // Identity is assigned by the server. `orgId` and `roles` in the request
      // body are ignored: accepting them let anyone mint an admin inside any
      // tenant, which is the whole of the org-scope model (AUD-001).
      /**
       * Three ways in, and they decide both the org and the role (WP-05 P-102):
       *
       *  - an **invite token** names the org AND the role an admin chose;
       *  - a **join code** names the org, and the role follows the founder rule;
       *  - neither, and the default org takes them.
       */
      /**
       * Present-but-blank is refused, not treated as absent.
       *
       * `joinCode: ""` used to fall through to the default org, which is the
       * silent mis-tenanting the paragraph above forbids — and an empty string
       * is exactly what an untouched or truncated form field sends. The KEY
       * being present means the caller meant to join a particular org, so a
       * blank value is a broken request rather than a decision to take the
       * default. Found 2026-09-14 by a probe that sent one by accident.
       */
      for (const key of ['joinCode', 'inviteToken'] as const) {
        if (key in body && String(body[key] ?? '').trim() === '') {
          return json({ error: `invalid_${key === 'joinCode' ? 'join_code' : 'invite'}`,
            detail: `"${key}" was sent empty; omit it to join the default org` }, 400);
        }
      }

      const presentedInvite = String(body.inviteToken ?? '').trim();
      const presented = String(body.joinCode ?? '').trim();
      let org: Row | undefined;
      let invited: Row | undefined;

      if (presentedInvite) {
        const inviteLimited = guard.check('invite', client, email);
        if (inviteLimited) return inviteLimited;
        invited = await config.db.systemFind(INVITE, { tokenHash: await sha256(presentedInvite) });
        // Unknown, spent and expired are one answer: an invite token is a bearer
        // credential, and distinguishing them tells a holder which guess was warm.
        const spent = invited?.acceptedAt != null;
        const expired = invited ? new Date(String(invited.expiresAt)) < new Date() : false;
        if (!invited || spent || expired) {
          guard.fail('invite', client, email);
          return json({ error: 'invalid_invite' }, 400);
        }
        // The invite was issued to an address; it is not transferable.
        if (String(invited.email).toLowerCase() !== email) {
          guard.fail('invite', client, email);
          return json({ error: 'invalid_invite' }, 400);
        }
        org = await config.db.systemFind(ORG, { id: String(invited.orgId) });
        if (!org) return json({ error: 'invalid_invite' }, 400);
      } else if (presented) {
        org = await config.db.systemFind(ORG, { joinCode: presented });
        // A wrong code is an error, never a silent fall back to the default org:
        // landing in the wrong tenant must not be something a typo can do.
        if (!org) return json({ error: 'invalid_join_code' }, 400);
      } else {
        org = await ensureOrgs(config.db);
      }

      // The first account in an org founds it and administers it; everyone who
      // joins afterwards holds the code, which is authorisation to be a member
      // and not to run the place. An invite overrides that with what the
      // inviting admin chose — still re-checked, because a stored role is not
      // a trusted role (Q-121).
      const existing = await config.db.systemList(USER, { orgId: String(org.id) });
      // An invite names its own role. Otherwise the founder rule applies, and
      // after that the org's own `defaultRole` — which is what P-120 lets an
      // administrator change without touching code.
      //
      // `POST /v0/auth/participant` is the participant registration path
      // (WB-001): the role is `customer`, SERVER-chosen and never from the
      // request, so a visitor cannot ask to be staff (Q-121). A `customer`
      // reads only the rows it owns; it is not a member of the workshop's
      // operations, which is what the founder/joiner rule would otherwise make
      // it.
      const orgDefaultRole = String(org.defaultRole ?? JOINER_ROLE);
      const roles = route === 'participant'
        ? 'customer'
        : invited
          ? storedRoles(invited.roles).join(',') || JOINER_ROLE
          : existing.length === 0
            ? FOUNDER_ROLE
            : (ASSIGNABLE_ROLES as readonly string[]).includes(orgDefaultRole) ? orgDefaultRole : JOINER_ROLE;
      // The constant above cannot be a reserved role today. The check is here so
      // that the next path to write roles cannot be, either (Q-121).
      assertAssignable([roles], 'register');

      const user = await config.db.systemCreate(USER, {
        orgId: String(org.id),
        email,
        passwordHash: await Bun.password.hash(password, { algorithm: 'argon2id', ...config.argon }),
        roles,
        tokenVersion: 0,
      });
      // One-time: marked spent only after the account exists, so a failed
      // creation does not burn the invite.
      if (invited) {
        await config.db.systemUpdate(INVITE, String(invited.id), { acceptedAt: new Date().toISOString() });
      }
      const headers = await issue(config, user, crypto.randomUUID());
      return withCookies({ data: { id: user.id, email, orgId: user.orgId, roles } }, headers, 201);
    }

    if (route === 'login' && request.method === 'POST') {
      const email = String(body.email ?? '').trim().toLowerCase();
      const limited = guard.check('login', client, email);
      if (limited) return limited;
      const user = await config.db.systemFind(USER, { email });
      // Enumeration-safe: same response and comparable work either way.
      const hash = String(user?.passwordHash ?? '$argon2id$v=19$m=8,t=1,p=1$AAAAAAAAAAA$AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA');
      const ok = await Bun.password.verify(String(body.password ?? ''), hash).catch(() => false);
      if (!user || !ok) {
        // Only a FAILED attempt costs budget. A guess that succeeds is not a
        // guess, and counting every sign-in would throttle honest traffic.
        guard.fail('login', client, email);
        return json({ error: 'invalid_credentials' }, 401);
      }
      // A deactivated member's row still verifies — it is a tombstone, not a
      // deletion — so the refusal is here. Same body as a bad password: whether
      // an address is deactivated or simply wrong is not a caller's business.
      if (user.deactivated === true || user.deactivated === 1) {
        guard.fail('login', client, email);
        return json({ error: 'invalid_credentials' }, 401);
      }
      guard.succeed('login', email);
      const headers = await issue(config, user, crypto.randomUUID());
      return withCookies({ data: { id: user.id, email, orgId: user.orgId } }, headers);
    }

    if (route === 'refresh' && request.method === 'POST') {
      const limited = guard.check('refresh', client);
      if (limited) return limited;
      const presented = readCookie(request, REFRESH_COOKIE);
      if (!presented) { guard.fail('refresh', client); return json({ error: 'no_refresh_token' }, 401); }
      const tokenHash = await sha256(presented);
      const session = await config.db.systemFind(SESSION, { tokenHash });
      if (!session) { guard.fail('refresh', client); return json({ error: 'invalid_refresh_token' }, 401); }

      // Reuse of a spent or revoked token revokes the whole family.
      if (session.revoked || session.usedAt) {
        await revokeFamily(config.db, String(session.familyId));
        return json({ error: 'refresh_reuse_detected', detail: 'session family revoked' }, 401);
      }
      if (new Date(String(session.expiresAt)) < new Date()) return json({ error: 'refresh_expired' }, 401);

      await config.db.systemUpdate(SESSION, String(session.id), { usedAt: new Date().toISOString(), revoked: true });
      const user = await config.db.systemFind(USER, { id: session.userId });
      if (!user) return json({ error: 'invalid_refresh_token' }, 401);
      const headers = await issue(config, user, String(session.familyId));
      return withCookies({ data: { rotated: true } }, headers);
    }

    if (route === 'logout' && request.method === 'POST') {
      const presented = readCookie(request, REFRESH_COOKIE);
      if (presented) {
        const session = await config.db.systemFind(SESSION, { tokenHash: await sha256(presented) });
        if (session) await revokeFamily(config.db, String(session.familyId));
      }
      const headers = new Headers();
      headers.append('set-cookie', clear(ACCESS_COOKIE, ACCESS_PATH));
      headers.append('set-cookie', clear(REFRESH_COOKIE, REFRESH_PATH));
      return withCookies({ data: { loggedOut: true } }, headers);
    }

    if (route === 'me' && request.method === 'GET') {
      // A session probe, not a protected resource: "nobody" is a valid answer.
      // Returning 401 here made every anonymous page load log a console error,
      // which would mask real ones.
      const actor = await resolveActorFromRequest(request, config);
      return json({ data: actor ?? null });
    }

    return undefined;
  };
}

/**
 * The actor comes from a verified access token — never from a fixed development
 * identity — and the token is then checked against the row it names (AUD-011).
 *
 * The signature proves the claims are ours; it says nothing about whether they
 * are still TRUE. `ver` is the bridge: every credential-affecting change bumps
 * `_user.tokenVersion`, so a token minted before it no longer matches and is
 * refused on the next request rather than at its own expiry. That is what makes
 * a demotion, a deactivation and a password change take effect immediately,
 * and without it a 15-minute window let a demoted admin keep administering.
 *
 * The cost is one `_user` read per authenticated request, which §15 named as
 * the trade when it introduced the claim. It is a primary-key lookup on a table
 * the request is already talking to; if it ever matters, the fix is a short-TTL
 * cache keyed by `(sub, ver)`, not dropping the check.
 */
export async function resolveActorFromRequest(request: Request, config: AuthConfig): Promise<Actor | undefined> {
  const token = readCookie(request, ACCESS_COOKIE);
  if (!token) return undefined;
  const result = await verifyJwt(token, config.keys);
  if (!result.ok) return undefined;

  const user = await config.db.systemFind(USER, { id: result.claims.sub });
  // A token for a user who no longer exists, has been deactivated, or whose
  // version has moved on is not an identity any more.
  if (!user) return undefined;
  if (user.deactivated === true || user.deactivated === 1) return undefined;
  if (Number(user.tokenVersion ?? 0) !== Number(result.claims.ver ?? 0)) return undefined;

  return { id: result.claims.sub, roles: result.claims.roles, orgId: result.claims.org };
}
