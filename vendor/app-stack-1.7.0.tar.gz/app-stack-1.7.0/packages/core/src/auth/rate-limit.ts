/**
 * Rate limiting on the credential routes (§22; WP-05 P-111).
 *
 * A token bucket per key, in process. `_ratelimit` rows would be needed only if
 * several server processes had to share a budget, and nothing here runs more
 * than one — recording that so the next person does not assume a distributed
 * limiter was intended and missing.
 *
 * **Failures are what is counted on the credential routes, not attempts.** The
 * threat on `login` and `refresh` is guessing, and a guess that succeeds is not
 * a guess. Counting every attempt would have throttled the browser gate, which
 * signs in about thirty times in a run from one address and is right to — and a
 * limiter that legitimate traffic trips is a limiter someone turns off.
 *
 * `register` is the exception and counts every attempt: there the threat is the
 * volume of accounts created, so a success is exactly what needs bounding
 * (Hardening v1 made the same observation about join codes — "guessing is not
 * the threat; volume of account creation is").
 */
import { json } from '../server.ts';
import {
  RATE_LIMIT_PER_EMAIL, RATE_LIMIT_PER_IP, RATE_LIMIT_REGISTER_PER_IP, RATE_LIMIT_WINDOW_SECONDS,
} from '../limits.ts';

interface Bucket { tokens: number; resetAt: number }

/**
 * Bounded on purpose. An unbounded map keyed by client address is a memory
 * exhaustion primitive handed to exactly the caller this file exists to limit:
 * a spray across a million addresses would otherwise cost more than the
 * requests it refuses. Expired buckets are swept on write, and if that is not
 * enough the oldest are dropped — dropping a bucket only ever forgives, never
 * punishes, so the failure mode is a limiter that is briefly lenient rather
 * than a server that falls over.
 */
const MAX_BUCKETS = 10_000;

export class RateLimiter {
  #buckets = new Map<string, Bucket>();
  #now: () => number;

  /** `now` is injectable so a test can move time without sleeping. */
  constructor(now: () => number = Date.now) {
    this.#now = now;
  }

  /**
   * Evict, and only when over the cap.
   *
   * Sweeping on every write made the limiter O(n) per request once the map was
   * full, so the caller this file exists to throttle would have been paying us
   * to walk ten thousand entries per attempt — a limiter that becomes the
   * amplifier. It now runs only when the cap is exceeded and drops to a
   * low-water mark, so the walk is amortised across the inserts that follow.
   *
   * Expired buckets go first; if that is not enough, the oldest do. Dropping a
   * bucket only ever forgives, so the failure mode is a briefly lenient
   * limiter, never a wrongly punished caller.
   */
  #evict(now: number) {
    for (const [key, bucket] of this.#buckets) {
      if (bucket.resetAt <= now) this.#buckets.delete(key);
    }
    if (this.#buckets.size <= MAX_BUCKETS) return;
    const target = Math.floor(MAX_BUCKETS * 0.9);
    for (const key of this.#buckets.keys()) {
      if (this.#buckets.size <= target) break;
      this.#buckets.delete(key);
    }
  }

  /** Seconds until this key's window resets, or 0 if it has budget. */
  retryAfter(key: string, limit: number): number {
    const now = this.#now();
    const bucket = this.#buckets.get(key);
    if (!bucket || bucket.resetAt <= now) return 0;
    return bucket.tokens < limit ? 0 : Math.ceil((bucket.resetAt - now) / 1000);
  }

  /** True when the key is over its limit. Does not consume. */
  exceeded(key: string, limit: number): boolean {
    return this.retryAfter(key, limit) > 0;
  }

  /** Record one event against a key. */
  consume(key: string): void {
    const now = this.#now();
    const bucket = this.#buckets.get(key);
    if (!bucket || bucket.resetAt <= now) {
      this.#buckets.set(key, { tokens: 1, resetAt: now + RATE_LIMIT_WINDOW_SECONDS * 1000 });
    } else {
      bucket.tokens++;
    }
    // After the insert, so the cap is a cap rather than a cap plus one.
    if (this.#buckets.size > MAX_BUCKETS) this.#evict(now);
  }

  /** Forget a key — used when a credential attempt succeeds. */
  clear(key: string): void {
    this.#buckets.delete(key);
  }

  /** Test seam only. */
  get size(): number { return this.#buckets.size; }
}

/**
 * What a request is limited BY.
 *
 * The address comes from the socket, never from `X-Forwarded-For`: that header
 * is caller-supplied, so trusting it would let anyone bypass the limiter by
 * setting it — turning the defence into a decoration. A deployment behind a
 * proxy therefore limits by the proxy's address until it is given a trusted-proxy
 * configuration, which is a deliberate gap named in the backlog rather than a
 * header read on faith.
 */
export interface Client { address: string }

export const ipKey = (route: string, client: Client | undefined) =>
  `${route}:ip:${client?.address ?? 'unknown'}`;
export const emailKey = (route: string, email: string) =>
  `${route}:email:${email.trim().toLowerCase()}`;

/** The 429, with the header a well-behaved client honours. */
export const tooManyRequests = (retryAfterSeconds: number) =>
  new Response(
    JSON.stringify({ error: 'rate_limited', detail: 'too many attempts; try again shortly' }),
    {
      status: 429,
      headers: { 'content-type': 'application/json', 'retry-after': String(Math.max(1, retryAfterSeconds)) },
    },
  );

export interface Guard {
  /** Refuse when either key is over budget; returns the response to send. */
  check(route: string, client: Client | undefined, email?: string): Response | undefined;
  /** Count a failed attempt against both keys. */
  fail(route: string, client: Client | undefined, email?: string): void;
  /** Count an attempt regardless of outcome — `register`'s shape. */
  attempt(route: string, client: Client | undefined, email?: string): void;
  /** A credential attempt succeeded: forget the email's failures. */
  succeed(route: string, email?: string): void;
}

export function createGuard(limiter = new RateLimiter()): Guard {
  const limitFor = (route: string) => (route === 'register' ? RATE_LIMIT_REGISTER_PER_IP : RATE_LIMIT_PER_IP);

  return {
    check(route, client, email) {
      const ip = limiter.retryAfter(ipKey(route, client), limitFor(route));
      if (ip > 0) return tooManyRequests(ip);
      if (email) {
        const byEmail = limiter.retryAfter(emailKey(route, email), RATE_LIMIT_PER_EMAIL);
        if (byEmail > 0) return tooManyRequests(byEmail);
      }
      return undefined;
    },
    fail(route, client, email) {
      limiter.consume(ipKey(route, client));
      if (email) limiter.consume(emailKey(route, email));
    },
    attempt(route, client, email) {
      limiter.consume(ipKey(route, client));
      if (email) limiter.consume(emailKey(route, email));
    },
    succeed(route, email) {
      if (email) limiter.clear(emailKey(route, email));
    },
  };
}
