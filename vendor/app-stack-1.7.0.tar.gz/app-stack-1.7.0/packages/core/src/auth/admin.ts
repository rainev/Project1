/**
 * Tenancy and identity administration (ARCHITECTURE §15; WP-05 phase 1).
 *
 * Orgs, invites and members. These are **not** generic dispatch and deliberately
 * so: they write the framework's own system models, where `orgId` and `roles`
 * are the things being decided rather than things a gate can be handed. Generic
 * dispatch refuses a `_`-prefixed model precisely so this surface cannot be
 * reached sideways.
 *
 * Every route here re-derives the actor from the access cookie and decides for
 * itself. There is no ambient "admin" — §22's rule that identity is
 * server-assigned means an admin of org A administers org A and nothing else,
 * and the only identity that crosses tenants is the reserved `platform` role,
 * which comes from server configuration and can never be granted here.
 */
import type { DBAdapter, Row } from '../db/adapter.ts';
import type { Actor } from '../engine/types.ts';
import { json } from '../server.ts';
import { assertAssignable, ASSIGNABLE_ROLES, isPlatform, storedRoles } from './roles.ts';
import { INVITE, ORG, SESSION, USER } from './system-models.ts';

/** A join code is a shared secret, so it is sized like one. */
export const joinCode = () => Buffer.from(crypto.getRandomValues(new Uint8Array(24))).toString('base64url');
/** Same shape and the same reasoning for an invite token. */
export const inviteToken = () => Buffer.from(crypto.getRandomValues(new Uint8Array(32))).toString('base64url');

export const sha256 = async (value: string) =>
  Buffer.from(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value))).toString('hex');

/** How long an unredeemed invite stays good. */
export const INVITE_TTL_SECONDS = 7 * 24 * 60 * 60;

/**
 * Bounds on a per-org access-token lifetime (P-120).
 *
 * A safety rail, not a tuning knob, which is why it is here and not in
 * `limits.ts` with the deployment's own numbers: an org administrator is
 * configuring their tenant, and neither "one second" nor "one year" is a
 * sensible thing for them to be able to choose. A value outside these is
 * refused rather than silently clamped — an admin who asked for a day should be
 * told no, not quietly given an hour.
 */
export const ORG_ACCESS_TTL_MIN = 60;
export const ORG_ACCESS_TTL_MAX = 60 * 60;

/** The settings an org exposes. Assembled by allowlist, like `memberView`. */
export const orgView = (row: Row) => ({
  id: String(row.id),
  name: String(row.name),
  displayName: String(row.displayName ?? row.name),
  defaultRole: String(row.defaultRole ?? 'staff'),
  accessTtlSeconds: row.accessTtlSeconds == null ? null : Number(row.accessTtlSeconds),
  isDefault: row.isDefault === true || row.isDefault === 1,
});

const forbidden = () => json({ error: 'forbidden' }, 403);
const unauthenticated = () => json({ error: 'unauthenticated' }, 401);

/** Admin of the org they are acting on. A platform actor is admin everywhere. */
const administers = (actor: Actor, orgId: string) =>
  isPlatform(actor) || (actor.orgId === orgId && actor.roles.includes('admin'));

/**
 * The two refusals a member route can give, kept distinct because §11 already
 * decided what each one means: a row outside the actor's scope is
 * **not_found** (its existence is not theirs to learn), and a row inside it
 * that they may not act on is **forbidden**.
 *
 * Collapsing both into 404 hid a real answer from an author debugging their own
 * tenant — staff acting on a colleague got "no such member" when the truth was
 * "you are not an admin". It leaks nothing to say so: they already know their
 * own org exists, and they still cannot enumerate it.
 */
function refuseMember(actor: Actor, target: Row | undefined): Response | undefined {
  const sameTenant = target && (isPlatform(actor) || String(target.orgId) === actor.orgId);
  if (!sameTenant) return json({ error: 'not_found' }, 404);
  if (!administers(actor, String(target!.orgId))) return forbidden();
  return undefined;
}

/**
 * What a member looks like on the wire. Assembled by allowlist, not by deleting
 * from the row: `passwordHash` must never be one forgotten `delete` away from a
 * response (§19's posture, applied to a system model).
 */
const memberView = (row: Row) => ({
  id: String(row.id),
  email: String(row.email),
  roles: storedRoles(row.roles),
  deactivated: row.deactivated === true || row.deactivated === 1,
  createdAt: row.createdAt ?? null,
});

export interface AdminDeps {
  db: DBAdapter;
  resolveActor: (request: Request) => Promise<Actor | undefined>;
  /** Revoke every live session family for a user — shared with logout. */
  revokeUser: (userId: string) => Promise<void>;
}

/**
 * Routes under `/v0/auth/`, matched on the path remainder. Returns `undefined`
 * when nothing here claims the route, so the caller can keep looking.
 */
export function createAdminRoutes(deps: AdminDeps) {
  const { db } = deps;

  return async function handle(
    route: string, request: Request, body: Row,
  ): Promise<Response | undefined> {
    const segments = route.split('/').filter(Boolean);
    const method = request.method;

    // ---- orgs (P-101) -----------------------------------------------------

    if (segments[0] === 'orgs' && segments.length === 1 && method === 'POST') {
      /**
       * Creating an org is a platform operation — with one bootstrap exception,
       * because a brand-new instance has no platform actor and no admin, and
       * something has to be able to make the first tenant. "Empty" means no
       * users at all, which stops being true the moment anyone registers.
       */
      const actor = await deps.resolveActor(request);
      const empty = (await db.systemList(USER)).length === 0;
      if (!empty) {
        if (!actor) return unauthenticated();
        if (!isPlatform(actor)) return forbidden();
      }

      const name = String(body.name ?? '').trim();
      if (!name) return json({ error: 'invalid_org', detail: 'name is required' }, 400);
      if (await db.systemFind(ORG, { name })) return json({ error: 'org_name_taken' }, 409);

      const code = joinCode();
      const org = await db.systemCreate(ORG, { name, joinCode: code, isDefault: false });
      // The code is shown ONCE, here. It is a secret; the org row keeps it so it
      // can be checked, and no read route returns it again except a rotation.
      return json({ data: { id: String(org.id), name, joinCode: code } }, 201);
    }

    if (segments[0] === 'orgs' && segments[2] === 'rotate-join-code' && method === 'POST') {
      const actor = await deps.resolveActor(request);
      if (!actor) return unauthenticated();
      const orgId = String(segments[1]);
      // An org admin may rotate their OWN code — that is the point of it being
      // rotatable — and a platform actor may rotate anyone's.
      if (!administers(actor, orgId)) return forbidden();
      const org = await db.systemFind(ORG, { id: orgId });
      if (!org) return json({ error: 'not_found' }, 404);

      const code = joinCode();
      await db.systemUpdate(ORG, String(org.id), { joinCode: code });
      return json({ data: { id: orgId, joinCode: code } });
    }

    if (segments[0] === 'orgs' && segments.length === 2 && method === 'GET') {
      const actor = await deps.resolveActor(request);
      if (!actor) return unauthenticated();
      const orgId = String(segments[1]);
      if (!administers(actor, orgId)) return forbidden();
      const org = await db.systemFind(ORG, { id: orgId });
      if (!org) return json({ error: 'not_found' }, 404);
      // Never the join code: it is a secret, and a read route that returned it
      // would make every settings page a place to harvest one.
      return json({ data: orgView(org) });
    }

    if (segments[0] === 'orgs' && segments[2] === 'settings' && method === 'POST') {
      const actor = await deps.resolveActor(request);
      if (!actor) return unauthenticated();
      const orgId = String(segments[1]);
      if (!administers(actor, orgId)) return forbidden();
      const org = await db.systemFind(ORG, { id: orgId });
      if (!org) return json({ error: 'not_found' }, 404);

      const patch: Row = {};
      if ('displayName' in body) {
        const displayName = String(body.displayName ?? '').trim();
        if (!displayName) return json({ error: 'invalid_settings', detail: 'displayName cannot be empty' }, 400);
        patch.displayName = displayName;
      }
      if ('defaultRole' in body) {
        const defaultRole = String(body.defaultRole ?? '').trim();
        if (!(ASSIGNABLE_ROLES as readonly string[]).includes(defaultRole)) {
          return json({ error: 'invalid_settings', detail: `defaultRole must be one of ${ASSIGNABLE_ROLES.join(', ')}` }, 400);
        }
        // The same check every other role-writing path makes: a reserved role
        // must not become reachable by being stored somewhere and read back.
        assertAssignable([defaultRole], 'org defaultRole');
        patch.defaultRole = defaultRole;
      }
      if ('accessTtlSeconds' in body) {
        const raw = body.accessTtlSeconds;
        if (raw === null) {
          patch.accessTtlSeconds = null;   // fall back to the server's default
        } else {
          const ttl = Number(raw);
          if (!Number.isInteger(ttl) || ttl < ORG_ACCESS_TTL_MIN || ttl > ORG_ACCESS_TTL_MAX) {
            return json({
              error: 'invalid_settings',
              detail: `accessTtlSeconds must be an integer between ${ORG_ACCESS_TTL_MIN} and ${ORG_ACCESS_TTL_MAX}, or null`,
            }, 400);
          }
          patch.accessTtlSeconds = ttl;
        }
      }
      if (Object.keys(patch).length === 0) {
        return json({ error: 'invalid_settings', detail: 'nothing to change' }, 400);
      }

      await db.systemUpdate(ORG, orgId, patch);
      const updated = await db.systemFind(ORG, { id: orgId });
      return json({ data: orgView(updated!) });
    }

    // ---- invites (P-102) --------------------------------------------------

    if (segments[0] === 'invite' && segments.length === 1 && method === 'POST') {
      const actor = await deps.resolveActor(request);
      if (!actor) return unauthenticated();
      if (!actor.roles.includes('admin') && !isPlatform(actor)) return forbidden();

      const email = String(body.email ?? '').trim().toLowerCase();
      if (!email) return json({ error: 'invalid_invite', detail: 'email is required' }, 400);
      const roles = String(body.roles ?? 'staff').trim();
      if (!(ASSIGNABLE_ROLES as readonly string[]).includes(roles)) {
        return json({ error: 'invalid_invite', detail: `roles must be one of ${ASSIGNABLE_ROLES.join(', ')}` }, 400);
      }
      // Belt and braces: the enum above already excludes it, and this is the
      // check that survives someone widening the enum (Q-121).
      assertAssignable([roles], 'invite');

      // An invite lands in the INVITER's org. Accepting an org id from the body
      // would let an admin of one tenant mint members in another.
      const orgId = actor.orgId;
      if (await db.systemFind(USER, { email })) return json({ error: 'email_taken' }, 409);

      const token = inviteToken();
      await db.systemCreate(INVITE, {
        orgId,
        email,
        roles,
        tokenHash: await sha256(token),
        expiresAt: new Date(Date.now() + INVITE_TTL_SECONDS * 1000).toISOString(),
        invitedBy: actor.id,
      });
      // Shown once, like a join code.
      return json({ data: { email, roles, token, expiresInSeconds: INVITE_TTL_SECONDS } }, 201);
    }

    // ---- members (P-103) --------------------------------------------------

    if (segments[0] === 'members' && segments.length === 1 && method === 'GET') {
      const actor = await deps.resolveActor(request);
      if (!actor) return unauthenticated();
      if (!actor.roles.includes('admin') && !isPlatform(actor)) return forbidden();
      const rows = await db.systemList(USER, { orgId: actor.orgId });
      return json({ data: rows.map(memberView) });
    }

    if (segments[0] === 'members' && segments[2] === 'role' && method === 'POST') {
      const actor = await deps.resolveActor(request);
      if (!actor) return unauthenticated();
      const target = await db.systemFind(USER, { id: String(segments[1]) });
      const refusal = refuseMember(actor, target);
      if (refusal) return refusal;
      const member = target!;

      const roles = String(body.roles ?? '').trim();
      if (!(ASSIGNABLE_ROLES as readonly string[]).includes(roles)) {
        return json({ error: 'invalid_role', detail: `roles must be one of ${ASSIGNABLE_ROLES.join(', ')}` }, 400);
      }
      assertAssignable([roles], 'member role');

      /**
       * An org must not be able to lock itself out. Demoting the last admin
       * leaves a tenant nobody can administer, and the only recovery is a
       * platform actor or the database — so it is refused here.
       */
      if (storedRoles(member.roles).includes('admin') && roles !== 'admin') {
        const admins = (await db.systemList(USER, { orgId: member.orgId }))
          .filter((u) => storedRoles(u.roles).includes('admin') && u.deactivated !== true && u.deactivated !== 1);
        if (admins.length <= 1) {
          return json({ error: 'last_admin', detail: 'an org must keep at least one active admin' }, 409);
        }
      }

      await db.systemUpdate(USER, String(member.id), { roles });
      /**
       * A role change must reach the actor's live tokens. The access token
       * carries `roles`, so revoking the session families forces a fresh login
       * and a fresh claim — otherwise a demoted admin keeps administering until
       * their access token expires.
       */
      await deps.revokeUser(String(member.id));
      return json({ data: memberView({ ...member, roles }) });
    }

    if (segments[0] === 'members' && segments[2] === 'deactivate' && method === 'POST') {
      const actor = await deps.resolveActor(request);
      if (!actor) return unauthenticated();
      const target = await db.systemFind(USER, { id: String(segments[1]) });
      const refusal = refuseMember(actor, target);
      if (refusal) return refusal;
      const member = target!;
      if (String(member.id) === actor.id) {
        return json({ error: 'cannot_deactivate_self', detail: 'another admin must do this' }, 409);
      }
      const admins = (await db.systemList(USER, { orgId: member.orgId }))
        .filter((u) => storedRoles(u.roles).includes('admin') && u.deactivated !== true && u.deactivated !== 1);
      if (storedRoles(member.roles).includes('admin') && admins.length <= 1) {
        return json({ error: 'last_admin', detail: 'an org must keep at least one active admin' }, 409);
      }

      await db.systemUpdate(USER, String(member.id), { deactivated: true });
      // The row is a tombstone from here: login refuses it, and every live
      // session goes now rather than at its own expiry.
      await deps.revokeUser(String(member.id));
      return json({ data: memberView({ ...member, deactivated: true }) });
    }

    return undefined;
  };
}

export { SESSION };
