/** Shared error taxonomy, so every layer can classify its own failures. */

export class Denied extends Error {
  constructor(readonly reason: string) { super(reason); this.name = 'Denied'; }
}

export class NotFound extends Error {
  constructor(message = 'not_found') { super(message); this.name = 'NotFound'; }
}

/** The caller sent something the framework will not accept. Never a crash. */
export class BadRequest extends Error {
  constructor(message: string) { super(message); this.name = 'BadRequest'; }
}

export class ValidationFailure extends Error {
  constructor(readonly errors: { path: string; keyword: string; message: string }[]) {
    super('validation_failed');
    this.name = 'ValidationFailure';
  }
}

/**
 * Ciphertext that will not open. Either the row was tampered with, or the wrong
 * key is configured. Never silently serve a partial row: fail, and say where.
 */
export class DecryptionFailure extends Error {
  constructor(readonly model: string, readonly field: string, readonly rowId: string) {
    super(`could not decrypt ${model}.${field} for row ${rowId}`);
    this.name = 'DecryptionFailure';
  }
}
