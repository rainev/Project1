/**
 * What the browser is allowed to see (ARCHITECTURE §19).
 *
 * Built by WHITELIST, never by deleting keys: a new `x-` keyword added to a
 * model or view is invisible to the client by default, rather than leaking the
 * first time someone forgets to strip it.
 */
import type { ValidateFunction } from 'ajv';
import { ajv, ConfigError, crossRef, formatSchemaErrors, loadFamily } from './config/loader.ts';
import { allowsAction, canRead, canWrite, makeView } from './gates.ts';
import { compileExpression, type Compiled } from './expressions.ts';
import { isAnonymous } from './public.ts';
import { requirementSet } from './schema.ts';
import type { LanguageSet } from './routes.ts';
import { copyKey, localiseLinks, translate, type LocaleContext } from './locales.ts';
import { ConfigError, type Model } from './model.ts';
import type { Actor } from './engine/types.ts';

/**
 * Views are a config family, so they get a meta-schema like models do (§3.1).
 *
 * Until this existed, `loadViews` returned `any[]` and a misspelled component or
 * a malformed prop reached the browser and rendered as nothing — a family that
 * loads and is never validated (AUD-029 / DEF-010).
 */
/**
 * `layout` is the one prop with real structure, so it gets described here rather
 * than reaching a component unchecked. Everything else in `props` stays open —
 * a per-component prop schema is a larger question (§3.1's typed-runtime column).
 */
const LAYOUT_SCHEMA = {
  type: 'array',
  items: {
    oneOf: [
      {
        type: 'object', required: ['row'], additionalProperties: false,
        properties: { row: { type: 'array', items: { type: 'string' }, minItems: 1 } },
      },
      {
        type: 'object', required: ['group', 'fields'], additionalProperties: false,
        properties: {
          group: { type: 'string', minLength: 1 },
          fields: { type: 'array', items: { type: 'string' }, minItems: 1 },
        },
      },
      {
        type: 'object', required: ['field'], additionalProperties: false,
        properties: { field: { type: 'string', minLength: 1 } },
      },
    ],
  },
} as const;

/**
 * Conditional behaviour, declared. A rule that names a nonsense effect or omits
 * its condition would otherwise reach the browser and quietly do nothing, which
 * is worse than a field that never hides: the author believes it works.
 */
const RULES_SCHEMA = {
  type: 'array',
  items: {
    type: 'object',
    required: ['field', 'effect', 'when'],
    additionalProperties: false,
    properties: {
      // No dots: the name becomes `#/properties/<field>`, and a dotted name
      // would silently produce a pointer that resolves to nothing (AUD-054).
      field: { type: 'string', minLength: 1, pattern: '^[^.]+$' },
      effect: { enum: ['SHOW', 'HIDE', 'ENABLE', 'DISABLE'] },
      when: {
        type: 'object',
        required: ['field'],
        additionalProperties: false,
        minProperties: 2,
        properties: {
          field: { type: 'string', minLength: 1, pattern: '^[^.]+$' },
          equals: {},
          oneOf: { type: 'array', minItems: 1 },
          exists: { type: 'boolean' },
        },
      },
    },
  },
} as const;

/**
 * `when: { state: … }` — a PRESENTATION condition on a node or a row action
 * (AUD-068 / AUD-075).
 *
 * One keyword, reading one thing: a state the model already declares in
 * `x-states`. Deliberately not an expression. A second expression dialect in
 * view config is how the pre-reset codebase grew five unfinished families, and
 * the open decision on this handoff recommends against it.
 *
 * **It is not a gate.** A node `when` hides is still refused by the server when
 * the actor calls the API directly — `x-access`, `x-scope`, `x-field-access`
 * and a transition's own `access` are what decide that, and none of them
 * consult this. `when` decides what is worth showing; the gates decide what may
 * be done. Using it for authorization would be authorization written in the one
 * place §19 says never holds any.
 */
const WHEN_SCHEMA = {
  type: 'object',
  required: ['state'],
  additionalProperties: false,
  properties: {
    state: {
      oneOf: [
        { type: 'string', minLength: 1 },
        { type: 'array', minItems: 1, items: { type: 'string', minLength: 1 } },
      ],
    },
  },
} as const;

/** The states one `when` admits, always as a list. */
export function whenStates(when: any): string[] {
  const state = when?.state;
  return Array.isArray(state) ? state : typeof state === 'string' ? [state] : [];
}

const NODE_SCHEMA = {
  type: 'object',
  required: ['type'],
  additionalProperties: false,
  properties: {
    type: { type: 'string', minLength: 1 },
    /**
     * The model this NODE reads, when it is not the page's. A tile naming a
     * model the actor may not read is ABSENT from the projection — the same
     * rule pages already follow, applied one level down, which is what makes a
     * dashboard of tiles safe to assemble from config (§19, WP-03 Q-111).
     */
    requires: { type: 'string', minLength: 1 },
    /** A tile's own policy, same shape and same reasoning as the page's. */
    'x-access': {
      type: 'object',
      properties: { read: { type: 'string', minLength: 1 } },
      additionalProperties: false,
    },
    props: {
      type: 'object',
      properties: { layout: LAYOUT_SCHEMA, rules: RULES_SCHEMA },
    },
    children: { type: 'array', items: { $ref: '#/$defs/node' } },
    /**
     * Which of the parent's regions this child belongs to (WP-09 C-118).
     *
     * A page composed into columns needs to say which children are the aside
     * and which are the main column, and a node carrying only `type`, `props`
     * and `children` can only say "in order". Absent means the parent's default
     * region, so every view written before this is unchanged.
     *
     * It names a REGION the parent component offers, not a layout: the parent
     * decides what an `aside` is, and a component that offers no such region
     * ignores it.
     */
    slot: { type: 'string', minLength: 1 },
    /**
     * Render this node only while the record the page is about is in one of
     * these states (N-101). Evaluated SERVER-SIDE, so a node whose condition
     * does not hold never reaches the browser at all — the same "absent, not
     * hidden" property `requires` and `x-access` already give (§19).
     */
    when: WHEN_SCHEMA,
  },
} as const;

const VIEW_SCHEMA = {
  $defs: { node: NODE_SCHEMA },
  type: 'object',
  required: ['id', 'route', 'node'],
  additionalProperties: false,
  properties: {
    id: { type: 'string', minLength: 1 },
    route: { type: 'string', pattern: '^/' },
    title: { type: 'string' },
    /**
     * One sentence about the page, for `<meta name="description">` and a link
     * preview (WP-07 S-120). Only meaningful on an `anonymous: true` page —
     * nothing crawls a page it must sign in to reach — but not refused
     * elsewhere, because a description is also what a link preview inside the
     * application would use.
     */
    description: { type: 'string', maxLength: 300 },
    nav: { type: 'string' },
    navOrder: { type: 'integer' },
    /** The model this page reads. Absent means the page needs no model. */
    requires: { type: 'string', minLength: 1 },
    /** Served to a visitor with no session. Deny by default: absent means no. */
    anonymous: { type: 'boolean' },
    /**
     * The page's OWN policy, in the same JEXL every other gate speaks (§11).
     *
     * `requires` gates by a model's readability, which is the right answer when
     * a page is about a model and no answer at all when it is not — an
     * administration page reads `_user` and `_org`, which generic dispatch
     * refuses by design, so there is no model policy to consult. A declared
     * QUERY already solved this for itself: it is not a model either, and it
     * carries its own compiled `x-access.read` (§7.1). A view carries the same
     * thing, for the same reason, rather than a second role-shaped keyword that
     * would drift from the gate it is imitating.
     *
     * It composes with `requires` — both must pass, as a cross-tenant query's
     * own access is required as well as the role, never instead.
     */
    'x-access': {
      type: 'object',
      properties: { read: { type: 'string', minLength: 1 } },
      additionalProperties: false,
    },
    node: { $ref: '#/$defs/node' },
  },
} as const;

const validateView = ajv.compile(VIEW_SCHEMA);

/**
 * Compiled `x-access.read`, keyed by the view or node object it was written on.
 *
 * Compiled at BOOT like every other gate expression, so a broken one fails
 * startup rather than blanking a page for one actor at request time. Keyed by
 * object identity for the reason `gates.ts` and `schema.ts` key theirs that
 * way: two apps in one process must not share compiled state.
 */
const viewAccess = new WeakMap<object, Compiled>();

/** Compile the policy on one node and every node beneath it. */
function compileNodeAccess(node: any, where: string): void {
  if (!node || typeof node !== 'object') return;
  const expression: string | undefined = node['x-access']?.read;
  if (typeof expression === 'string') {
    viewAccess.set(node, compileExpression(expression, `${where}.x-access.read`));
  }
  (node.children ?? []).forEach((child: any, i: number) => compileNodeAccess(child, `${where}/${i}`));
}

/** Compile a view's own policy and its whole node tree. Called once, at boot. */
function compileViewAccess(raw: any, where: string): void {
  const expression: string | undefined = raw?.['x-access']?.read;
  if (typeof expression === 'string') {
    viewAccess.set(raw, compileExpression(expression, `${where}.x-access.read`));
  }
  compileNodeAccess(raw?.node, where);
}

/**
 * Does this actor pass the policy written on this view or node?
 *
 * Absent means **no constraint**, not deny. A model with no `x-access` denies
 * because it is a resource and silence about a resource must never grant; a
 * view is a projection of resources the server re-checks anyway, so silence
 * here means "this page adds no constraint of its own" and the models it reads
 * still decide. Making it deny would also make every existing view disappear,
 * which is a migration, not a default.
 */
function passesViewAccess(raw: object, actor: Actor | undefined): boolean {
  const compiled = viewAccess.get(raw);
  if (!compiled) return true;
  if (!actor) return false;      // a policy expression cannot be true for nobody
  try {
    return compiled.evalSync({
      actor: { id: actor.id, roles: [...actor.roles], orgId: actor.orgId },
      now: new Date().toISOString(),
    }) === true;
  } catch {
    return false;                // a throwing gate refuses, as everywhere else
  }
}

export class ViewError extends ConfigError {
  constructor(source: string, detail: string) {
    super(source, detail);
    this.message = `view error in ${source}: ${detail}`;
    this.name = 'ViewError';
  }
}

/**
 * Every field a node's `layout` names must exist on the model the node reads
 * (its own `props.model`, else the page's `requires`). Shape validation alone
 * let a typo'd field pass boot and silently render nothing (AUD-045).
 */
function assertKnownFields(node: any, page: any, models: Map<string, Model>, source: string, where = 'node') {
  const modelName = node.props?.model ?? page.requires;
  const model = typeof modelName === 'string' ? models.get(modelName) : undefined;
  const fail = (detail: string, at: string = where) => new ViewError(source, `${at} ${detail}`);
  if (typeof modelName === 'string' && !model) throw fail(`names unknown model "${modelName}" — known: ${[...models.keys()].join(', ')}`);
  if (typeof node.requires === 'string' && !models.has(node.requires)) {
    throw fail(`requires unknown model "${node.requires}" — known: ${[...models.keys()].join(', ')}`);
  }
  if (model) {
    // A board IS a lifecycle: its lanes are the state field's values and its
    // moves are the declared transitions (W-102). Pointed at a model with no
    // `x-states` it can only render an empty frame, which is the silence the
    // rest of these checks exist to prevent — so it is refused at boot.
    if (node.type === 'BoardScreen' && !model.states) {
      throw fail(`renders a board of "${model.name}", which declares no x-states — a board's lanes and moves are a lifecycle, so declare one (x-states: { field, initial, transitions })`);
    }
    const layout: any[] = Array.isArray(node.props?.layout) ? node.props.layout : [];
    for (const [i, section] of layout.entries()) {
      const names: unknown[] = 'row' in section ? section.row : 'group' in section ? section.fields : [section.field];
      for (const name of names) crossRef(name, model, `${where}/props/layout/${i}`, { system: false, error: fail });
    }
    /**
     * Each of these reads a prop by NAME, and a prop name is not owned by one
     * component. `columns` is a list of grid columns on `DataGrid` and a column
     * COUNT on `ContentCards`, `ContentStats`, `ContentSection` and `Dashboard`;
     * `fields` and `rules` are the same story waiting to happen. Reading a
     * number as a list crashed boot with `.entries is not a function` — a
     * TypeError out of the config loader, on config that was entirely valid.
     *
     * So each one checks the shape it needs before walking it, the way the
     * `layout` line above already did. A prop that is not the shape this check
     * understands is not this check's business.
     */
    const propList = (key: string): unknown[] => {
      const value = node.props?.[key];
      return Array.isArray(value) ? value : [];
    };
    for (const [i, name] of propList('fields').entries()) {
      crossRef(name, model, `${where}/props/fields/${i}`, { system: false, error: fail });
    }
    // A rule names two fields: the one it acts on and the one it watches. Both
    // must exist, and a rule is the case where silence is worst — the field
    // simply never hides and the author believes the declaration works. Proven
    // on 2026-09-13: a rule left naming `internalNote` after the rename booted
    // clean (AUD-054).
    for (const [i, rule] of (propList('rules') as any[]).entries()) {
      if (!rule || typeof rule !== 'object') continue;
      crossRef(rule.field, model, `${where}/props/rules/${i}/field`, { system: false, error: fail });
      crossRef(rule.when?.field, model, `${where}/props/rules/${i}/when/field`, { system: false, error: fail });
    }
    for (const [i, column] of (propList('columns') as any[]).entries()) {
      // Grid columns may name system fields (createdAt) — a form may not.
      if (column && typeof column === 'object') crossRef(column.field, model, `${where}/props/columns/${i}`, { error: fail });
    }
  }
  (node.children ?? []).forEach((child: any, i: number) =>
    assertKnownFields(child, page, models, source, `${where}/children/${i}`));
}

/**
 * The model whose lifecycle a node's `when` reads.
 *
 * The node's own model if it names one, else the page's. A condition has to be
 * about SOMETHING, and the only record a page is about is the one its route
 * addresses — which is the page's `requires`.
 */
function stateModelName(node: any, page: any): string | undefined {
  const name = node.props?.model ?? node.requires ?? page.requires;
  return typeof name === 'string' ? name : undefined;
}

/**
 * Every state a `when` names must be one the model actually declares (N-101).
 *
 * This is the whole reason `when` reads a declared state instead of an
 * expression: a typo is answerable at BOOT, with the valid names in the
 * message. The failure it replaces is the one this file's other cross-checks
 * exist for — a condition that is evaluated, never holds, and renders nothing,
 * while the author believes the declaration works (AUD-054's shape).
 *
 * `rowActions[].when` is checked here too rather than in the component: a
 * condition that silently never fires is the same defect whether it hides a
 * node or an action, and the component cannot refuse a boot it is not present
 * for.
 */
function assertKnownStates(node: any, page: any, models: Map<string, Model>, source: string, where = 'node') {
  const fail = (detail: string, at: string = where) => new ViewError(source, `${at} ${detail}`);

  const check = (when: any, at: string) => {
    const wanted = whenStates(when);
    if (!wanted.length) return;
    const modelName = stateModelName(node, page);
    if (!modelName) {
      throw fail('declares `when` but neither it nor its page names a model — `when` reads a record\'s state, so there must be a record', at);
    }
    const model = models.get(modelName);
    if (!model) throw fail(`declares \`when\` against unknown model "${modelName}" — known: ${[...models.keys()].join(', ')}`, at);
    if (!model.states) {
      throw fail(`declares \`when\` against "${modelName}", which declares no x-states — a state condition needs a declared lifecycle (x-states: { field, initial, transitions })`, at);
    }
    for (const state of wanted) {
      if (!model.states.values.includes(state)) {
        throw fail(`names unknown state "${state}" of "${modelName}" — declared states: ${model.states.values.join(', ')}`, at);
      }
    }
  };

  check(node.when, where);

  // Per-row conditions (N-111). Shape is checked here because `rowActions` is a
  // component prop, and a malformed one would otherwise reach the browser and
  // quietly do nothing.
  const rowActions = Array.isArray(node.props?.rowActions) ? node.props.rowActions : [];
  for (const [i, action] of rowActions.entries()) {
    if (!action || typeof action !== 'object' || action.when === undefined) continue;
    const at = `${where}/props/rowActions/${i}/when`;
    const when = action.when;
    if (typeof when !== 'object' || when === null || Array.isArray(when)) {
      throw fail('must be an object of the form { state: <name or list> }', at);
    }
    const extra = Object.keys(when).filter((k) => k !== 'state');
    if (extra.length) throw fail(`has unknown key(s) ${extra.join(', ')} — the only key is \`state\``, at);
    const wanted = whenStates(when);
    if (!wanted.length) throw fail('needs a `state`, as a name or a list of names', at);
    check(when, at);
  }

  (node.children ?? []).forEach((child: any, i: number) =>
    assertKnownStates(child, page, models, source, `${where}/children/${i}`));
}

/**
 * Every icon a view names must be one that can be drawn (AUD-205).
 *
 * `Icon.vue` falls back to an empty shape list for a name it does not know and
 * still renders the `<svg>`, so a misspelt icon is an invisible hole in the
 * page with no error anywhere. That is the same silence `assertKnownStates`
 * and `assertKnownFields` exist to remove, and it is answered the same way: at
 * boot, naming the vocabulary.
 *
 * **Which props hold an icon is a convention, not a list**: a key called
 * `icon`, a key ending in `Icon`, and `name` on an `Icon` node. Walking the
 * props by that rule rather than enumerating known prop paths means a new
 * icon-bearing prop is covered the day it is added, instead of the day someone
 * remembers to add it here. The walk descends objects and arrays, so
 * `rowActions[].icon` and `brand.backIcon` are reached without naming either.
 */
/**
 * Every `t:` key a view names has to exist in the default language's catalogue.
 *
 * It is checked against the DEFAULT language only, deliberately. A key missing
 * there is a typo or copy nobody wrote, and the page would render the literal
 * `t:terms.heading` to a reader; a key missing from an alternate is a
 * translation not done yet, which renders in the default language and is the
 * whole point of having one. Conflating them would make starting a second
 * language impossible without finishing it.
 */
function assertKnownCopy(doc: any, known: ReadonlySet<string>, source: string) {
  const walk = (value: unknown, path: string) => {
    if (typeof value === 'string') {
      const key = copyKey(value);
      if (key === undefined || known.has(key)) return;
      throw new ViewError(source,
        `${path} names copy "${key}" that locales/ does not define in the default language`);
    }
    if (Array.isArray(value)) return value.forEach((item, i) => walk(item, `${path}/${i}`));
    if (value && typeof value === 'object') {
      for (const [k, inner] of Object.entries(value)) walk(inner, `${path}/${k}`);
    }
  };
  // The whole document, not only the nodes: a page's own title, description and
  // nav label are copy a reader sees too.
  for (const key of ['title', 'description', 'nav']) walk(doc[key], key);
  walk(doc.node, 'node');
}

/**
 * The same check, for the copy a MODEL declares — `x-labels` on an enum.
 *
 * A separate entry point because models load before views and are not
 * documents: the message names the model and the field rather than a node path.
 */
export function assertKnownModelCopy(models: Iterable<Model>, known: ReadonlySet<string>) {
  for (const model of models) {
    for (const [field, prop] of Object.entries(model.props)) {
      for (const [value, label] of Object.entries(prop.labels ?? {})) {
        const key = copyKey(label);
        if (key === undefined || known.has(key)) continue;
        throw new ConfigError(`models/${model.name}.yaml`,
          `x-labels on "${field}" shows "${value}" as copy "${key}", which locales/ does not define in the default language`);
      }
    }
    for (const [name, transition] of Object.entries(model.states?.transitions ?? {})) {
      const key = transition.label === undefined ? undefined : copyKey(transition.label);
      if (key === undefined || known.has(key)) continue;
      throw new ConfigError(`models/${model.name}.yaml`,
        `x-states.transitions.${name}.label is copy "${key}", which locales/ does not define in the default language`);
    }
  }
}

function assertKnownIcons(node: any, known: ReadonlySet<string>, source: string, where = 'node') {
  const isIconKey = (key: string) => key === 'icon' || /Icon$/.test(key);

  const walk = (value: unknown, path: string, iconHere: boolean) => {
    if (typeof value === 'string') {
      if (!iconHere || known.has(value)) return;
      throw new ViewError(source, `${path} names unknown icon "${value}" — declared: ${[...known].sort().join(', ')}`);
    }
    if (Array.isArray(value)) {
      value.forEach((item, i) => walk(item, `${path}/${i}`, iconHere));
      return;
    }
    if (value && typeof value === 'object') {
      for (const [key, inner] of Object.entries(value)) {
        walk(inner, `${path}/${key}`, isIconKey(key));
      }
    }
  };

  // `Icon` addresses its drawing by `name`; every other component by an
  // icon-shaped key. Checked separately so a `name` on anything else — a
  // channel, a tab, a field — is not read as an icon.
  if (node.type === 'Icon' && typeof node.props?.name === 'string' && !known.has(node.props.name)) {
    throw new ViewError(source,
      `${where}/props/name names unknown icon "${node.props.name}" — declared: ${[...known].sort().join(', ')}`);
  }
  for (const [key, value] of Object.entries(node.props ?? {})) {
    walk(value, `${where}/props/${key}`, isIconKey(key));
  }

  (node.children ?? []).forEach((child: any, i: number) =>
    assertKnownIcons(child, known, source, `${where}/children/${i}`));
}

/** Every component name a node uses, so an unknown one fails at boot. */
function assertKnownComponents(node: any, components: readonly string[], source: string, where = 'node') {
  if (!components.includes(node.type)) {
    throw new ViewError(source, `${where} names unknown component "${node.type}" — known: ${components.join(', ')}`);
  }
  (node.children ?? []).forEach((child: any, i: number) =>
    assertKnownComponents(child, components, source, `${where}/children/${i}`));
}

export interface NodeProjection {
  type: string;
  props?: Record<string, unknown>;
  children?: NodeProjection[];
  /** The parent region this node belongs to; absent means the default one. */
  slot?: string;
}

export interface PageProjection {
  id: string;
  route: string;
  title?: string;
  description?: string;
  nav?: string;
  navOrder?: number;
  node: NodeProjection;
}

/** What this actor may do with one model. Facts, never the rules behind them. */
export interface ModelProjection {
  /** Operations this actor may perform. */
  ops: string[];
  /** Required field sets, for the operations they may perform. */
  required: Record<string, string[]>;
  /**
   * Fields that reference another model, so a form can render a picker.
   *
   * Present only for targets this actor may READ: a relation must not become a
   * way to enumerate a model whose gate would refuse you. The picker fetches its
   * options through the same dispatch, so scope applies there too.
   */
  lookups: Record<string, { model: string; label: string }>;
  /**
   * What each upload property will accept, for properties this actor may WRITE.
   *
   * The picker needs it to filter and the form needs it to refuse an oversized
   * file before spending the upload; the server enforces both regardless
   * (`readMultipart`, and the stage route). Projected per actor for the same
   * reason the required set is: which fields take a file, and on what terms, is
   * shape, and shape follows the gates (§19). Nothing about storage layout or
   * keys crosses — only the two limits the caller is about to be judged against.
   */
  uploads: Record<string, { accept: string[]; maxSize: number }>;
  /**
   * How each `enum` value is SHOWN, by field then value (`x-labels`).
   *
   * Absent when no field this actor may read declares any, so a model without
   * labels projects exactly as it did before the keyword existed.
   *
   * Only for fields this actor may READ, for the reason every other entry here
   * is per-actor: a label set enumerates a field's values, and a field whose
   * read gate refuses this actor should not disclose them.
   *
   * **The stored value never leaves.** A select posts the value and a grid
   * matches on it; this says only what is drawn over it.
   */
  labels?: Record<string, Record<string, string>>;
  /**
   * The model's lifecycle, if it declares one — the lanes a board draws and the
   * moves it may offer (W-102).
   *
   * Facts, never the rules behind them: `from`, `to` and the ordered state
   * values cross, and a transition's `access` expression does not. A transition
   * this actor may not perform is ABSENT, the same way an operation they may
   * not perform is absent from `ops` — so a board has nothing to hide, and the
   * server refuses the move regardless of what the client believes.
   */
  states?: {
    field: string;
    initial: string;
    values: string[];
    transitions: Record<string, { from: string[]; to: string; label?: string }>;
  };
}

export interface AppProjection {
  title?: string;
  /**
   * The language this document was resolved in. Absent on an app that declares
   * none, which is what keeps a single-language app's projection byte-identical
   * to what it was before languages existed.
   */
  locale?: string;
  /**
   * Every language the app publishes in. On the document because the client
   * strips a prefix before matching too, and a language picker has to name the
   * languages it offers — both need the set, not just the current one.
   */
  languages?: LanguageSet;
  pages: PageProjection[];
  /** The app's declared icon vocabulary, name to SVG path data. */
  icons?: Record<string, string>;
  /** Per-actor model facts. Empty for a visitor with no session. */
  models: Record<string, ModelProjection>;
}

const NODE_KEYS = ['type', 'props', 'children', 'slot'] as const;
// `requires` and `anonymous` are deliberately NOT here: they are inputs to the
// projection, not facts about the actor, and the client has no use for either.
const PAGE_KEYS = ['id', 'route', 'title', 'description', 'nav', 'navOrder'] as const;

function projectNode(
  raw: any, where: string, readable: (model: string) => boolean, actor?: Actor, state?: string,
): NodeProjection | undefined {
  if (!raw || typeof raw.type !== 'string') {
    throw new Error(`view ${where}: every node needs a string "type"`);
  }
  // Absent, not hidden: a tile the actor may not read never reaches the browser,
  // so there is nothing for a client-side toggle to get wrong.
  if (typeof raw.requires === 'string' && !readable(raw.requires)) return undefined;
  // A tile may also carry its own policy, for the same reason a page may.
  if (!passesViewAccess(raw, actor)) return undefined;
  /**
   * The state condition, evaluated HERE (N-102).
   *
   * Here and not in the browser, so a node whose condition does not hold is
   * absent from what the browser receives rather than hidden in it. A condition
   * that cannot be evaluated — no record, or a record this actor may not read,
   * so `state` is undefined — does not hold: silence about a record must not
   * render the branch that assumes one.
   *
   * This is presentation, never authorization. The states themselves are
   * already public in the projection (`models.<name>.states.values`), and every
   * operation the hidden node would have offered is refused by the gates when
   * the actor calls the API directly.
   */
  const wanted = whenStates(raw.when);
  if (wanted.length && (state === undefined || !wanted.includes(state))) return undefined;

  const node: NodeProjection = { type: raw.type };
  for (const key of NODE_KEYS) {
    if (key === 'type' || raw[key] === undefined) continue;
    if (key === 'props') node.props = { ...raw.props };
    if (key === 'slot') node.slot = raw.slot;
    if (key === 'children') {
      node.children = (raw.children as any[])
        .map((c, i) => projectNode(c, `${where}/${i}`, readable, actor, state))
        .filter((c): c is NodeProjection => c !== undefined);
    }
  }
  return node;
}

/**
 * Build the projection for ONE actor (§19).
 *
 * The client receives facts about this actor — which pages they can reach, which
 * operations they may perform — and never the rules that produced them. Nothing
 * here evaluates on the client, because nothing rule-shaped is sent.
 *
 * Built by WHITELIST, and the filtering is deny-by-default in both directions: a
 * page naming a model the actor cannot read is ABSENT, and a page not marked
 * `anonymous` is absent for a visitor with no session.
 */
export function projectApp(
  views: any[],
  models: Map<string, Model>,
  actor: Actor | undefined,
  title?: string,
  /**
   * The lifecycle state of the record the requested page is about, by model
   * name, for `when` to read (N-102).
   *
   * Supplied by the caller because reading it is a gated database read and this
   * function performs none: `app.ts` fetches the row through the same engine
   * every other read goes through, so a record this actor may not read yields
   * nothing here and every conditioned node is absent. Empty on a page that
   * addresses no record, which is every page written before this.
   */
  states: Record<string, string | undefined> = {},
  /** The app's declared icon vocabulary (`config/icons.yaml`). */
  icons?: Record<string, string>,
  /**
   * The language to resolve this document in, what else the app publishes in,
   * and the words.
   *
   * It is a parameter rather than a field on the actor **because it comes from
   * the request.** `orgId` and `roles` are server-assigned precisely so a
   * caller cannot name its own (§22), and a request-derived value sitting on
   * the same object is a value an `x-access` expression could one day read.
   * Locale is not an authorisation axis: both languages of a public page are
   * readable by the same anonymous actor.
   */
  language?: LocaleContext,
): AppProjection {
  const readable = (modelName: string): boolean => {
    const model = models.get(modelName);
    // A page naming a model that does not exist is a config error caught at
    // boot; here, refuse rather than assume.
    if (!model || !actor) return false;
    return allowsAction(model, makeView(actor, 'list', model, {}));
  };

  const visible = views.filter((raw) => {
    // A visitor sees `anonymous: true` pages and nothing else. Tested by
    // identity rather than by absence, because a visitor now HAS an actor —
    // without this, a page that simply declared no `requires` would become
    // public the day the anonymous actor arrived.
    if (!actor || isAnonymous(actor)) return raw.anonymous === true && passesViewAccess(raw, actor);
    if (raw.anonymous === true) return passesViewAccess(raw, actor);
    // Both, never either: a page's own policy narrows what its model allows,
    // exactly as a cross-tenant query's `x-access` is required as well as the
    // reserved role rather than instead of it.
    return (raw.requires === undefined || readable(raw.requires)) && passesViewAccess(raw, actor);
  });

  const pages = visible.flatMap((raw) => {
    const node = projectNode(raw.node, raw.id ?? '?', readable, actor, stateOf(raw, states));
    // The whole page's root node was refused: the page goes with it.
    if (!node) return [];
    const page = { node } as PageProjection;
    for (const key of PAGE_KEYS) if (raw[key] !== undefined) (page as any)[key] = raw[key];
    if (!page.id || !page.route) throw new Error(`view "${raw.id ?? '?'}": id and route are required`);
    return [page];
  });

  // Directory order is filesystem-dependent; navigation order must not be.
  pages.sort((a, b) => (a.navOrder ?? Number.MAX_SAFE_INTEGER) - (b.navOrder ?? Number.MAX_SAFE_INTEGER));

  // Model facts, for the models this actor can actually reach.
  const projected: Record<string, ModelProjection> = {};
  if (actor) {
    const named = new Set(visible.map((v) => v.requires).filter(Boolean) as string[]);
    for (const name of named) {
      const model = models.get(name);
      if (!model) continue;
      const ops = PROJECTED_OPS.filter((op) => allowsAction(model, makeView(actor, op, model, {})));
      const custom = Object.keys(model.actions)
        .filter((op) => allowsAction(model, makeView(actor, op, model, {})));
      const all = [...ops, ...custom];
      const lookups: Record<string, { model: string; label: string }> = {};
      for (const [field, lookup] of Object.entries(model.lookups)) {
        if (readable(lookup.model)) lookups[field] = lookup;
      }

      const uploads: Record<string, { accept: string[]; maxSize: number }> = {};
      for (const [field, settings] of Object.entries(model.uploads)) {
        if (!canWrite(model, makeView(actor, 'create', model, {}), field)) continue;
        uploads[field] = { accept: settings.accept, maxSize: settings.maxSize };
      }

      const labels: Record<string, Record<string, string>> = {};
      for (const [field, prop] of Object.entries(model.props)) {
        if (prop.labels && canRead(model, makeView(actor, 'get', model, {}), field)) {
          labels[field] = prop.labels;
        }
      }

      const required: Record<string, string[]> = {};
      // Only for operations they may perform — §19 is explicit that the required
      // set for an op the actor cannot perform does not cross.
      for (const op of all) {
        const set = requirementSet(model, op);
        if (set.length) required[op] = set;
      }
      // Only the transitions this actor may perform — `custom` has already been
      // filtered through the gate, and a transition is one of its entries.
      const states = model.states && {
        field: model.states.field,
        initial: model.states.initial,
        values: model.states.values,
        transitions: Object.fromEntries(
          Object.entries(model.states.transitions)
            .filter(([transition]) => custom.includes(transition))
            .map(([transition, { from, to, label }]) => [transition, { from, to, ...(label ? { label } : {}) }]),
        ),
      };
      projected[name] = {
        ops: all, required, lookups, uploads,
        ...(Object.keys(labels).length ? { labels } : {}),
        ...(states ? { states } : {}),
      };
    }
  }

  const document: AppProjection = {
    ...(title ? { title } : {}),
    ...(language ? { locale: language.locale, languages: language.languages } : {}),
    ...(icons ? { icons } : {}),
    pages,
    models: projected,
  };
  // Both run here, once, over the finished document — see `translate`. The
  // page ROUTES are deliberately not rewritten: matching happens against the
  // path with the prefix already stripped, so a prefixed route would match
  // nothing. Only the links a reader follows move.
  if (!language) return document;
  return localiseLinks(translate(document, language), language, pages.map((page) => page.route));
}

const PROJECTED_OPS = ['create', 'get', 'list', 'update', 'delete', 'count', 'aggregate', 'history'];

/** The state value that a view's `when` conditions read, if one was resolved. */
function stateOf(raw: any, states: Record<string, string | undefined>): string | undefined {
  return typeof raw?.requires === 'string' ? states[raw.requires] : undefined;
}

/**
 * Does any node in this view carry a `when`? (N-102)
 *
 * `app.ts` asks before spending a database read: a page with no state condition
 * needs no record fetched to project it, and every page written before this
 * falls in that class. A NODE's `when` only — a `rowActions[].when` is judged
 * per row in the grid, against rows the server already sent it.
 */
export function usesStateCondition(node: any): boolean {
  if (!node || typeof node !== 'object') return false;
  if (whenStates(node.when).length) return true;
  return (node.children ?? []).some((child: any) => usesStateCondition(child));
}

/**
 * A component may DECLARE what props it takes, and then they are validated at
 * boot (WP-07 S-102, AUD-065).
 *
 * Node `props` are copied to the browser wholesale — the whitelist in this file
 * is at the key level above them — so until now a misspelled prop reached the
 * component as `undefined` and rendered as a blank area of the page. The schema
 * lives with the app, not here: `core` validates views without importing the UI
 * package, exactly as it does for component NAMES.
 *
 * Declaring is optional and partial on purpose. A component with no schema
 * behaves as it always did, so this arrives one component at a time rather than
 * as a flag day across sixteen of them.
 */
export type ComponentProps = Readonly<Record<string, object>>;

function assertKnownProps(
  node: any, schemas: ComponentProps, source: string, where = 'node',
): void {
  const schema = schemas[node.type];
  if (schema) {
    const validate = propValidator(node.type, schema);
    if (!validate(node.props ?? {})) {
      throw new ViewError(source, `${where} props: ${formatSchemaErrors(validate.errors)}`);
    }
  }
  (node.children ?? []).forEach((child: any, i: number) =>
    assertKnownProps(child, schemas, source, `${where}/children/${i}`));
}

/** Compiled once per component, keyed by the schema object Ajv was handed. */
const propValidators = new WeakMap<object, ValidateFunction>();
function propValidator(name: string, schema: object): ValidateFunction {
  let compiled = propValidators.get(schema);
  if (!compiled) {
    compiled = ajv.compile({ ...(schema as Record<string, unknown>), $id: `props:${name}` });
    propValidators.set(schema, compiled);
  }
  return compiled;
}

export async function loadViews(
  dir: string,
  components: readonly string[] = [],
  models?: Map<string, Model>,
  componentProps: ComponentProps = {},
  /**
   * Every icon name a view may use: the app's declared vocabulary plus the
   * framework's built-ins. Supplied by the caller, because the built-ins live
   * in the UI package and core does not import it — the same reason
   * `components` is passed in. Omitted -> the icon check is skipped.
   */
  icons?: ReadonlySet<string>,
  /**
   * Every copy key the default language defines (`config/locales/<default>.yaml`).
   * Omitted -> the copy check is skipped, which is what an app declaring no
   * languages gets.
   */
  copy?: ReadonlySet<string>,
): Promise<any[]> {
  const views: any[] = [];
  const seen = new Map<string, string>();
  const orders = new Map<number, string>();

  const loaded = await loadFamily(dir, {
    meta: validateView,
    compile: (doc) => doc,
    error: (source, detail) => new ViewError(source, detail),
  });

  for (const { source, value: doc } of loaded) {
    // Skipped when the caller supplies no list, so core stays independent of the
    // UI package; the app passes its registry's names in.
    if (components.length) assertKnownComponents(doc.node, components, source);
    // Props are checked after the NAME, so an unknown component is reported as
    // an unknown component rather than as a schema that does not exist.
    assertKnownProps(doc.node, componentProps, source);
    // After the prop SHAPES, so a malformed prop is reported as malformed
    // rather than as an unknown icon inside it.
    if (icons) assertKnownIcons(doc.node, icons, source);
    // Last of the vocabulary checks, so a key inside a malformed prop or an
    // unknown component is reported as that first.
    if (copy) assertKnownCopy(doc, copy, source);

    // Field and model names are checked when the caller supplies the models;
    // the app does, tests of the view shape alone need not.
    if (models) {
      if (doc.requires !== undefined && !models.has(doc.requires)) {
        throw new ViewError(source, `requires unknown model "${doc.requires}" — known: ${[...models.keys()].join(', ')}`);
      }
      assertKnownFields(doc.node, doc, models, source);
      // Conditions are cross-checked against the lifecycle the model declares,
      // so an unknown state names the valid ones and fails the boot (N-101).
      assertKnownStates(doc.node, doc, models, source);
    }

    const clash = seen.get(doc.route);
    if (clash) throw new ViewError(source, `route "${doc.route}" is already served by ${clash}`);
    seen.set(doc.route, source);

    // Two pages with the same navOrder tie, and the tie breaks on directory
    // order — which is the exact non-determinism navOrder exists to remove.
    if (doc.navOrder !== undefined) {
      const other = orders.get(doc.navOrder);
      if (other) {
        throw new ViewError(source,
          `navOrder ${doc.navOrder} is already used by ${other} — ties resolve by directory order, which is not stable`);
      }
      orders.set(doc.navOrder, source);
    }

    /**
     * Compile the page's and every tile's `x-access.read` now, so a broken
     * expression fails the BOOT — the same posture models, queries and gates
     * take. A policy that only breaks when a particular actor loads a
     * particular page is a policy nobody finds until it matters.
     */
    try {
      compileViewAccess(doc, source);
    } catch (error) {
      throw new ViewError(source, (error as Error).message);
    }

    views.push(doc);
  }
  return views;
}
