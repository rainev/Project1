import { stat } from 'node:fs/promises';
import { createDispatcher } from './dispatch.ts';
import type { Actor } from './engine/types.ts';
import { createAdapter } from './db/factory.ts';
import { loadModels, type Model } from './model.ts';
import { loadAppConfig } from './app-config.ts';
import { ConfigError } from './config/loader.ts';
import { loadQueries } from './queries/compile.ts';
import { serve, json, type Handler } from './server.ts';
import { assertKnownModelCopy, loadViews, projectApp, usesStateCondition } from './projection.ts';
import { matchRoute, resolveLocale } from './routes.ts';
import { compileGates } from './gates.ts';
import { compileGuards } from './engine/guards.ts';
import { loadHandlers } from './handlers/index.ts';
import { createAuthRoutes, ensureOrgs, resolveActorFromRequest, type AuthConfig } from './auth/index.ts';
import { platformAdmins } from './auth/roles.ts';
import { ORG, USER, SYSTEM_MODELS, REGISTERED_SYSTEM_MODELS } from './auth/system-models.ts';
import { createEngine } from './engine/execute.ts';
import { createChannelRuntime, type ChannelAudit } from './channels/runtime.ts';
import { OUTBOX } from './events/model.ts';
import { createOutbox } from './events/outbox.ts';
import { SCHEDULE } from './schedule/model.ts';
import { createScheduler } from './schedule/ticker.ts';
import { loadProviders } from './notify/providers.ts';
import { send, type Message } from './notify/send.ts';
import { crossReferenceProviders } from './handlers/declare.ts';
import { rotateEncryptedFields } from './db/rotate.ts';
import { secret } from './secrets.ts';
import { createKeyProvider } from './crypto/keys.ts';
import { FileLocalImpl } from './files/local.ts';
import { createAssets } from './assets.ts';
import { ANONYMOUS, assertPublicModelsAreScoped } from './public.ts';
import { loadTheme, themeCss } from './theme.ts';
import { loadIcons } from './icons.ts';
import { loadLocales, type LocaleContext } from './locales.ts';
import { robotsTxt, sitemapXml } from './seo.ts';

export interface AppOptions {
  configDir: string;
  databaseUrl: string;
  port: number;
  /** Interface to listen on. Unset means every interface — see `ServeOptions.hostname`. */
  hostname?: string;
  /**
   * The directory every `x-channels` root must sit under. Server configuration, never a
   * row: without it, containment would be checked against a value the row supplied.
   * Defaults to the user's home directory.
   */
  workspaceBase?: string;
  /**
   * Run every request as one local administrator, with no sign-in.
   *
   * For a single-user desktop application, where the window and the server are the same
   * program and there is nobody else to authenticate. **It is refused unless the server
   * is also bound to a loopback address** — the same setting on a LAN-reachable port
   * would hand an administrator to anyone who can reach it, which is not a footgun to
   * leave lying around.
   */
  localActor?: boolean;
  version?: string;
  assets?: Handler;
  /** Directory holding the built UI bundle. */
  distDir?: string;
  title?: string;
  /** Where uploaded bytes live. Defaults to `<cwd>/.data/files`. */
  filesDir?: string;
  /**
   * Component names a view may use. The app passes its UI registry's names in,
   * so core validates views without importing the UI package. Omitted -> the
   * component check is skipped and only the view meta-schema applies.
   */
  components?: readonly string[];
  /**
   * What each component's props must look like, by component name (S-102).
   * Partial by design: a component with no entry is validated no further than
   * the view meta-schema, exactly as before.
   */
  componentProps?: import('./projection.ts').ComponentProps;
  /**
   * Icon names the framework itself ships. Added to the app's declared
   * `icons.yaml` to form the vocabulary a view may name; a view naming
   * anything else fails the boot rather than drawing an empty `<svg>`
   * (AUD-205). Omitted -> the icon check is skipped.
   */
  builtinIcons?: readonly string[];
  /** Argon2 cost. Lowered for tests and local verification; see project memory. */
  argon?: { memoryCost: number; timeCost: number };
  /**
   * Comma-separated addresses holding the reserved `platform` role. Defaults to
   * `PLATFORM_ADMINS`; the tests pass it directly.
   */
  platformAdmins?: string;
}

/** An app need not declare every family; a missing directory is not an error. */
async function isDirectory(path: string): Promise<boolean> {
  try {
    return (await stat(path)).isDirectory();
  } catch {
    return false;
  }
}

/**
 * Data keys, and which of them is active (§8, WP-04 E-122).
 *
 * `APP_DEK` is key id `k1`. It was the only spelling before rotation existed
 * and it is the kid every envelope in every existing database already names, so
 * it keeps that meaning rather than becoming "whichever key is current".
 *
 * A further key is `APP_DEK_<KID>` — `APP_DEK_K2` is kid `k2` — and
 * `APP_DEK_ACTIVE` names the one NEW ciphertext is written with. Every key
 * resolves through `secret()`, so each has its own `_FILE` form. Rotating is
 * therefore: add the new key, point `APP_DEK_ACTIVE` at it, restart; the boot
 * re-seals every row, and the old key can then be removed.
 */
function resolveDataKeys(): { keys: Record<string, string>; activeKid: string } {
  const production = process.env.NODE_ENV === 'production';
  const keys: Record<string, string> = {};

  // `APP_DEK_ACTIVE` names a key, it is not one; `..._FILE` belongs to whatever
  // key it suffixes. Neither is a kid.
  for (const name of Object.keys(process.env)) {
    const match = /^APP_DEK_([A-Z0-9]+)$/.exec(name);
    if (!match || match[1] === 'ACTIVE' || match[1] === 'FILE') continue;
    keys[match[1]!.toLowerCase()] = secret(name);
  }
  // The `_FILE` form of an extra key: `APP_DEK_K2_FILE` is still kid `k2`.
  for (const name of Object.keys(process.env)) {
    const match = /^APP_DEK_([A-Z0-9]+)_FILE$/.exec(name);
    if (!match || match[1] === 'ACTIVE') continue;
    const kid = match[1]!.toLowerCase();
    if (!(kid in keys)) keys[kid] = secret(`APP_DEK_${match[1]}`);
  }

  try {
    const legacy = secret('APP_DEK');
    // Ambiguity is a deployment bug, not something to silently resolve —
    // the same posture `secret()` takes to `NAME` and `NAME_FILE` together.
    if ('k1' in keys && keys.k1 !== legacy) {
      throw new Error('both APP_DEK and APP_DEK_K1 are set and differ; they are the same key id — set exactly one');
    }
    keys.k1 = legacy;
  } catch (error) {
    if (String((error as Error).message).startsWith('both APP_DEK and')) throw error;
    // An app that supplied only a rotated key never needs `APP_DEK` itself.
    if (Object.keys(keys).length === 0) {
      if (production) throw error;
      console.warn('WARNING: APP_DEK is not set. Using an ephemeral development data key — encrypted values will not survive a restart. Production refuses to boot without it.');
      keys.k1 = Buffer.from(crypto.getRandomValues(new Uint8Array(32))).toString('base64url');
    }
  }

  const requested = process.env.APP_DEK_ACTIVE?.trim().toLowerCase();
  if (requested && !(requested in keys)) {
    throw new Error(
      `APP_DEK_ACTIVE names key id "${requested}", which has no key material ` +
      `(set APP_DEK_${requested.toUpperCase()}). Known: ${Object.keys(keys).join(', ')}`,
    );
  }
  const activeKid = requested ?? 'k1';
  if (!(activeKid in keys)) {
    throw new Error(
      `no key material for the active key id "${activeKid}": set APP_DEK, ` +
      `or name a different one with APP_DEK_ACTIVE. Known: ${Object.keys(keys).join(', ')}`,
    );
  }
  return { keys, activeKid };
}

/** Production must never boot on a generated secret. */
function resolveJwtSecret(): string {
  const production = process.env.NODE_ENV === 'production';
  if (production) return secret('JWT_SECRET');
  try {
    return secret('JWT_SECRET');
  } catch {
    const ephemeral = Buffer.from(crypto.getRandomValues(new Uint8Array(32))).toString('base64url');
    console.warn('WARNING: JWT_SECRET is not set. Using an ephemeral development secret — every restart invalidates all sessions. Production refuses to boot without it.');
    return ephemeral;
  }
}

export async function createApp(options: AppOptions) {
  const version = options.version ?? 'v0';

  const models = await loadModels(`${options.configDir}/models`, [...REGISTERED_SYSTEM_MODELS, OUTBOX, SCHEDULE]);

  // Compile every expression at boot: a broken gate fails startup, not a request.
  for (const model of models.values()) compileGates(model);
  // The guard keyword's expressions, compiled beside the gates and for the same
  // reason: a limit whose expression is broken must fail the boot, not the
  // first request that happens to reach the limit (S-121).
  for (const model of models.values()) compileGuards(model);
  // A model open to visitors must be scoped by something a visitor has (S-101).
  // Runs after the gates compile, because the check evaluates them.
  assertPublicModelsAreScoped(models.values());

  /**
   * Where a notification can go (§10, WP-06 W-120).
   *
   * Loaded before the handlers, because a `notify` declaration names a provider
   * and a name that resolves to nothing must fail the BOOT — the same reason a
   * hook's file and export resolve here rather than on the first request.
   * `secretRef` resolves now too, through the one secret seam.
   */
  const providers = await loadProviders(options.configDir);
  const providerProblems = crossReferenceProviders(models, providers.keys());
  if (providerProblems.length) throw new ConfigError('notifications.yaml', providerProblems.join('; '));

  // Every declared handler resolves now: a missing file or export fails startup.
  const handlers = await loadHandlers(models.values(), options.configDir, {
    /**
     * The seam between a declaration and the network.
     *
     * `run.ts` evaluates the expressions and knows nothing about sockets; this
     * turns the result into a message and hands it to the provider. It throws
     * on failure, so the outbox counts the attempt and retries — a receiver
     * being down must not lose the event.
     */
    notify: async (name, payload, ctx) => {
      const provider = providers.get(name);
      // Boot cross-referenced this, so reaching it means the two disagree.
      if (!provider) throw new Error(`no notification provider named "${name}"`);
      const message: Message = {
        event: ctx.op, model: ctx.model.name, rowId: ctx.id,
        data: payload.data, at: ctx.meta.at,
        // The declaration's recipient and body, when it named them (S-111,
        // S-112). Undefined when it did not, and the provider's own `to` and
        // default body are then what send. The credential, the relay and the
        // `from` address are NOT here and cannot be: they come from the
        // provider this resolved to, which was loaded from notifications.yaml
        // at boot and is not reachable from a declaration or a row.
        to: payload.to, subject: payload.subject, text: payload.text, html: payload.html,
      };
      await send(provider, message);
    },
  });

  // The third config family. An app that declares no queries has no directory,
  // which is not an error — but a directory that exists is loaded and compiled
  // at boot, so a query that names an unknown model fails startup (§7.1).
  const queriesDir = `${options.configDir}/queries`;
  const queries = (await isDirectory(queriesDir)) ? await loadQueries(queriesDir, models) : new Map();

  // Declared tokens, compiled once: a bad one fails the boot like any other
  // config, rather than rendering as an unstyled page (S-110).
  const theme = await loadTheme(options.configDir);
  /**
   * What the app is, as opposed to what it contains. Its `publicOrigin` is the
   * address the PUBLIC reaches this app at, which behind a proxy terminating
   * TLS is not the address the request arrived on.
   */
  const appConfig = await loadAppConfig(options.configDir);
  const icons = await loadIcons(options.configDir);
  const catalogues = await loadLocales(options.configDir, appConfig.languages);
  /**
   * The keys the default language defines. A view or a model naming copy that
   * is not here refuses the boot, rather than rendering `t:terms.heading` to a
   * reader.
   */
  const copyKeys = catalogues && appConfig.languages
    ? new Set(Object.keys(catalogues[appConfig.languages.default] ?? {}))
    : undefined;
  // Models declare copy too — `x-labels` on an enum — and are checked here
  // rather than beside the other model checks, because the catalogue they are
  // checked against loads after them.
  if (copyKeys) assertKnownModelCopy(models.values(), copyKeys);

  const keys = await createKeyProvider(resolveDataKeys());

  // Uploaded bytes go through the same key path as fields (§8, §9).
  const files = new FileLocalImpl(options.filesDir ?? '.data/files', keys);

  const db = createAdapter(options.databaseUrl);
  /**
   * One entry per table. A registered framework model is in `models` AND in
   * `SYSTEM_MODELS`, so spreading both migrated it twice and reported its table
   * twice — harmless, because migration is idempotent, and misleading to anyone
   * reading the boot line to learn what this app stores.
   */
  const migrating = new Map<string, Model>();
  for (const model of [...SYSTEM_MODELS, OUTBOX, SCHEDULE, ...models.values()]) {
    migrating.set(model.name, model);
  }
  const applied = await db.migrate([...migrating.values()]);

  // Orgs exist before anyone can be in one, and orgIds predating the _orgs table
  // are adopted, so an existing database keeps working.
  const defaultOrg = await ensureOrgs(db);

  // Data migration, and it is one: an active key that nothing is sealed under
  // yet means the old key cannot be retired and every blind index is stale.
  // Before the first request, never after (E-122, see `db/rotate.ts`).
  const rotation = await rotateEncryptedFields(
    db, models.values(), keys, (await db.systemList(ORG)).map((org) => String(org.id)), files,
  );
  if (rotation.ran && (rotation.rows || rotation.files)) {
    console.log(`re-sealed ${rotation.rows} row(s) and ${rotation.files} file(s) under key id "${rotation.kid}"`);
  }

  const jwtSecret = resolveJwtSecret();
  const authConfig: AuthConfig = {
    db,
    keys: { k1: jwtSecret },
    activeKid: 'k1',
    argon: options.argon ?? { memoryCost: 19456, timeCost: 2 },
    // Server configuration, like the JWT secret. A request can no more ask for
    // this than it can ask for its own orgId (Q-121).
    platformAdmins: platformAdmins(options.platformAdmins ?? process.env.PLATFORM_ADMINS),
  };

  /**
   * The outbox worker (WP-06 W-110).
   *
   * It needs an `execute` to run a listener's `ctx.call` through the one door,
   * and the dispatcher needs the worker so it can hint that something is due —
   * which would be a cycle if either owned the other. Neither does: the engine
   * is a closure over configuration and holds no mutable state, so composing a
   * second one here for delivery costs nothing and keeps the dependency a line
   * rather than a knot.
   *
   * Delivery runs on the app's own connection, never a request's, which is what
   * makes "after commit" true by construction: a row this worker can read is a
   * row that committed.
   */
  /**
   * One engine for everything that runs outside a request.
   *
   * The outbox worker and the scheduler both need to reach persistence through
   * the one door, and neither may borrow a request's transaction. `createEngine`
   * is a closure over configuration and holds no mutable state, so composing one
   * here for both is a line rather than a knot.
   */
  /**
   * A connection of its own for work that is not a request.
   *
   * The outbox worker and the scheduler run off timers, so they are genuinely
   * concurrent with request handling — and a driver's transaction state is
   * per CONNECTION. Sharing one with the request path means a worker that opens
   * a transaction while a request opens one gets "cannot start a transaction
   * within a transaction", and the request is the one that 500s. Observed in a
   * full gate run on 2026-09-18, once the scheduler started ticking.
   *
   * Two connections cost one file handle and remove that entire class. What
   * remains is ordinary database contention — see the handoff for the part of
   * that which belongs to `db/**` and is not this package's to fix.
   */
  const backgroundDb = createAdapter(options.databaseUrl);

  const background = createEngine({
    models, queries, handlers, keys, files,
    // A listener runs as the actor who emitted, and that actor may be a
    // visitor — so delivery needs the same fallback the request path has.
    defaultOrgId: String(defaultOrg.id),
  });

  const outbox = createOutbox({ db: backgroundDb, models, handlers, execute: background.execute });

  /**
   * Recurring work (W-121). ONE ticker for every declared schedule, on the
   * app's own connection: a timer per declaration is a number that grows with
   * the config, and each would have to rediscover the same durable state.
   */
  const scheduler = createScheduler({ db: backgroundDb, models, execute: background.execute });

  /**
   * Channels (`x-channels`). Built only when a model declares one, so an app that wants
   * no sockets gets no socket surface at all.
   *
   * The row a channel runs against is read through `execute` like anything else — org
   * scope injected, gates applied — rather than straight off the adapter. A channel is
   * not a way around the one door.
   */
  const declaresChannel = [...models.values()].some((model) => Object.keys(model.channels).length > 0);
  const channelRuntime = declaresChannel
    ? createChannelRuntime({
        models,
        workspaceBase: options.workspaceBase,
        readRow: async (model, id, actor) => {
          const row = await background.execute({
            actor, op: 'get', model: model.name, id, data: {}, query: {},
            meta: { requestId: crypto.randomUUID(), at: new Date().toISOString(), source: 'channel' },
          }, backgroundDb, 0);
          return (row ?? undefined) as Record<string, unknown> | undefined;
        },
        audit: (entry: ChannelAudit) => {
          // Operator-visible on stdout, in the same place every other refusal shows up.
          console.log(`[channel] ${entry.decision} ${entry.model}.${entry.channel}` +
            `${entry.sessionId ? ` ${entry.sessionId}` : ''}${entry.detail ? ` — ${entry.detail}` : ''}`);
        },
      })
    : undefined;

  /**
   * A request with no session is a VISITOR, not a non-entity (WP-07 S-101).
   *
   * Returning the anonymous actor rather than `undefined` is what lets a public
   * model be read at all, and it moves no boundary: the actor holds one role
   * that grants nothing and an empty org, so every gate judges it exactly as it
   * judged a stranger before. The intake still answers 401 rather than 403 when
   * a visitor is refused — being unauthenticated is the more useful answer.
   */
  /**
   * The single local identity, when `localActor` is on. Created once, like the default
   * org: gates still run, roles are still read from a row, and nothing about the
   * request path changes — the only difference is that the identity arrives from
   * configuration instead of a cookie.
   */
  let localIdentity: Actor | undefined;
  if (options.localActor) {
    const loopback = ['127.0.0.1', '::1', 'localhost'];
    if (!options.hostname || !loopback.includes(options.hostname)) {
      throw new Error(
        'localActor needs a loopback bind: pass --bind 127.0.0.1. Running with no sign-in on a ' +
        'reachable interface would give an administrator to anyone who can reach the port.');
    }
    const email = 'local@app-studio';
    const existing = await db.systemFind(USER, { email });
    const row = existing ?? await db.systemCreate(USER, {
      email, passwordHash: '!', orgId: defaultOrg.id, roles: 'admin', tokenVersion: 0,
    });
    localIdentity = { id: String(row.id), roles: ['admin'], orgId: String(row.orgId) };
    console.log(`  local actor: ${email} (no sign-in; loopback only)`);
  }

  const resolveActor = async (request: Request) =>
    localIdentity ?? (await resolveActorFromRequest(request, authConfig)) ?? ANONYMOUS;

  const dispatch = createDispatcher({
    version,
    models,
    queries,
    db,
    handlers,
    keys,
    files,
    onEmit: () => outbox.nudge(),
    resolveActor,
    defaultOrgId: String(defaultOrg.id),
  });

  let assets = options.assets;
  let views: any[] | undefined;

  /**
   * The lifecycle state of the record the requested PATH is about (N-102).
   *
   * A `when: { state: … }` node is judged server-side, so a node whose
   * condition does not hold is absent from the document rather than hidden in
   * it. Judging it needs the record, and the only place the record is named is
   * the path — `/payment/:id`.
   *
   * Three properties, all deliberate:
   *
   *  - **It is a gated read.** The row comes back through the same engine every
   *    other read goes through, as THIS actor, so scope and policy apply. A
   *    record the actor may not read resolves to nothing.
   *  - **Nothing resolved means nothing renders.** A refusal, a missing row and
   *    a page that addresses no record are the same answer: `{}`, and a
   *    conditioned node is absent. Silence about a record must not render the
   *    branch that assumes one.
   *  - **It costs nothing on a page with no condition.** `usesStateCondition`
   *    is asked first, so every page written before this — and every page that
   *    simply does not use the keyword — projects with no extra query.
   *
   * The engine closure is stateless; the CONNECTION is what matters, and this
   * runs on the request adapter rather than the background one.
   */
  /**
   * What a request's path says about the language it should be answered in.
   * `undefined` for an app declaring none, which is what leaves its projection
   * exactly as it was before languages existed.
   */
  const languageFor = (path: string): LocaleContext | undefined => {
    if (!appConfig.languages || !catalogues) return undefined;
    const { locale } = resolveLocale(path, appConfig.languages);
    return { locale: locale!, languages: appConfig.languages, catalogues };
  };

  const statesFor = async (url: URL, actor: Actor | undefined): Promise<Record<string, string | undefined>> => {
    if (!views || !actor) return {};
    // The language prefix names which language, never which page: `/fil/notes/1`
    // is the same route as `/notes/1`, so it is stripped before matching.
    const { path } = resolveLocale(url.pathname, appConfig.languages);
    const raw = views.find((view) => matchRoute(view.route, path));
    if (!raw || !usesStateCondition(raw.node)) return {};
    const modelName = raw.requires;
    const model = typeof modelName === 'string' ? models.get(modelName) : undefined;
    // Cross-checked at boot: a `when` without a stateful model does not load.
    if (!model?.states) return {};
    // The record a page is about is the one its route addresses by `:id`. A
    // conditioned page with no `:id` has no record, so nothing holds.
    const id = matchRoute(raw.route, path)?.id;
    if (!id) return {};
    try {
      const row = (await background.execute(
        {
          actor, op: 'get', model: modelName as string, id, data: {}, query: {},
          meta: { requestId: crypto.randomUUID(), at: new Date().toISOString(), source: 'http' },
        },
        db, 0,
      )) as Record<string, unknown> | undefined;
      const value = row?.[model.states.field];
      return { [modelName as string]: typeof value === 'string' ? value : undefined };
    } catch {
      return {};
    }
  };

  if (!assets && options.distDir) {
    // Views load and validate once; the PROJECTION is built per request, because
    // it is a statement about one actor (§19) — and, where a node is
    // conditioned, about one record.
    views = await loadViews(
      `${options.configDir}/views`, options.components, models, options.componentProps,
      // Only when the caller named the framework's own icons: without them a
      // view drawing a built-in would fail a check it could not satisfy.
      options.builtinIcons
        ? new Set([...Object.keys(icons ?? {}), ...options.builtinIcons])
        : undefined,
      // The default language's keys, so a view naming copy nobody wrote refuses
      // the boot rather than rendering `t:terms.heading` to a reader.
      copyKeys,
    );
    assets = createAssets(
      options.distDir,
      async (actor, url) => projectApp(
        views!, models, actor, options.title, await statesFor(url, actor), icons,
        languageFor(url.pathname),
      ),
      resolveActor,
      themeCss(theme),
      `${options.configDir}/assets`,
      appConfig.publicOrigin,
    );
  }

  const server = serve({
    port: options.port,
    hostname: options.hostname,
    channel: channelRuntime && {
      handlers: channelRuntime.handlers as never,
      async upgrade(request, url, bunServer) {
        const prefix = `/${version}/`;

        // The token endpoint. A POST, so `sameOrigin()` has already refused a
        // cross-site caller before this runs — which is exactly why the token can be
        // minted here and spent on the socket, where that check does not apply.
        if (url.pathname.startsWith(`${prefix}channel-token/`)) {
          if (request.method !== 'POST') return json({ error: 'method_not_allowed' }, 405);
          const target = channelRuntime.parsePath(
            url.pathname.replace(`${prefix}channel-token/`, `${prefix}channel/`), prefix);
          if (!target) return json({ error: 'not_found' }, 404);
          const actor = await resolveActor(request);
          const decision = await channelRuntime.authorizeToken(actor, target);
          if (decision instanceof Response) return decision;
          return json({ token: channelRuntime.mintToken(target.model, target.channel, target.rowId) });
        }

        const target = channelRuntime.parsePath(url.pathname, prefix);
        if (!target) return json({ error: 'not_found', path: url.pathname }, 404);

        const actor = await resolveActor(request);
        const decision = await channelRuntime.authorize(request, url, actor, target);
        if (decision instanceof Response) return decision;
        if (!bunServer.upgrade(request, { data: decision.data })) {
          return json({ error: 'upgrade_failed' }, 400);
        }
        return undefined;   // upgraded
      },
    },
    version,
    auth: createAuthRoutes(authConfig),
    dispatch,
    assets,
    /**
     * The projection, refetchable (S-103).
     *
     * Same headers as the document that carries it, and for the same reason: it
     * is a statement about ONE actor, so a shared cache holding one reader's
     * page set and serving it to another would undo §19. Absent when no UI is
     * configured, exactly like `assets`.
     */
    /**
     * A sitemap is a PUBLIC document, so it is built for the anonymous actor
     * rather than for whoever asked (S-120). One generated per reader would
     * either hand a crawler an administrator's page set or vary per request in
     * a way no crawler expects.
     */
    crawl: views && (({ url }) => {
      // The address a crawler should follow, which is the public one when the
      // app declares it — a sitemap of http URLs for an https site is worse
      // than no sitemap, because it is authoritative and wrong.
      const origin = appConfig.publicOrigin ?? url.origin;
      if (url.pathname === '/robots.txt') {
        return new Response(robotsTxt(origin), { headers: { 'content-type': 'text/plain; charset=utf-8' } });
      }
      const visitor = projectApp(views!, models, ANONYMOUS, options.title);
      return new Response(sitemapXml(visitor.pages, origin, appConfig.languages), {
        headers: { 'content-type': 'application/xml; charset=utf-8' },
      });
    }),
    /**
     * `?path=` is the page being projected, and it is why this endpoint takes a
     * parameter at all.
     *
     * Client routing refetches the projection on every navigation, which is the
     * whole safety argument for routing in place: the server decides what
     * exists, per actor, per request. A conditioned node is also per RECORD, and
     * this endpoint has no document URL to read it from — so the client sends
     * the path it is navigating to. Untrusted, like every other input: it only
     * ever selects which declared route to resolve, and the record behind it is
     * read through the gates.
     */
    appProjection: views && (async ({ request, url }) => {
      const actor = await resolveActor(request);
      // A path, not a URL: `new URL(value, origin)` would happily take an
      // absolute one and resolve it against someone else's host.
      const path = url.searchParams.get('path');
      const states = path?.startsWith('/') ? await statesFor(new URL(path, url.origin), actor) : {};
      // The client sends the path it is navigating to, prefix and all, so the
      // document it gets back is resolved in the language that path names.
      return new Response(
        JSON.stringify(
          projectApp(views!, models, actor, options.title, states, undefined,
            languageFor(path?.startsWith('/') ? path : '/')),
        ),
        { headers: { 'content-type': 'application/json', 'cache-control': 'private, no-store', vary: 'cookie' } },
      );
    }),
  });
  // Anything staged by a request that never committed is swept on the next boot.
  const swept = await files.sweep(0);
  if (swept) console.log(`swept ${swept} orphaned staged upload(s)`);

  // Started after the server, because anything already in `_outbox` from a
  // previous run is due now: a process that died between commit and delivery
  // must deliver on the next boot, which is the point of writing it down.
  outbox.start();
  scheduler.start();
  if (scheduler.declared.length) console.log(`schedules: ${scheduler.declared.join(', ')}`);
  if (appConfig.languages) {
    const { default: fallback, alternates } = appConfig.languages;
    console.log(`languages: ${fallback} (default, bare paths), ${alternates.join(', ')}`);
  }

  return {
    server, models, queries, db, backgroundDb, applied, handlers, files, outbox, scheduler,
    /**
     * Stop serving, and take every channel's process with it.
     *
     * A channel starts a real process, so "the server exited" must not mean "the
     * terminals are still running": an orphaned session holds a pty, the program inside
     * it, and the user's files. Whoever launched the server calls this — a desktop
     * shell, a signal handler, a test.
     */
    shutdown() {
      channelRuntime?.shutdown();
      server.stop(true);
    },
    /** Build a projection for an actor — exposed so tests can assert on it. */
    project: (actor?: Actor) => projectApp(views ?? [], models, actor, options.title),
  };
}
