/**
 * `config/locales/` — the words, per language.
 *
 * A view names a key and the catalogue holds the copy: `title: t:terms.heading`.
 * The indirection buys the one thing a translation layer otherwise cannot have —
 * **boot refuses a key the default language does not define**, the way it
 * already refuses an unknown state, field, icon or prop. Without it, an
 * untranslated page and a typo'd key look identical, and both ship.
 *
 * The default language's file is required and every other is optional: a key an
 * alternate does not carry renders in the default language. So a translation in
 * progress is a running site, not a broken one.
 */
import { ConfigError } from './model.ts';
import { assertNoYamlTraps } from './config/yaml-traps.ts';
import { matchRoute, type LanguageSet } from './routes.ts';

/** What marks a string as a key into the catalogue rather than the copy itself. */
export const COPY_PREFIX = 't:';

/** One language's copy: key to words. */
export type Catalogue = Record<string, string>;
/** Every language's copy, by language tag. */
export type Catalogues = Record<string, Catalogue>;

/** Everything the projection needs to resolve copy for one reader. */
export interface LocaleContext {
  /** The language this document is being resolved in. */
  locale: string;
  /** Every language the app publishes in — the client matches paths with it. */
  languages: LanguageSet;
  /** The copy each language declares. */
  catalogues: Catalogues;
}

const KEY = /^[a-z0-9]+([.-][a-z0-9]+)*$/;

/** The key a value names, or undefined when the value is copy in its own right. */
export const copyKey = (value: string): string | undefined =>
  value.startsWith(COPY_PREFIX) ? value.slice(COPY_PREFIX.length) : undefined;

export function compileCatalogue(raw: unknown, source: string): Catalogue {
  if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) {
    throw new ConfigError(source, 'a locale file is a mapping of key to words');
  }
  const out: Catalogue = {};
  for (const [key, value] of Object.entries(raw as Record<string, unknown>)) {
    if (!KEY.test(key)) {
      throw new ConfigError(source,
        `"${key}" is not a copy key — lowercase words joined by "." or "-", as in "terms.heading"`);
    }
    if (typeof value !== 'string') {
      throw new ConfigError(source, `"${key}" must be a string — copy, not ${JSON.stringify(value)}`);
    }
    out[key] = value;
  }
  return out;
}

/**
 * Reads `config/locales/<tag>.yaml` for every declared language.
 *
 * An app declaring no languages has no catalogue and gets `undefined`, so
 * nothing downstream can start resolving copy because this ran.
 */
export async function loadLocales(
  configDir: string,
  languages: LanguageSet | undefined,
): Promise<Catalogues | undefined> {
  if (!languages) return undefined;
  const dir = `${configDir}/locales`;
  const catalogues: Catalogues = {};

  const read = async (tag: string): Promise<Catalogue | undefined> => {
    const file = Bun.file(`${dir}/${tag}.yaml`);
    if (!(await file.exists())) return undefined;
    const text = await file.text();
    assertNoYamlTraps(text, `locales/${tag}.yaml`);
    return compileCatalogue(Bun.YAML.parse(text), `locales/${tag}.yaml`);
  };

  const fallback = await read(languages.default);
  if (!fallback) {
    throw new ConfigError('app.yaml',
      `languages.default is "${languages.default}", so ${dir}/${languages.default}.yaml has to exist — ` +
      'it is the copy every other language falls back to');
  }
  catalogues[languages.default] = fallback;
  // An alternate with no file is a language nothing has been translated into
  // yet, which renders as the default language rather than as a failure.
  for (const tag of languages.alternates) catalogues[tag] = (await read(tag)) ?? {};
  return catalogues;
}

/** The words for a key, in this language or the one it falls back to. */
export function resolveCopy(key: string, context: LocaleContext): string | undefined {
  return context.catalogues[context.locale]?.[key]
    ?? context.catalogues[context.languages.default]?.[key];
}

/**
 * Rewrites every link to a page so it stays in the language being read.
 *
 * Without this a two-language site is **one page deep**: `/fil/terms` renders
 * in Filipino and its every link points at the bare route, so the first click
 * leaves the language. The default language keeps bare paths, so this is a
 * no-op there — which is also why an app declaring no languages cannot be
 * affected by it.
 *
 * **Only a path that matches a declared route is rewritten.** A link to an
 * asset, a download or another site is left exactly as written: the test is
 * "does this address a page of this app", not "does this look like a path".
 */
export function localiseLinks<T>(document: T, context: LocaleContext, routes: readonly string[]): T {
  if (context.locale === context.languages.default) return document;
  // `/` prefixes to `/fil`, not `/fil/`: one page, one address.
  const prefixed = (path: string) => (path === '/' ? `/${context.locale}` : `/${context.locale}${path}`);
  const isLinkKey = (key: string) => key === 'href' || /Href$/.test(key);

  const walk = (value: unknown, linkHere: boolean): unknown => {
    if (typeof value === 'string') {
      if (!linkHere || !value.startsWith('/')) return value;
      return routes.some((route) => matchRoute(route, value)) ? prefixed(value) : value;
    }
    if (Array.isArray(value)) return value.map((item) => walk(item, linkHere));
    if (value !== null && typeof value === 'object') {
      return Object.fromEntries(
        Object.entries(value).map(([k, v]) => [k, walk(v, isLinkKey(k))]),
      );
    }
    return value;
  };
  return walk(document, false) as T;
}

/**
 * Replaces every `t:` key in a projected document with the words it names.
 *
 * It runs **once, over the finished document**, rather than at each of the 46
 * text-bearing props: the projection has already decided what this actor may
 * see, so walking it catches a page's own `title`, `description` and `nav`
 * alongside every node prop, and a component gaining a text prop needs no
 * change here.
 */
export function translate<T>(document: T, context: LocaleContext): T {
  const walk = (value: unknown): unknown => {
    if (typeof value === 'string') {
      const key = copyKey(value);
      // A key the boot check let through is defined in the default language, so
      // the only way this is undefined is a key in an alternate's file alone.
      return key === undefined ? value : resolveCopy(key, context) ?? value;
    }
    if (Array.isArray(value)) return value.map(walk);
    if (value !== null && typeof value === 'object') {
      return Object.fromEntries(Object.entries(value).map(([k, v]) => [k, walk(v)]));
    }
    return value;
  };
  return walk(document) as T;
}
