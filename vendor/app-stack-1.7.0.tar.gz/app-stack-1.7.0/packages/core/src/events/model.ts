/**
 * `_outbox` — the durable record of something that happened (ARCHITECTURE §16,
 * decision 15; WP-06 W-110).
 *
 * A row here is written **inside the transaction that caused it** and delivered
 * **after that transaction commits**. That ordering is the whole design, and it
 * is what makes "the row was written, so the side effect will happen" true
 * without a distributed transaction: the fact and the intent to act on it
 * commit together, or neither does.
 *
 * It is framework-owned and its name begins with `_`, so generic dispatch
 * refuses it — an outbox row is not something a tenant reads, writes or lists.
 *
 * **`payload` carries ids and names, never row values** (`at` and `model` say
 * what happened; `rowId` says to what). It is stored as plain JSON text beside
 * ciphertext, so a decrypted field written here would undo §8 one row away from
 * the thing it protects — the same rule `_audits.fields` follows. A handler
 * that needs the row fetches it with `ctx.call('get', …)` at DELIVERY time,
 * which re-applies the gates then rather than trusting a snapshot taken when
 * nobody was asking.
 */
import { compileModel, type Model } from '../model.ts';
import type { Row } from '../db/adapter.ts';
import type { Actor, EmittedEvent, Envelope } from '../engine/types.ts';

export const OUTBOX: Model = compileModel({
  $id: 'outbox',
  /**
   * The delivery queue, readable so an operator can answer "is anything stuck"
   * without a database client — attempts, next attempt, last error, delivered.
   *
   * `payload` is `x-internal`. It carries the event's own data, which came from
   * a row whose field policy the reader may not satisfy: exposing it here would
   * route around every gate the write itself passed through.
   */
  'x-dispatch': 'read',
  'x-access': { read: "'admin' in actor.roles || 'platform' in actor.roles" },
  'x-scope': { orgId: 'actor.orgId' },
  type: 'object',
  properties: {
    /** `<model>.<event>` — `note.created`, `note.start`. */
    name: { type: 'string' },
    /** JSON. Ids and names only; see the note above. */
    payload: { type: 'string', 'x-internal': true },
    /** What it was about, for reading the table by eye. */
    model: { type: 'string' },
    rowId: { type: 'string' },
    /** The request that emitted it, so an event joins to its audit rows. */
    requestId: { type: 'string' },
    /**
     * Who caused it. Delivery acts as this actor, so a handler can do exactly
     * what they could have done by hand and no more — the identity is
     * server-assigned when the row is written and read back here, never taken
     * from a payload (§22).
     */
    actorId: { type: 'string' },
    actorRoles: { type: 'string' },
    /** 'pending' | 'delivered' | 'failed' */
    status: { type: 'string' },
    attempts: { type: 'integer' },
    /** ISO. A pending row is due when this is in the past. */
    nextAttemptAt: { type: 'string' },
    /** Why the last attempt failed. Server-side only; never returned to a caller. */
    lastError: { type: 'string' },
    deliveredAt: { type: 'string' },
    /** When the causing request happened, which is the delivery order. */
    at: { type: 'string' },
    /**
     * How many deliveries deep this event is.
     *
     * A handler may emit, and what it emits is delivered in turn, so a rule
     * that reacts to its own effect would otherwise run forever — quietly, in a
     * background loop nobody is watching. Capped for the same reason `ctx.call`
     * is capped at 5, and a row over the cap is `failed` with the reason rather
     * than dropped.
     */
    depth: { type: 'integer' },
  },
  'x-storage': { table: '_outbox', notNull: ['name', 'status'] },
}, 'framework:outbox');

/**
 * One buffered event, as the row that will be written.
 *
 * Here rather than at either call site because there are two — the engine
 * writing what a request emitted, and the worker writing what a listener
 * emitted during delivery — and a second copy of this shape is how the two
 * would come to disagree about what an outbox row means.
 */
export function outboxRow(
  event: EmittedEvent, actor: Actor, meta: Envelope['meta'], at: string,
): Row {
  return {
    orgId: actor.orgId,
    name: event.name,
    payload: JSON.stringify(event.payload),
    model: event.model,
    rowId: event.rowId ?? null,
    requestId: meta.requestId,
    // Server-assigned identity, recorded so delivery can act as the actor who
    // caused this and no one else (§22).
    actorId: actor.id,
    actorRoles: actor.roles.join(','),
    status: 'pending',
    attempts: 0,
    // Due immediately; the worker decides when it gets there.
    nextAttemptAt: at,
    lastError: null,
    deliveredAt: null,
    at,
    depth: meta.chain ?? 0,
  };
}
