/**
 * The outbox worker: deliver what was committed (ARCHITECTURE §16, decision 15;
 * WP-06 W-110).
 *
 * The engine writes `_outbox` rows **inside** the transaction that caused them.
 * This delivers them **after** that transaction commits — and it does so by
 * reading the table on its own connection, which is the reason it needs no
 * signal from the request path and cannot be told a lie about commit: a row it
 * can see is a row that committed. A request that rolled back leaves nothing
 * here to find.
 *
 * That is also what makes the two failure cases behave:
 *
 *   - a rollback takes the event with the write, because they were one write;
 *   - a handler that throws cannot undo anything, because the transaction it
 *     would have rolled back closed before this worker started. The attempt is
 *     counted, the row goes back to `pending` with a later `nextAttemptAt`, and
 *     it is tried again. At-least-once, which is the only honest guarantee
 *     without a distributed transaction.
 *
 * **One process.** Claiming is "read pending, deliver, mark", which is correct
 * while exactly one worker runs and would double-deliver if two did. Making it
 * safe for two means `SELECT … FOR UPDATE SKIP LOCKED` per engine, which is
 * WP-04's adapter work and this package's one stated ask of it. Until then a
 * second instance must not run the worker.
 */
import type { DBAdapter, Row } from '../db/adapter.ts';
import type { Model } from '../model.ts';
import type { HandlerDecl, HandlerRegistry } from '../handlers/index.ts';
import type { ActionContext, Actor, EmittedEvent, Envelope, Query } from '../engine/types.ts';
import { createAuditWriter, type Attempted } from '../engine/audit.ts';
import { OUTBOX, outboxRow } from './model.ts';

/**
 * How many deliveries deep a chain of events may go.
 *
 * Five, like `ctx.call`'s depth cap, and for the same reason: a rule that
 * reacts to its own effect is a loop, and a loop in a background worker is one
 * nobody sees. A row past the cap is `failed` with the reason, never dropped.
 */
export const MAX_EVENT_CHAIN = 5;

/** One bound listener: the handler, and the model whose config declared it. */
export interface EventListener {
  model: Model;
  handler: HandlerDecl;
  where: string;
}

/**
 * Every `x-events` listener in the app, indexed by event name.
 *
 * Built from the models rather than kept as a registration list, so there is
 * one source for "is anyone listening" — the engine asks it to decide whether a
 * builtin event is worth a row, and the worker asks it to decide what to run.
 */
export function eventListeners(models: Map<string, Model>): Map<string, EventListener[]> {
  const index = new Map<string, EventListener[]>();
  for (const model of models.values()) {
    for (const [name, handlers] of Object.entries(model.events)) {
      const bound = index.get(name) ?? [];
      handlers.forEach((handler, i) => bound.push({ model, handler, where: `x-events."${name}"[${i}]` }));
      index.set(name, bound);
    }
  }
  return index;
}

export type ExecuteFn = (
  envelope: Envelope, tx: DBAdapter, depth: number,
) => Promise<unknown>;

export interface OutboxOptions {
  db: DBAdapter;
  models: Map<string, Model>;
  handlers: HandlerRegistry;
  /** The engine's `execute`, so a handler's `ctx.call` passes the same gates. */
  execute: ExecuteFn;
  /** How often to look for due rows. */
  intervalMs?: number;
  /** Give up after this many failed attempts. */
  maxAttempts?: number;
  /** First retry delay; doubles per attempt. */
  baseDelayMs?: number;
  /** Injected so a test can move time without sleeping. */
  now?: () => Date;
}

export interface TickResult {
  delivered: number;
  retried: number;
  failed: number;
}

export function createOutbox(options: OutboxOptions) {
  const {
    db, models, handlers, execute,
    intervalMs = 250, maxAttempts = 5, baseDelayMs = 250, now = () => new Date(),
  } = options;

  const listeners = eventListeners(models);
  /**
   * The same writer the request path uses, so a side effect that happened after
   * the response is as traceable as one that happened during it (W-111).
   *
   * One row per delivery ATTEMPT, carrying `source: 'event'` and the requestId
   * of the request that caused it — so a retry is visible, and an event joins
   * to the request it came from. Nested `ctx.call`s inside a listener are not
   * audited separately, which is the choice the intake already makes for a
   * hook's calls.
   */
  const audit = createAuditWriter(db);
  let timer: ReturnType<typeof setTimeout> | undefined;
  let running = false;

  /** Exponential, capped: 250ms, 500ms, 1s, 2s, 4s. */
  const backoff = (attempts: number) => Math.min(baseDelayMs * 2 ** (attempts - 1), 60_000);

  /**
   * Run one row's listeners on ONE transaction of their own.
   *
   * Their own, and not the caller's, because the caller's is gone — that is
   * what "after commit" means. So a handler that throws rolls back only what
   * this delivery did; the write that caused the event is already durable and
   * nothing here can reach it.
   */
  async function deliver(row: Row): Promise<void> {
    const name = String(row.name);
    const bound = listeners.get(name) ?? [];
    const actor: Actor = {
      id: String(row.actorId ?? ''),
      roles: String(row.actorRoles ?? '').split(',').filter(Boolean),
      orgId: String(row.orgId ?? ''),
    };
    const payload: Row = JSON.parse(String(row.payload || '{}')) as Row;
    const chain = Number(row.depth ?? 0) + 1;
    /**
     * What the listeners themselves emit.
     *
     * Written on the DELIVERY transaction, on the same terms as the engine's:
     * if a listener later in the chain throws, the whole attempt rolls back and
     * the events it had already buffered go with it. So "emitted inside the
     * transaction that caused it" holds one level down too.
     */
    const emitted: EmittedEvent[] = [];
    /**
     * Outbound sends a listener asked for, held until the transaction that
     * resolved them has committed (AUD-087).
     *
     * The row, the recipients and the body are resolved inside the transaction
     * below; the SOCKET runs after it. Before this, a `notify` sent from inside
     * the transaction, which held a database write lock for the length of every
     * SMTP round trip — so a retrying backlog reliably 500'd unrelated writes.
     */
    const sends: Array<() => Promise<void>> = [];

    await db.tx(async (tx) => {
      for (const listener of bound) {
        const handler = handlers.get(listener.handler);
        if (!handler) {
          throw new Error(`${listener.model.name}.${listener.where} was not bound at boot`);
        }
        const meta: Envelope['meta'] = {
          // The request that caused it, so an event's audit rows join to the
          // ones the original request left.
          requestId: String(row.requestId ?? ''),
          at: now().toISOString(),
          source: 'event',
          chain,
        };
        const ctx: ActionContext = {
          actor,
          op: name,
          model: listener.model,
          id: row.rowId ? String(row.rowId) : undefined,
          data: { ...payload },
          query: {} as Query,
          meta,
          scope: {},
          tx,
          /**
           * The one door, again. A listener reaches persistence exactly as a
           * hook does, so it can do what the actor who caused the event could
           * have done by hand and nothing more — the gates run at DELIVERY
           * time, on the row as it is now.
           */
          call: (op, modelName, input = {}) => execute(
            {
              actor, op, model: modelName, id: input.id,
              data: input.data ?? {}, query: input.query ?? {},
              meta: { ...meta, source: 'event' },
            },
            tx, 0,
          ),
          emit: (eventName, eventPayload = {}) => {
            if (typeof eventName !== 'string' || !eventName.includes('.')) {
              throw new Error(`an event name is "<model>.<event>", not "${String(eventName)}"`);
            }
            emitted.push({
              name: eventName,
              payload: { ...eventPayload },
              model: listener.model.name,
              rowId: row.rowId ? String(row.rowId) : undefined,
            });
          },
          log: (...args) => console.log(`[${meta.requestId}] ${name}:`, ...args),
          staged: [],
          removals: [],
          // The outbox is where a `notify` send is deferred out of the
          // transaction (AUD-087). Only this context provides it.
          deferSend: (fn) => sends.push(fn),
        };
        await handler(ctx);
      }
      const at = now().toISOString();
      for (const event of emitted) {
        await tx.systemCreate(OUTBOX, outboxRow(event, actor, {
          requestId: String(row.requestId ?? ''), at, source: 'event', chain,
        }, at));
      }
    });

    /**
     * The socket, OUTSIDE the transaction (AUD-087).
     *
     * The transaction above committed when `db.tx` resolved, so the listeners'
     * own writes and any events they emitted are durable before the first byte
     * of an SMTP conversation. A send that fails here propagates to `tick`,
     * which counts the attempt and schedules a retry — the documented
     * at-least-once guarantee, and the reason the send still throws rather than
     * swallowing a dead relay.
     */
    for (const send of sends) await send();
  }

  /**
   * One pass over what is due.
   *
   * Each row is independent: one that fails must not stop the ones behind it,
   * or a single bad listener would stall every event in the system.
   */
  async function tick(): Promise<TickResult> {
    const result: TickResult = { delivered: 0, retried: 0, failed: 0 };
    if (running) return result;
    running = true;
    try {
      const at = now().toISOString();
      const pending = await db.systemList(OUTBOX, { status: 'pending' });
      const due = pending
        .filter((row) => String(row.nextAttemptAt ?? '') <= at)
        .sort((a, b) => String(a.at ?? '').localeCompare(String(b.at ?? '')));

      for (const row of due) {
        const id = String(row.id);
        const attempts = Number(row.attempts ?? 0) + 1;

        if (Number(row.depth ?? 0) > MAX_EVENT_CHAIN) {
          await db.systemUpdate(OUTBOX, id, {
            status: 'failed', attempts,
            lastError: `event chain exceeded ${MAX_EVENT_CHAIN} deliveries`,
          });
          console.error(`[outbox] ${row.name} exceeded ${MAX_EVENT_CHAIN} deliveries — a listener is reacting to its own effect`);
          result.failed++;
          continue;
        }

        const attempted: Attempted = {
          actor: {
            id: String(row.actorId ?? ''),
            roles: String(row.actorRoles ?? '').split(',').filter(Boolean),
            orgId: String(row.orgId ?? ''),
          },
          op: String(row.name),
          model: String(row.model ?? '-'),
          id: row.rowId ? String(row.rowId) : undefined,
          data: JSON.parse(String(row.payload || '{}')),
          meta: { requestId: String(row.requestId ?? ''), at: now().toISOString(), source: 'event' },
        };

        try {
          await deliver(row);
          await db.systemUpdate(OUTBOX, id, {
            status: 'delivered', attempts, deliveredAt: now().toISOString(), lastError: null,
          });
          await audit({ envelope: attempted, status: 200, detail: `delivered on attempt ${attempts}` });
          result.delivered++;
        } catch (error) {
          /**
           * The database was busy, not the listener wrong.
           *
           * This worker has its own connection and still contends with the
           * request path for the file. Spending one of five attempts on a
           * moment's contention would eventually mark a perfectly good event
           * `failed` for a reason that has nothing to do with it, so the row is
           * left untouched and the next pass takes it. The lasting answer is a
           * busy timeout, which lives in `db/**`.
           */
          if (/database is locked|database table is locked|busy|cannot start a transaction/i
            .test(String((error as Error)?.message ?? error))) {
            continue;
          }
          const detail = (error as Error).message ?? String(error);
          await audit({
            envelope: attempted, status: 500, outcome: 'error',
            detail: `attempt ${attempts} failed: ${detail}`,
          });
          if (attempts >= maxAttempts) {
            await db.systemUpdate(OUTBOX, id, { status: 'failed', attempts, lastError: detail });
            result.failed++;
            console.error(`[outbox] ${row.name} gave up after ${attempts} attempt(s): ${detail}`);
          } else {
            await db.systemUpdate(OUTBOX, id, {
              status: 'pending', attempts, lastError: detail,
              nextAttemptAt: new Date(now().getTime() + backoff(attempts)).toISOString(),
            });
            result.retried++;
            console.warn(`[outbox] ${row.name} attempt ${attempts} failed, retrying: ${detail}`);
          }
        }
      }
    } finally {
      running = false;
    }
    return result;
  }

  /**
   * Arm the next pass.
   *
   * A tick that throws — the database is briefly locked, say — must not stop
   * the worker: every row it did not reach is still `pending` and still due, so
   * the next pass picks it up. The loop's own survival is the retry.
   */
  function arm(delay: number) {
    clearTimeout(timer);
    timer = setTimeout(() => {
      tick().catch((error) => console.error('[outbox] tick failed:', error)).finally(() => arm(intervalMs));
    }, delay);
    // Do not hold the process open for a background poller.
    (timer as { unref?: () => void }).unref?.();
  }

  return {
    tick,
    start() { arm(intervalMs); },
    stop() { clearTimeout(timer); timer = undefined; },
    /**
     * Ask for a pass sooner than the interval.
     *
     * An optimisation and nothing more: correctness is the interval, and the
     * worker delivers whether or not anybody nudges it. It exists because a
     * user watching a screen should not wait a full interval for an effect the
     * server already committed.
     */
    nudge() { if (timer) arm(5); },
  };
}

export type Outbox = ReturnType<typeof createOutbox>;
