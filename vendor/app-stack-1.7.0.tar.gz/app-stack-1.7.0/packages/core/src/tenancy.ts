/**
 * Which scope key means *tenancy* (Q-124, decided 2026-09-14).
 *
 * **There is no `x-tenant:` model keyword, and there should not be.** Which org
 * a row belongs to is DATA, not structure: it is a value the server assigns per
 * actor per request, so the model cannot name it and stay true. That is what
 * `x-scope` is for and why it holds JEXL — scoping is resolved dynamically, per
 * actor, and the declaration says how to derive the value rather than what the
 * value is.
 *
 * So the tenant key is recognised, not declared. `x-scope` is a map of column
 * to expression, and a key is the tenant key when its expression is a bare read
 * of the actor's org identity — the one value that is server-assigned (§22)
 * rather than a property of the row or the request. `{ ownerId: actor.id }` is
 * an equally valid scope key and must keep NARROWING a read rather than widening
 * with it, which is the whole reason the two have to be told apart.
 *
 * Recognition goes through JEXL's own parser (`readPath`), not through string
 * equality on the config text. `actor.orgId` and `actor["orgId"]` are one read
 * written two ways and now classify identically; the previous string compare
 * made them disagree, and the disagreement was silent on the safe side only by
 * luck.
 *
 * Three outcomes, because there are three cases:
 *
 *  - **tenant** — a bare read of `actor.orgId`. A cross-tenant read widens it.
 *  - **derived** — an expression that READS `actor.orgId` and then computes over
 *    it (`actor.orgId + '-shard'`, `actor.orgId|lower`). Neither safely widened
 *    (the bound values would be wrong) nor safely left alone (it pins the read
 *    to this actor's tenant while the query claims to span tenants). A
 *    cross-tenant query naming such a model is refused at boot.
 *  - **neither** — `actor.id`, a literal, anything reading `row`. An ordinary
 *    narrowing key, left exactly as it was.
 *
 * The derived case is the failure this file's own notes called out as
 * unacceptable — "the author would assume it had widened" — and it was
 * undetectable while the check was a string compare. It is detectable now.
 */
import { mentionsPath, readPath } from './expressions.ts';
import type { Model } from './model.ts';

/**
 * The path a tenant scope expression reads. Canonical spelling, used in boot
 * messages; it is NOT matched as text — see `classify`.
 */
export const TENANT_EXPRESSION = 'actor.orgId';

interface Classified {
  /** Scope keys that carry server-assigned tenancy. Widened by a cross-tenant read. */
  tenant: string[];
  /** Scope keys derived FROM tenancy without being it. Refused in a cross-tenant query. */
  derived: string[];
}

/** Keyed by the Model object, like every other compiled cache here. */
const cache = new WeakMap<Model, Classified>();

function classify(model: Model): Classified {
  const cached = cache.get(model);
  if (cached) return cached;

  const out: Classified = { tenant: [], derived: [] };
  for (const [column, expression] of Object.entries(model.scope)) {
    const where = `${model.name}.x-scope.${column}`;
    const path = readPath(expression, where);

    if (path === TENANT_EXPRESSION) { out.tenant.push(column); continue; }

    /**
     * `readPath` answers `undefined` both for a computation and for a JEXL build
     * that stopped exposing its AST. Only the first is interesting, and the
     * second must not silently reclassify a working app's scope keys — so fall
     * back to the comparison this file used to make. It agrees with the parser
     * on the spelling every existing model uses.
     */
    if (path === undefined && expression.trim() === TENANT_EXPRESSION) {
      out.tenant.push(column);
      continue;
    }
    if (path === undefined && mentionsPath(expression, TENANT_EXPRESSION, where)) {
      out.derived.push(column);
    }
  }

  cache.set(model, out);
  return out;
}

/** Scope keys of this model that carry server-assigned tenancy. */
export function tenantScopeKeys(model: Model): string[] {
  return classify(model).tenant;
}

/**
 * Scope keys that derive from tenancy without being it.
 *
 * Non-empty means a cross-tenant read over this model cannot be honest, so the
 * query compiler refuses it by name rather than widening around it.
 */
export function tenancyDerivedScopeKeys(model: Model): string[] {
  return classify(model).derived;
}

/**
 * Widen a resolved scope across the given tenants, leaving every other key
 * exactly as it was — an `ownerId` key still narrows to this actor.
 *
 * The tenant list is never empty by the time it reaches here (the caller refuses
 * first), but an empty one would still read as "no tenants": the adapter binds an
 * empty scope list to `1 = 0`.
 */
export function widenScope(
  model: Model, scope: Record<string, unknown>, tenants: readonly string[],
): Record<string, unknown> {
  const keys = tenantScopeKeys(model);
  if (keys.length === 0) return scope;
  const out = { ...scope };
  for (const key of keys) {
    if (key in out) out[key] = { in: [...tenants] };
  }
  return out;
}
