/**
 * The one expression language (ARCHITECTURE §11, §12).
 *
 * JEXL, compiled at boot, evaluated against frozen plain data. Gates use it,
 * and so do declarative hooks and actions — deliberately the same language, so
 * an author who can read `x-access` can read `x-hooks` without learning a
 * second grammar, and there is one place where "what an expression may do" is
 * decided.
 *
 * **Transforms** are §12's fourth kind of handler: pure, value in, value out,
 * running inside the expression. They are the common normalisations that used
 * to need a `.ts` file each (WP-02 H-111). They are registered on the shared
 * instance here so registration cannot race a compile: every module that
 * compiles an expression imports `jexl` from this file.
 *
 * A transform is deliberately forgiving about type: `input.title|trim` on a
 * payload that never carried a title must yield `undefined`, not throw, because
 * a hook declared for `beforeUpdate` sees whatever fields that request sent.
 */
import jexl from 'jexl';

const asString = (value: unknown): value is string => typeof value === 'string';

/** Leading and trailing whitespace removed. */
jexl.addTransform('trim', (value: unknown) => (asString(value) ? value.trim() : value));
/** Every run of whitespace becomes one space. Pair with `trim`. */
jexl.addTransform('collapseWhitespace', (value: unknown) => (asString(value) ? value.replace(/\s+/g, ' ') : value));
/** Lower case, for comparison and for case-insensitive storage. */
jexl.addTransform('lower', (value: unknown) => (asString(value) ? value.toLowerCase() : value));

/** The transforms an author may use. Named so a boot error can list them. */
export const TRANSFORMS = ['trim', 'collapseWhitespace', 'lower'] as const;

/**
 * Refuse an unknown transform at boot.
 *
 * JEXL resolves a transform when the expression RUNS, not when it compiles, so
 * `input.title|trimm` compiles perfectly and throws on the first request that
 * reaches it — exactly the silence §13's boot checks exist to prevent. The
 * compiled AST marks each one with `pool: 'transforms'`, so the names are
 * readable before anything has been served.
 *
 * `_getAst` is JEXL's own internal, so this is best-effort by construction: if
 * a future version stops exposing it the check goes quiet rather than failing
 * every boot. It is a papercut guard, not a security boundary — nothing
 * downstream may assume it ran.
 */
function usedTransforms(compiled: unknown, found: Set<string> = new Set()): Set<string> {
  const ast = (compiled as { _getAst?: () => unknown })._getAst?.() ?? (compiled as { _ast?: unknown })._ast;
  const walk = (node: unknown) => {
    if (!node || typeof node !== 'object') return;
    if (Array.isArray(node)) { for (const child of node) walk(child); return; }
    const record = node as Record<string, unknown>;
    if (record.pool === 'transforms' && typeof record.name === 'string') found.add(record.name);
    for (const value of Object.values(record)) walk(value);
  };
  walk(ast);
  return found;
}

/**
 * The AST JEXL compiled, or `undefined` if this build stopped exposing it.
 *
 * `_getAst` is JEXL's own internal. Every caller here treats `undefined` as "I
 * could not tell" and falls back to something safe rather than guessing, so a
 * future version of the library degrades behaviour it cannot silently corrupt.
 */
function astOf(compiled: unknown): unknown {
  return (compiled as { _getAst?: () => unknown })._getAst?.() ?? (compiled as { _ast?: unknown })._ast;
}

/**
 * The identifier path an expression reads, if reading one is ALL it does.
 *
 * `actor.orgId` and `actor["orgId"]` both answer `"actor.orgId"` — the same
 * read, written twice. Anything that computes over a value answers `undefined`:
 * `actor.orgId + '-x'` is a binary expression, `actor.orgId|lower` is a
 * transform call, `'eu'` is a literal. So is a dynamic subscript
 * (`actor[whatever]`), because what it reads is not knowable until it runs.
 *
 * This exists so config can be classified by what it MEANS rather than by how
 * it was typed. `tenancy.ts` is the caller that matters: it has to decide which
 * scope key carries server-assigned tenancy, and comparing the raw string
 * against `"actor.orgId"` made two spellings of one read disagree.
 */
export function readPath(expression: string, where: string): string | undefined {
  const ast = astOf(compileExpression(expression, where));
  if (!ast) return undefined;

  const segments: string[] = [];
  let node = ast as Record<string, unknown> | undefined;

  while (node) {
    if (node.type === 'Identifier' && typeof node.value === 'string') {
      segments.unshift(node.value);
      node = node.from as Record<string, unknown> | undefined;
      continue;
    }
    // `actor["orgId"]` — a subscript, but only a knowable one: the key must be
    // a literal, and a RELATIVE filter (`.[…]`) selects within a collection
    // rather than reading a property, so it is not a path at all.
    if (node.type === 'FilterExpression' && node.relative === false) {
      const key = node.expr as Record<string, unknown> | undefined;
      if (key?.type !== 'Literal' || typeof key.value !== 'string') return undefined;
      segments.unshift(key.value);
      node = node.subject as Record<string, unknown> | undefined;
      continue;
    }
    return undefined;
  }

  return segments.length ? segments.join('.') : undefined;
}

/** Whether an expression reads this path ANYWHERE inside it, computation included. */
export function mentionsPath(expression: string, path: string, where: string): boolean {
  const ast = astOf(compileExpression(expression, where));
  if (!ast) return false;

  let found = false;
  const walk = (node: unknown) => {
    if (found || !node || typeof node !== 'object') return;
    if (Array.isArray(node)) { for (const child of node) walk(child); return; }
    const record = node as Record<string, unknown>;
    // Re-render each node as a path and compare: one rule for both spellings.
    if (record.type === 'Identifier' || record.type === 'FilterExpression') {
      const segments: string[] = [];
      let cursor: Record<string, unknown> | undefined = record;
      let bare = true;
      while (cursor && bare) {
        if (cursor.type === 'Identifier' && typeof cursor.value === 'string') {
          segments.unshift(cursor.value);
          cursor = cursor.from as Record<string, unknown> | undefined;
        } else if (cursor.type === 'FilterExpression' && cursor.relative === false) {
          const key = cursor.expr as Record<string, unknown> | undefined;
          if (key?.type !== 'Literal' || typeof key.value !== 'string') { bare = false; break; }
          segments.unshift(key.value);
          cursor = cursor.subject as Record<string, unknown> | undefined;
        } else { bare = false; }
      }
      if (bare && segments.join('.') === path) { found = true; return; }
    }
    for (const value of Object.values(record)) walk(value);
  };
  walk(ast);
  return found;
}

export type Compiled = { evalSync(context: unknown): unknown };

/**
 * Compile now so a broken expression fails startup, not a request. `where`
 * names the declaration, because the author's next move is to go and fix it.
 */
export function compileExpression(expression: string, where: string): Compiled {
  let compiled: Compiled;
  try {
    compiled = jexl.compile(expression);
  } catch (error) {
    throw new Error(`${where}: invalid expression "${expression}" — ${(error as Error).message}`);
  }
  for (const name of usedTransforms(compiled)) {
    if (!(TRANSFORMS as readonly string[]).includes(name)) {
      throw new Error(
        `${where}: expression "${expression}" uses unknown transform "${name}" — ` +
        `available: ${TRANSFORMS.join(', ')}`,
      );
    }
  }
  return compiled;
}

export { jexl };
