/**
 * Route patterns, shared by the server and the browser (WP-07 S-120).
 *
 * `/notes/:id` matches `/notes/abc`, yielding `{ id: 'abc' }`.
 *
 * It lived in `packages/ui/src/createAppStack.ts` and was the client's alone
 * while only the client routed. Server-rendered `<title>`, `<meta
 * name="description">` and `<link rel="canonical">` need the same answer for
 * the same path — a crawler is not going to run `createAppStack` — and two
 * matchers that agreed by coincidence would be exactly the "parallel duplicate
 * implementations" the reset was called for.
 *
 * **Nothing here touches a Bun API**, deliberately: `@appstack/core/routes` is
 * imported by the browser bundle, and the rest of this package is not
 * importable there.
 */

/** Matched params, or undefined when the pattern does not describe this path. */
export function matchRoute(pattern: string, path: string): Record<string, string> | undefined {
  const patternParts = pattern.split('/').filter(Boolean);
  const pathParts = path.split('/').filter(Boolean);
  if (patternParts.length !== pathParts.length) return undefined;
  const params: Record<string, string> = {};
  for (const [i, part] of patternParts.entries()) {
    if (part.startsWith(':')) params[part.slice(1)] = decodeURIComponent(pathParts[i]!);
    else if (part !== pathParts[i]) return undefined;
  }
  return params;
}

/**
 * The languages an app publishes in, as `routes` needs them. Structural rather
 * than imported from `app-config.ts`, which reaches for Bun — see the note
 * above: this module is in the browser bundle and the rest of the package is
 * not.
 */
export interface LanguageSet {
  readonly default: string;
  readonly alternates: readonly string[];
  /** How each language names itself. Absent: the tag, uppercased. */
  readonly labels?: Readonly<Record<string, string>>;
}

/** Every language an app publishes in, the default first. */
export const languageTags = (languages: LanguageSet): string[] =>
  [languages.default, ...languages.alternates];

/**
 * Every address one route is published at — one per language, the default bare
 * and every alternate prefixed. An app declaring no languages has exactly one.
 *
 * It answers two questions with one rule: what the `hreflang` alternates are,
 * and where a language picker sends the reader. Those must not disagree.
 */
export function addressesOf(route: string, languages?: LanguageSet): string[] {
  if (!languages) return [route];
  // `/` prefixes to `/fil`, not `/fil/`: one page, one address.
  return [route, ...languages.alternates.map((tag) => (route === '/' ? `/${tag}` : `/${tag}${route}`))];
}

/**
 * Splits a request path into the language it names and the path beneath it.
 *
 * **Only an alternate is a prefix.** The default language keeps bare paths, so
 * `/about` is the English page and `/fil/about` is the Filipino one — which
 * means adding a language to a live site changes no address that already
 * exists, and every page still has exactly one.
 *
 * An app declaring no languages gets its path back and no locale, so nothing
 * downstream can start behaving differently because the function was called.
 */
export function resolveLocale(
  path: string,
  languages?: LanguageSet,
): { locale?: string; path: string } {
  if (!languages) return { path };
  const parts = path.split('/').filter(Boolean);
  const first = parts[0];
  if (first !== undefined && languages.alternates.includes(first)) {
    return { locale: first, path: `/${parts.slice(1).join('/')}` };
  }
  return { locale: languages.default, path };
}
