/**
 * The single seam for secret material (ARCHITECTURE §10).
 *
 * Callers name only the variable. `NAME_FILE` means the value was mounted by the
 * orchestrator (Docker/K8s convention), so the secret never appears in the
 * environment or in a process listing.
 */
const cache = new Map<string, string>();

export class SecretError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'SecretError';
  }
}

export interface SecretOptions {
  /** Where to look. Defaults to the process environment. */
  env?: Record<string, string | undefined>;
  /** Return undefined instead of throwing when absent. */
  optional?: boolean;
}

function readFileSync(path: string): string {
  // Bun.file() is async; secrets resolve once at boot, so a sync read is correct here.
  return require('node:fs').readFileSync(path, 'utf8');
}

/** Resolve a secret. Throws at boot rather than at first request. */
export function secret(name: string, options: SecretOptions = {}): string {
  const cached = cache.get(name);
  if (cached !== undefined && !options.env) return cached;

  const env = options.env ?? (process.env as Record<string, string | undefined>);
  const inline = env[name];
  const fileVar = `${name}_FILE`;
  const path = env[fileVar];

  const hasInline = inline !== undefined && inline !== '';
  const hasPath = path !== undefined && path !== '';

  // Ambiguity is a deployment bug, not something to silently resolve.
  if (hasInline && hasPath) {
    throw new SecretError(`both ${name} and ${fileVar} are set; set exactly one`);
  }

  let value: string | undefined;

  if (hasPath) {
    let contents: string;
    try {
      contents = readFileSync(path!);
    } catch (error) {
      // Report the source, never the value.
      throw new SecretError(`${fileVar} points at ${path}, which could not be read: ${(error as NodeJS.ErrnoException).code ?? 'unknown error'}`);
    }
    value = contents.replace(/\r?\n$/, '');
  } else if (hasInline) {
    value = inline;
  }

  // An empty value or an empty file is missing, not an empty secret.
  if (value === undefined || value === '') {
    if (options.optional) return undefined as unknown as string;
    throw new SecretError(
      `${name} is not set (provide ${name}, or ${fileVar} pointing at a file containing it)`,
    );
  }

  if (!options.env) cache.set(name, value);
  return value;
}

/** Rejects config that carries literal secret material instead of a reference. */
export function assertNoLiteralSecrets(config: unknown, where: string): void {
  const suspicious = /-----BEGIN [A-Z ]*PRIVATE KEY-----|^[A-Za-z0-9+/]{40,}={0,2}$/;
  const walk = (node: unknown, path: string) => {
    if (typeof node === 'string' && suspicious.test(node.trim())) {
      throw new SecretError(`${where}${path}: looks like literal secret material; use secretRef instead`);
    }
    if (Array.isArray(node)) node.forEach((v, i) => walk(v, `${path}[${i}]`));
    else if (node && typeof node === 'object') {
      for (const [k, v] of Object.entries(node)) walk(v, `${path}.${k}`);
    }
  };
  walk(config, '');
}
