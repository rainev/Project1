/** HTTP surface. One dispatch route for every model, plus health. */

export interface RouteContext {
  request: Request;
  url: URL;
  /**
   * The SOCKET address, for rate limiting (§22). Passed rather than derived
   * inside a handler because only the server holds it — and it is deliberately
   * not `X-Forwarded-For`, which a caller controls. Behind a proxy this is the
   * proxy, which is the honest answer until a trusted-proxy configuration
   * exists.
   */
  client?: { address: string };
}

export type Handler = (ctx: RouteContext) => Promise<Response> | Response;

export interface ServeOptions {
  port: number;
  /**
   * The interface to listen on. **Bun binds every interface when this is unset**, and
   * reports `hostname === "localhost"` while doing it — measured 2026-09-20: `lsof`
   * showed `TCP *:<port>` and the machine's LAN address answered. Reading the API's own
   * field would have confirmed the opposite of the truth, so anything that must stay on
   * the machine has to pass `127.0.0.1` here and check with `lsof`, not with the server
   * object.
   */
  hostname?: string;
  version: string;
  /**
   * Handles /<version>/auth/*. Returns undefined when the path is not an auth route.
   *
   * `client` carries the SOCKET address, for rate limiting (§22). It is passed
   * rather than derived inside the handler because only the server holds it —
   * and it is deliberately not `X-Forwarded-For`, which a caller controls.
   */
  auth?: (request: Request, url: URL, client?: { address: string }) => Promise<Response | undefined>;
  /**
   * Handles /<version>/app — this actor's projection, as JSON (WP-07 S-103).
   *
   * The same value the document carries, on an endpoint, so client-side
   * navigation can refetch it instead of freezing whatever was baked in at
   * first paint. It is deliberately NOT part of generic dispatch: the
   * projection is not a model, and `/v0/<action>/<model>` is for models.
   */
  appProjection?: Handler;
  /** Handles /<version>/<action>/<model>/<id?>. Absent until the dispatcher exists. */
  dispatch?: Handler;
  /** Serves the UI bundle. Absent until the UI exists. */
  assets?: Handler;
  /** `/sitemap.xml` and `/robots.txt` — public, and built for a visitor (S-120). */
  crawl?: Handler;
  /**
   * Duplex channels (`x-channels`): `/<version>/channel/...` and its token endpoint.
   *
   * A sixth slot rather than part of `dispatch`, for the reason `appProjection` is its
   * own: a socket is not `/v0/<action>/<model>`, and the upgrade needs the `Server` to
   * hand the connection over. Absent when no model declares a channel — the framework
   * opens no listener it was not asked for.
   */
  channel?: {
    upgrade: (request: Request, url: URL, server: import('bun').Server) => Promise<Response | undefined>;
    handlers: import('bun').WebSocketHandler<any>;
  };
}

export function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json' },
  });
}


/** State-changing methods; a GET is not a CSRF risk worth a check. */
const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

/**
 * `SameSite=Lax` already blocks the cross-site POST, and this is the second half
 * of that answer (ARCHITECTURE §15): a same-origin check on anything that
 * changes state, so a browser that mis-handles SameSite — or a non-browser
 * client replaying a stolen cookie from a page we do not control — is refused.
 *
 * `Sec-Fetch-Site` is the precise signal and every current browser sends it.
 * `Origin` is the fallback. A request carrying neither is same-origin or not a
 * browser at all, and is allowed: rejecting it would break curl and every
 * server-to-server caller.
 */
export function sameOrigin(request: Request, url: URL): boolean {
  if (SAFE_METHODS.has(request.method)) return true;

  const site = request.headers.get('sec-fetch-site');
  if (site) return site === 'same-origin' || site === 'none';

  const origin = request.headers.get('origin');
  if (!origin) return true;
  try {
    return new URL(origin).origin === url.origin;
  } catch {
    return false;
  }
}

export function serve(options: ServeOptions) {
  const prefix = `/${options.version}/`;

  return Bun.serve({
    port: options.port,
    ...(options.hostname ? { hostname: options.hostname } : {}),
    ...(options.channel ? { websocket: options.channel.handlers } : {}),
    async fetch(request, server) {
      const url = new URL(request.url);
      // Bun gives the peer address; behind a proxy this is the proxy, which is
      // the honest answer until a trusted-proxy configuration exists.
      const address = server?.requestIP?.(request)?.address;
      const client = address ? { address } : undefined;

      if (url.pathname.startsWith(prefix) && !sameOrigin(request, url)) {
        return json({ error: 'forbidden', detail: 'cross-site request refused' }, 403);
      }

      if ((url.pathname === '/sitemap.xml' || url.pathname === '/robots.txt') && options.crawl) {
        return options.crawl({ request, url, client });
      }

      if (url.pathname === '/health') {
        return json({ status: 'ok', version: options.version });
      }

      if (url.pathname.startsWith(`${prefix}auth/`) && options.auth) {
        const response = await options.auth(request, url, client);
        if (response) return response;
      }

      // Before dispatch: a channel path is not `/v0/<action>/<model>`, and an upgrade
      // must not be mistaken for one.
      if (options.channel && url.pathname.startsWith(`${prefix}channel`)) {
        const handled = await options.channel.upgrade(request, url, server!);
        if (handled) return handled;
        return undefined as unknown as Response;   // upgraded: Bun owns the socket now
      }

      if (url.pathname === `${prefix}app` && options.appProjection) {
        return options.appProjection({ request, url });
      }

      if (url.pathname.startsWith(prefix) && options.dispatch) {
        return options.dispatch({ request, url, client });
      }

      if (options.assets) return options.assets({ request, url, client });

      return json({ error: 'not_found', path: url.pathname }, 404);
    },
  });
}
