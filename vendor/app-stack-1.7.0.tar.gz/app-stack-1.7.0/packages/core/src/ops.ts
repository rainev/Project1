/**
 * The operation vocabulary: what generic dispatch implements, what a hook can
 * bind to, and how a lifecycle point is spelled (ARCHITECTURE §3, §12).
 *
 * Its own file because three layers need it and none of them owns it: the model
 * compiler refuses a hook bound to a point nothing fires and a declarative
 * `call` naming an op that does not exist, the engine runs the switch, and the
 * intake routes. Keeping it here is what lets the model compiler and the engine
 * agree without importing each other.
 */

/** Operations generic dispatch implements itself. Anything else must be declared. */
export const BUILTIN_OPS = new Set(['create', 'get', 'list', 'update', 'delete', 'schema', 'count', 'aggregate', 'history']);

/** The built-ins that change a row. A model declaring `x-dispatch: read` refuses these. */
export const WRITE_OPS = new Set(['create', 'update', 'delete']);

/**
 * Operations the dispatcher runs hooks around. A hook point is `before`/`after`
 * plus one of these, or plus a declared `x-action`.
 *
 * This list is what makes an unfired hook a boot error instead of silence, so it
 * has to stay in step with the dispatcher's switch: a point listed here that the
 * dispatcher does not fire binds a handler that never runs, which is the silence
 * this check exists to prevent.
 */
export const HOOKED_OPS = ['create', 'update', 'delete'] as const;

/**
 * The events generic dispatch emits by itself, one per writing operation
 * (§12, WP-06 W-112). A custom action — and therefore every declared
 * transition — emits its own name instead, so `note.start` is an event exactly
 * as `note.created` is.
 *
 * Here rather than in `events/` for the reason the rest of this file is here:
 * the model compiler refuses an `x-events` key naming something nothing emits,
 * and the engine is what emits it. Neither owns the vocabulary.
 */
export const BUILTIN_EVENTS = ['created', 'updated', 'deleted'] as const;

/** The event one builtin operation emits, or `undefined` if it emits none. */
export const eventFor = (op: string): string | undefined =>
  op === 'create' ? 'created' : op === 'update' ? 'updated' : op === 'delete' ? 'deleted' : undefined;

/**
 * The lifecycle point a hook binds to: `before` or `after` plus the operation,
 * capitalised. One builder, used by the compiler's validation and the engine's
 * runner, so the two cannot drift (AUD-046).
 */
export const hookPoint = (prefix: 'before' | 'after', op: string) =>
  `${prefix}${op.charAt(0).toUpperCase()}${op.slice(1)}`;
