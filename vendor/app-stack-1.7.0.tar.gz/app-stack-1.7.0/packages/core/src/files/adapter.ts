/** File bytes live behind their own seam, mirroring the database adapter. */
export interface FileDescriptor {
  id: string;
  name: string;
  size: number;
  contentType: string;
  /** SHA-256 of the PLAINTEXT, so integrity is verifiable against the original. */
  checksum: string;
  /**
   * The key id the bytes were sealed with, so rotation never orphans a file —
   * the same role `kid` plays in a field's ciphertext envelope (§8). Absent on
   * descriptors written before encryption existed, which read back as plaintext.
   */
  kid?: string;
}

export interface FileAdapter {
  /** Write to a staging area; the row is not committed yet. */
  stage(orgId: string, file: File): Promise<FileDescriptor>;
  /**
   * The descriptor this adapter recorded when it staged those bytes, or
   * undefined if the tenant has nothing staged under that id.
   *
   * `POST /v0/stage` hands the descriptor to a browser, and a browser may send
   * back anything — so the value that reaches a row is read from here, never
   * from the request (WP-02 H-122).
   */
  describeStaged(orgId: string, id: string): Promise<FileDescriptor | undefined>;
  /** Promote staged bytes once the transaction has committed. */
  finalise(orgId: string, id: string): Promise<void>;
  /** Discard staged bytes for a transaction that rolled back. */
  discard(orgId: string, id: string): Promise<void>;
  /** `kid` comes from the descriptor, so rotated keys still open old files. */
  read(orgId: string, id: string, kid?: string): Promise<ReadableStream | undefined>;
  /**
   * Re-seal stored bytes under the ACTIVE key, given the key id they carry
   * now, and answer with the new one (WP-04 E-122).
   *
   * A key is only retired once nothing still needs it, and a field rotation
   * that left uploaded bytes behind would make that untrue while looking done.
   * Undefined means there was nothing to do — no bytes, or an adapter holding
   * plaintext.
   */
  reseal(orgId: string, id: string, kid?: string): Promise<string | undefined>;
  /** Delete stored bytes. Called after a delete has committed, never before. */
  remove(orgId: string, id: string): Promise<void>;
  /** Remove stage leftovers older than the cutoff. */
  sweep(olderThanMs: number): Promise<number>;
}
