/**
 * Byte verification for uploads (AUD-069, §22).
 *
 * `x-upload.accept` is an allowlist of media types, but until WP-11 the type it
 * was matched against came from the CALLER: `File.type` on a multipart part is
 * whatever the client put in the part's `Content-Type` header. So a payload
 * announced as `image/png` was stored under that type and later SERVED under
 * it, because `files/local.ts` records the declared type on the descriptor and
 * `GET /v0/file/...` streams it back with that `Content-Type`.
 *
 * The fix is to read the leading bytes and refuse a file whose content does not
 * agree with what it claims to be. Two directions, and both are needed:
 *
 *   1. The declared type has a known signature — the bytes must carry it.
 *      (A PNG announced as `application/pdf`: no `%PDF-`, refused.)
 *   2. The declared type has NO known signature, i.e. it is a textual type the
 *      table cannot pin down — then the bytes must not carry some OTHER known
 *      signature. (PNG bytes announced as `text/plain`, refused, because the
 *      content is demonstrably a format the declaration denies.)
 *
 * A type this table does not know, carrying bytes this table cannot identify,
 * is accepted: the table's job is to catch a contradiction it can prove, not to
 * become a second allowlist. `accept` remains the allowlist.
 */

/** The longest prefix any signature below needs. */
const PREFIX_BYTES = 32;

interface Signature {
  /** Bytes that must appear at `offset`. */
  readonly magic: readonly number[];
  readonly offset: number;
  /** Bytes that must also appear further in, for container formats like RIFF. */
  readonly also?: { readonly magic: readonly number[]; readonly offset: number };
}

const ascii = (text: string): number[] => [...text].map((c) => c.charCodeAt(0));

/**
 * One entry per media type `x-upload.accept` can name and this table can prove.
 * Several types share a signature — every OOXML document is a zip — which is
 * why a type maps to a LIST: any one matching is agreement.
 */
const SIGNATURES: Record<string, readonly Signature[]> = {
  'image/png': [{ magic: [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a], offset: 0 }],
  'image/jpeg': [{ magic: [0xff, 0xd8, 0xff], offset: 0 }],
  'image/gif': [
    { magic: ascii('GIF87a'), offset: 0 },
    { magic: ascii('GIF89a'), offset: 0 },
  ],
  'image/webp': [{ magic: ascii('RIFF'), offset: 0, also: { magic: ascii('WEBP'), offset: 8 } }],
  'image/bmp': [{ magic: ascii('BM'), offset: 0 }],
  'image/tiff': [
    { magic: [0x49, 0x49, 0x2a, 0x00], offset: 0 },
    { magic: [0x4d, 0x4d, 0x00, 0x2a], offset: 0 },
  ],
  'image/avif': [{ magic: ascii('ftypavif'), offset: 4 }],
  'image/heic': [{ magic: ascii('ftypheic'), offset: 4 }],
  'application/pdf': [{ magic: ascii('%PDF-'), offset: 0 }],
  'application/zip': [
    { magic: [0x50, 0x4b, 0x03, 0x04], offset: 0 },
    { magic: [0x50, 0x4b, 0x05, 0x06], offset: 0 },
    { magic: [0x50, 0x4b, 0x07, 0x08], offset: 0 },
  ],
  'application/gzip': [{ magic: [0x1f, 0x8b], offset: 0 }],
  'audio/mpeg': [
    { magic: ascii('ID3'), offset: 0 },
    { magic: [0xff, 0xfb], offset: 0 },
    { magic: [0xff, 0xf3], offset: 0 },
    { magic: [0xff, 0xf2], offset: 0 },
  ],
  'video/mp4': [{ magic: ascii('ftyp'), offset: 4 }],
};

/** OOXML and ODF are zip containers; they agree with a zip's signature. */
for (const type of [
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'application/vnd.oasis.opendocument.text',
  'application/vnd.oasis.opendocument.spreadsheet',
  'application/epub+zip',
]) {
  SIGNATURES[type] = SIGNATURES['application/zip']!;
}

const matches = (bytes: Uint8Array, signature: Signature): boolean => {
  const at = (magic: readonly number[], offset: number): boolean => {
    if (bytes.length < offset + magic.length) return false;
    return magic.every((byte, index) => bytes[offset + index] === byte);
  };
  if (!at(signature.magic, signature.offset)) return false;
  return signature.also ? at(signature.also.magic, signature.also.offset) : true;
};

/** Every media type in the table whose signature these bytes carry. */
function identify(bytes: Uint8Array): string[] {
  const found: string[] = [];
  for (const [type, signatures] of Object.entries(SIGNATURES)) {
    if (signatures.some((signature) => matches(bytes, signature))) found.push(type);
  }
  return found;
}

/** Whether this table can prove anything about a declared media type. */
export function hasSignature(mediaType: string): boolean {
  return mediaType in SIGNATURES;
}

/**
 * The reason these bytes contradict `declared`, or undefined if they do not.
 *
 * Pure and synchronous so it can be tested over a byte array directly, without
 * a server, a socket or a file adapter.
 */
export function signatureMismatch(bytes: Uint8Array, declared: string): string | undefined {
  const type = declared.split(';')[0]!.trim().toLowerCase();
  const expected = SIGNATURES[type];
  const actual = identify(bytes);

  if (expected) {
    if (expected.some((signature) => matches(bytes, signature))) return undefined;
    const looksLike = actual.length ? ` — the bytes are ${actual[0]}` : '';
    return `content does not match the declared type ${type}${looksLike}`;
  }

  // Direction 2: nothing to require, but something to forbid.
  if (actual.length) {
    return `content does not match the declared type ${type} — the bytes are ${actual[0]}`;
  }
  return undefined;
}

/**
 * Refuse a file whose leading bytes contradict its declared media type.
 *
 * Reads only `PREFIX_BYTES`, so cost does not scale with the upload, and runs
 * BEFORE the adapter stages anything — which is how S-102 holds by
 * construction rather than by a cleanup path that might not run.
 */
export async function verifyBytes(file: File, declared: string): Promise<string | undefined> {
  const prefix = new Uint8Array(await file.slice(0, PREFIX_BYTES).arrayBuffer());
  return signatureMismatch(prefix, declared);
}
