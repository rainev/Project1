import { mkdir, readdir, rename, rm, stat } from 'node:fs/promises';
import { join } from 'node:path';
import { DecryptionFailure } from '../errors.ts';
import type { KeyProvider } from '../crypto/keys.ts';
import type { FileAdapter, FileDescriptor } from './adapter.ts';

/**
 * Uploaded bytes go through the same key path as fields (§8), so ciphertext —
 * not plaintext — is what lands in every dump, backup and stolen disk image.
 *
 * On-disk layout is `iv (12 bytes) || ciphertext+tag`. The key id lives on the
 * descriptor rather than in the file, because the descriptor is already the
 * thing the row stores and rotation has to be able to find it.
 *
 * AAD binds the bytes to one tenant and one file id, so a file cannot be swapped
 * for another tenant's by moving it on disk — the same property AAD gives a
 * field value.
 */
const IV_BYTES = 12;
const fileAad = (orgId: string, id: string) => new TextEncoder().encode(`file:${orgId}:${id}`);

/**
 * Filesystems are not transactional, so writes are staged and only promoted once
 * the database transaction commits. A janitor sweeps anything left behind by a
 * rollback or a crash.
 */
export class FileLocalImpl implements FileAdapter {
  #root: string;
  #keys?: KeyProvider;

  /** Without a key provider the adapter stores plaintext — tests only. */
  constructor(root: string, keys?: KeyProvider) {
    this.#root = root;
    this.#keys = keys;
  }

  /**
   * Staging is per tenant.
   *
   * It was `.staging/<id>` — flat — and `finalise(orgId, id)` renamed out of it
   * using whichever org asked. That was unreachable while staging and
   * finalising happened inside one request under one identity. `POST /v0/stage`
   * splits them across two requests, so an id that leaked to another tenant
   * would have let them finalise bytes they did not stage: they could not read
   * them (the AAD binds to the staging tenant) but they could take them, and
   * the owner's upload would vanish. Scoping the directory removes the move
   * rather than relying on the id staying secret (WP-02 H-122).
   */
  #staged = (orgId: string, id: string) => join(this.#root, '.staging', orgId, id);
  #describe = (orgId: string, id: string) => join(this.#root, '.staging', orgId, `${id}.json`);
  #stored = (orgId: string, id: string) => join(this.#root, orgId, id);

  async stage(orgId: string, file: File): Promise<FileDescriptor> {
    const id = crypto.randomUUID();
    await mkdir(join(this.#root, '.staging', orgId), { recursive: true });
    const bytes = new Uint8Array(await file.arrayBuffer());

    // Checksum and size describe the ORIGINAL: the caller asked about their
    // file, not about our envelope.
    const checksum = Buffer.from(await crypto.subtle.digest('SHA-256', bytes)).toString('hex');
    const descriptor: FileDescriptor = {
      id,
      name: file.name || 'upload',
      size: bytes.byteLength,
      contentType: file.type || 'application/octet-stream',
      checksum,
    };

    // Sealed before it touches the disk, so staged bytes are never plaintext
    // either — a crash between stage and finalise leaves ciphertext behind.
    await Bun.write(this.#staged(orgId, id), await this.#seal(orgId, id, bytes, descriptor));
    // Written after sealing, because #seal stamps `kid` onto the descriptor.
    // This is the copy a later request is believed over the caller's.
    await Bun.write(this.#describe(orgId, id), JSON.stringify(descriptor));
    return descriptor;
  }

  async describeStaged(orgId: string, id: string): Promise<FileDescriptor | undefined> {
    const file = Bun.file(this.#describe(orgId, id));
    if (!(await file.exists())) return undefined;
    try { return (await file.json()) as FileDescriptor; } catch { return undefined; }
  }

  async #seal(orgId: string, id: string, bytes: Uint8Array, descriptor: FileDescriptor): Promise<Uint8Array> {
    if (!this.#keys) return bytes;
    const iv = crypto.getRandomValues(new Uint8Array(IV_BYTES));
    const key = await this.#keys.dataKey(orgId);
    const sealed = new Uint8Array(await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv, additionalData: fileAad(orgId, id) }, key, bytes,
    ));
    descriptor.kid = this.#keys.activeKid;
    const out = new Uint8Array(iv.byteLength + sealed.byteLength);
    out.set(iv, 0);
    out.set(sealed, iv.byteLength);
    return out;
  }

  async finalise(orgId: string, id: string): Promise<void> {
    await mkdir(join(this.#root, orgId), { recursive: true });
    await rename(this.#staged(orgId, id), this.#stored(orgId, id));
    await rm(this.#describe(orgId, id), { force: true });
  }

  async discard(orgId: string, id: string): Promise<void> {
    await rm(this.#staged(orgId, id), { force: true });
    await rm(this.#describe(orgId, id), { force: true });
  }

  /**
   * Reads whole, because AES-GCM authenticates over the entire message: the tag
   * cannot be checked until the last byte, and streaming plaintext before that
   * would be serving unverified data. Fine at the sizes `x-upload.maxSize`
   * permits; chunked framing is what large files would need.
   */
  async read(orgId: string, id: string, kid?: string): Promise<ReadableStream | undefined> {
    const file = Bun.file(this.#stored(orgId, id));
    if (!(await file.exists())) return undefined;

    const raw = new Uint8Array(await file.arrayBuffer());
    if (!this.#keys) return new Blob([raw]).stream();

    const key = await this.#keys.dataKey(orgId, kid);
    let plain: Uint8Array;
    try {
      plain = new Uint8Array(await crypto.subtle.decrypt(
        { name: 'AES-GCM', iv: raw.subarray(0, IV_BYTES), additionalData: fileAad(orgId, id) },
        key,
        raw.subarray(IV_BYTES),
      ));
    } catch {
      // The AAD is authenticated, so this fires when bytes have been moved
      // between files or tenants, or the wrong key is configured. Same posture
      // as a field: loud and specific server-side, opaque to the caller — never
      // serve unverified bytes.
      throw new DecryptionFailure('file', id, orgId);
    }
    return new Blob([plain]).stream();
  }

  /**
   * Decrypt with the key the descriptor names, encrypt with the active one,
   * and swap the file atomically — a rotation interrupted half-way must leave
   * readable bytes, not a truncated envelope. The caller records the new kid on
   * the descriptor; until it does, the file still opens under the old one,
   * because nothing has moved.
   */
  async reseal(orgId: string, id: string, kid?: string): Promise<string | undefined> {
    if (!this.#keys) return undefined;
    if (kid === this.#keys.activeKid) return kid;
    const path = this.#stored(orgId, id);
    const file = Bun.file(path);
    if (!(await file.exists())) return undefined;

    const raw = new Uint8Array(await file.arrayBuffer());
    const plain = new Uint8Array(await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv: raw.subarray(0, IV_BYTES), additionalData: fileAad(orgId, id) },
      await this.#keys.dataKey(orgId, kid),
      raw.subarray(IV_BYTES),
    ).catch(() => { throw new DecryptionFailure('file', id, orgId); }));

    // `#seal` stamps the active kid onto whatever descriptor it is handed; here
    // that is a scratch object, and the real one is updated by the caller in
    // the same write as the row.
    const stamp: FileDescriptor = { id, name: '', size: 0, contentType: '', checksum: '' };
    const sealed = await this.#seal(orgId, id, plain, stamp);
    const staging = `${path}.rotating`;
    await Bun.write(staging, sealed);
    await rename(staging, path);
    return stamp.kid;
  }

  async remove(orgId: string, id: string): Promise<void> {
    await rm(this.#stored(orgId, id), { force: true });
  }

  /** Staging is a directory per tenant now, so the sweep descends one level. */
  async sweep(olderThanMs: number): Promise<number> {
    const root = join(this.#root, '.staging');
    const cutoff = Date.now() - olderThanMs;
    let removed = 0;
    let orgs: string[];
    try { orgs = await readdir(root); } catch { return 0; }
    for (const org of orgs) {
      const dir = join(root, org);
      let entries: string[];
      try { entries = await readdir(dir); } catch { continue; }
      for (const entry of entries) {
        const info = await stat(join(dir, entry)).catch(() => undefined);
        if (!info?.isFile() || info.mtimeMs >= cutoff) continue;
        await rm(join(dir, entry), { force: true });
        // The sidecar is bookkeeping, not an orphaned upload.
        if (!entry.endsWith('.json')) removed++;
      }
    }
    return removed;
  }
}
