/**
 * Where encryption sits in the request pipeline (ARCHITECTURE §8):
 *   validate -> field-write policy -> [encrypt] -> store
 *   store -> [decrypt] -> field-read projection -> respond
 *
 * Hooks and gates therefore see plaintext; the adapter only ever sees ciphertext.
 */
import { BadRequest, DecryptionFailure } from '../errors.ts';
import type { Filter, Row } from '../db/adapter.ts';
import type { Model } from '../model.ts';
import { aad, blindIndex, decryptValue, encryptValue, indexColumn, isEnvelope } from './field.ts';
import type { KeyProvider } from './keys.ts';

const EQUALITY_OPS = new Set(['eq', 'ne', 'in']);

/** Encrypt declared fields and compute their blind indexes. Binds to this row. */
export async function encryptInput(
  keys: KeyProvider, model: Model, orgId: string, rowId: string, data: Row,
): Promise<Row> {
  if (Object.keys(model.encrypted).length === 0) return data;
  const out: Row = { ...data };

  for (const [field, setting] of Object.entries(model.encrypted)) {
    const value = out[field];
    if (value === undefined || value === null) continue;
    out[field] = await encryptValue(keys, orgId, String(value), aad(model.name, field, orgId, rowId));
    if (setting.search === 'exact') {
      out[indexColumn(field)] = await blindIndex(keys, orgId, value);
    }
  }
  return out;
}

/** Decrypt on the way out. A row is useless to a caller as ciphertext. */
export async function decryptRow<T extends Row>(
  keys: KeyProvider, model: Model, orgId: string, row: T,
): Promise<T> {
  if (Object.keys(model.encrypted).length === 0) return row;
  const out: Row = { ...row };

  for (const field of Object.keys(model.encrypted)) {
    const value = out[field];
    if (!isEnvelope(value)) continue;
    try {
      out[field] = await decryptValue(keys, orgId, value, aad(model.name, field, orgId, String(row.id)));
    } catch {
      // AES-GCM authenticates the AAD, so this fires when ciphertext has been
      // moved between fields, rows or tenants — or when the key is wrong.
      throw new DecryptionFailure(model.name, field, String(row.id));
    }
  }
  /**
   * The shadow column is framework bookkeeping and never leaves the server.
   *
   * Swept unconditionally, AFTER the loop, because the loop `continue`s on a
   * field that holds no envelope — a null, or a value written before the field
   * was encrypted — and that row still carries a `_bidx` column that must not
   * reach a caller. There was a second `delete` inside the loop doing the same
   * thing for the subset of fields that did decrypt (AUD-050); it was dead, and
   * removing the wrong one of the two would have leaked the column on exactly
   * the rows the loop skips.
   */
  for (const field of Object.keys(model.encrypted)) delete out[indexColumn(field)];
  return out as T;
}

/**
 * Equality on an encrypted field is answered by its blind index. Anything else —
 * ranges, LIKE, ordering — is refused; config-time checks stop most of this, and
 * this is the runtime backstop.
 */
export async function rewriteFilters(
  keys: KeyProvider, model: Model, orgId: string, filters: Filter[] = [],
): Promise<Filter[]> {
  const out: Filter[] = [];
  for (const filter of filters) {
    const setting = model.encrypted[filter.field];
    if (!setting) { out.push(filter); continue; }
    if (setting.search !== 'exact' || !EQUALITY_OPS.has(filter.op)) {
      throw new BadRequest(`${model.name}: "${filter.field}" is encrypted and supports only equality lookup`);
    }
    const values = Array.isArray(filter.value) ? filter.value : [filter.value];
    const hashed = await Promise.all(values.map((v) => blindIndex(keys, orgId, v)));
    out.push({ field: indexColumn(filter.field), op: filter.op, value: Array.isArray(filter.value) ? hashed : hashed[0] });
  }
  return out;
}

/** Uniqueness on an encrypted field compares blind indexes, never ciphertext. */
export async function uniquenessProbe(
  keys: KeyProvider, model: Model, orgId: string, field: string, value: unknown,
): Promise<{ field: string; value: unknown }> {
  if (!model.encrypted[field]) return { field, value };
  if (model.encrypted[field]!.search !== 'exact') {
    throw new BadRequest(`${model.name}: "${field}" is encrypted without a blind index and cannot be unique`);
  }
  return { field: indexColumn(field), value: await blindIndex(keys, orgId, value) };
}

/** Aggregating ciphertext is meaningless; refuse rather than return nonsense. */
export function assertAggregatable(model: Model, fields: (string | undefined)[]) {
  for (const field of fields) {
    if (field && model.encrypted[field]) {
      throw new BadRequest(`${model.name}: "${field}" is encrypted and cannot be aggregated or grouped`);
    }
  }
}
