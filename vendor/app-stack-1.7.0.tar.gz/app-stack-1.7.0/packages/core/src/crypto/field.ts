/**
 * Field-level encryption, applied above the adapter so behaviour is identical on
 * every engine and ciphertext lands in every dump and backup.
 */
import type { KeyProvider } from './keys.ts';

const encoder = new TextEncoder();
const decoder = new TextDecoder();

export const ENVELOPE_PREFIX = 'v1';

/**
 * Additional authenticated data binds ciphertext to exactly one field of one row
 * of one tenant, so a value cannot be moved between columns, rows or orgs.
 */
export function aad(model: string, field: string, orgId: string, rowId: string): Uint8Array {
  return encoder.encode(`${model}:${field}:${orgId}:${rowId}`);
}

export async function encryptValue(
  keys: KeyProvider, orgId: string, plaintext: string, additional: Uint8Array,
): Promise<string> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await keys.dataKey(orgId);
  const ciphertext = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv, additionalData: additional }, key, encoder.encode(plaintext),
  );
  return [
    ENVELOPE_PREFIX,
    keys.activeKid,
    Buffer.from(iv).toString('base64url'),
    Buffer.from(ciphertext).toString('base64url'),
  ].join(':');
}

export async function decryptValue(
  keys: KeyProvider, orgId: string, envelope: string, additional: Uint8Array,
): Promise<string> {
  const [version, kid, iv, ciphertext] = envelope.split(':');
  if (version !== ENVELOPE_PREFIX || !kid || !iv || !ciphertext) {
    throw new Error('unrecognised ciphertext envelope');
  }
  // The envelope names the key that wrote it, so rotation never orphans data.
  const key = await keys.dataKey(orgId, kid);
  const plaintext = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: Buffer.from(iv, 'base64url'), additionalData: additional },
    key,
    Buffer.from(ciphertext, 'base64url'),
  );
  return decoder.decode(plaintext);
}

export const isEnvelope = (value: unknown): value is string =>
  typeof value === 'string' && value.startsWith(`${ENVELOPE_PREFIX}:`);

/** Normalise before hashing so equality lookup behaves predictably. */
export function normaliseForIndex(value: unknown): string {
  return String(value).trim().toLowerCase();
}

/** Deterministic, so it leaks equality and nothing else. */
export async function blindIndex(keys: KeyProvider, orgId: string, value: unknown): Promise<string> {
  const key = await keys.indexKey(orgId);
  const mac = await crypto.subtle.sign('HMAC', key, encoder.encode(normaliseForIndex(value)));
  return Buffer.from(mac).toString('base64url');
}

export const indexColumn = (field: string) => `${field}_bidx`;
