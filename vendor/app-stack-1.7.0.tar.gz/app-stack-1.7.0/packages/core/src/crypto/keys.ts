/**
 * Key material (ARCHITECTURE §8).
 *
 * A single master key is resolved once from the secret seam. Per-tenant data keys
 * are derived from it with HKDF, so one tenant's key leaking does not decrypt
 * another's. Key material never appears in config.
 */
import { secret } from '../secrets.ts';

const encoder = new TextEncoder();

export interface KeyProvider {
  /** Which key id new ciphertext is written with. */
  readonly activeKid: string;
  /** Data key for a tenant under a given key id. */
  dataKey(orgId: string, kid?: string): Promise<CryptoKey>;
  /** Deterministic key for blind indexes. Separate from the encryption key. */
  indexKey(orgId: string): Promise<CryptoKey>;
}

async function hkdf(master: CryptoKey, info: string, usage: 'encrypt' | 'index'): Promise<CryptoKey> {
  const bits = await crypto.subtle.deriveBits(
    { name: 'HKDF', hash: 'SHA-256', salt: encoder.encode(`app-stack:${usage}`), info: encoder.encode(info) },
    master,
    256,
  );
  return usage === 'encrypt'
    ? crypto.subtle.importKey('raw', bits, { name: 'AES-GCM' }, false, ['encrypt', 'decrypt'])
    : crypto.subtle.importKey('raw', bits, { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
}

export async function createKeyProvider(options: { keys?: Record<string, string>; activeKid?: string } = {}): Promise<KeyProvider> {
  // Rotation: every key id that can still decrypt existing ciphertext.
  const material = options.keys ?? { k1: secret('APP_DEK') };
  const activeKid = options.activeKid ?? Object.keys(material)[0]!;

  const masters = new Map<string, CryptoKey>();
  for (const [kid, value] of Object.entries(material)) {
    masters.set(kid, await crypto.subtle.importKey('raw', encoder.encode(value), 'HKDF', false, ['deriveBits']));
  }

  const cache = new Map<string, CryptoKey>();
  const derive = async (kid: string, orgId: string, usage: 'encrypt' | 'index') => {
    const cacheKey = `${kid}:${orgId}:${usage}`;
    let key = cache.get(cacheKey);
    if (!key) {
      const master = masters.get(kid);
      if (!master) throw new Error(`unknown key id "${kid}"`);
      key = await hkdf(master, `org:${orgId}`, usage);
      cache.set(cacheKey, key);
    }
    return key;
  };

  return {
    activeKid,
    dataKey: (orgId, kid = activeKid) => derive(kid, orgId, 'encrypt'),
    indexKey: (orgId) => derive(activeKid, orgId, 'index'),
  };
}
