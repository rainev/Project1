/**
 * Declarative hooks and actions — the grammar (ARCHITECTURE §12, §13; D-02).
 *
 * A hook or an action is either a `path#namedExport` reference to code or an
 * object the framework runs itself. Five forms, chosen because they are what
 * the showcase's own handlers turned out to be once the TypeScript was read:
 *
 *   call   — perform another operation, through `ctx.call`
 *   batch  — several of those, in order, in the same transaction
 *   set    — patch fields on the pending write (or on the result, after commit)
 *   deny   — refuse when a condition holds
 *   skip   — stop running the rest of this point's chain when a condition holds
 *
 * Every expression is JEXL over the DECLARATION VIEW: the gate view
 * (`actor`, `op`, `model`, `input`, `row`, `now`) plus `id`, plus `result`
 * after commit. Deliberately the same language as the gates — see
 * `expressions.ts` — so there is no second grammar to learn or to secure.
 *
 * **A declaration is not trusted code.** `call` and `batch` go back through
 * `ctx.call`, which re-enters the one door and therefore the gates: a
 * declaration can do nothing the actor who triggered it could not do by hand.
 * That is the whole reason this is worth having as well as the escape hatch —
 * code is trusted and runs in-process, a declaration is neither.
 *
 * This is an `x-` keyword on the model, not a fourth config family: it needs no
 * parser of its own and no loader of its own (§21's first rule, §3.1).
 */
import { compileExpression, mentionsPath, type Compiled } from '../expressions.ts';
import { BUILTIN_OPS } from '../ops.ts';

const IDENTIFIER = /^[A-Za-z_][A-Za-z0-9_]*$/;

/**
 * A value in `set` or in a call's `data`.
 *
 * A **string is an expression**, never a literal — `"'todo'"` is the literal
 * string, `"input.status"` reads the payload. Making the common case (reading
 * something) the unquoted one is what keeps declarations short, and a rule with
 * no exceptions beats one that guesses. Booleans, numbers and `null` are taken
 * literally, because there is no useful expression over them.
 */
export type DeclaredValue = string | number | boolean | null;

export interface CallDecl {
  op: string;
  model: string;
  /** Expression yielding the id of the row to act on. Omit for `create`. */
  id?: string;
  data?: Record<string, DeclaredValue>;
}

/**
 * Send a message through a declared provider (WP-06 W-120).
 *
 * The sixth form, and the only one that reaches outside the process — which is
 * why it is admitted in `x-events` and nowhere else. A hook that notified would
 * be sending for a write that can still roll back, and there is no unsend.
 */
export interface NotifyDecl {
  /** A provider named in `config/notifications.yaml`. */
  provider: string;
  /**
   * Expressions, like a call's `data`. Evaluated at DELIVERY time, so this is
   * not the outbox payload and the "ids and names, never row values" rule that
   * governs `_outbox.payload` does not apply to it — these values never touch
   * the outbox row. They are what the body substitutes from.
   */
  data?: Record<string, DeclaredValue>;
  /**
   * Expression yielding the recipient, or a list of them (AUD-067, S-111).
   *
   * Overrides the provider's `to` for THIS declaration only; the provider's own
   * `to` stays the default, so an operator webhook declared beside this one is
   * unchanged. A recipient may come from a row. A CREDENTIAL never may: `from`,
   * `host`, `port` and `secretRef` are provider keys and this object refuses
   * them (`additionalProperties: false`), so a row can say who to write to and
   * can never say what to authenticate as.
   */
  to?: string;
  /** Templates. `{name}` is substituted from `data`; see `fillTemplate`. */
  subject?: string;
  text?: string;
  html?: string;
}

export type Declaration =
  | { call: CallDecl }
  | { batch: CallDecl[] }
  | { set: Record<string, DeclaredValue> }
  | { deny: { when: string; reason: string } }
  | { skip: { when: string } }
  | { notify: NotifyDecl };

/** What an `x-hooks` entry or an `x-actions` value may be. */
export type HandlerDecl = string | Declaration;

const VALUE = { type: ['string', 'number', 'boolean', 'null'] } as const;

const CALL_SCHEMA = {
  type: 'object',
  required: ['op', 'model'],
  additionalProperties: false,
  properties: {
    op: { type: 'string', pattern: IDENTIFIER.source },
    model: { type: 'string', pattern: IDENTIFIER.source },
    id: { type: 'string', minLength: 1 },
    data: { type: 'object', additionalProperties: VALUE },
  },
} as const;

const DECLARATION_SCHEMA = {
  type: 'object',
  minProperties: 1,
  maxProperties: 1,
  additionalProperties: false,
  properties: {
    call: CALL_SCHEMA,
    batch: { type: 'array', minItems: 1, items: CALL_SCHEMA },
    set: { type: 'object', minProperties: 1, additionalProperties: VALUE },
    deny: {
      type: 'object',
      required: ['when', 'reason'],
      additionalProperties: false,
      properties: { when: { type: 'string', minLength: 1 }, reason: { type: 'string', minLength: 1 } },
    },
    skip: {
      type: 'object',
      required: ['when'],
      additionalProperties: false,
      properties: { when: { type: 'string', minLength: 1 } },
    },
    notify: {
      type: 'object',
      required: ['provider'],
      // Load-bearing: `from`, `host`, `port`, `user` and `secretRef` are
      // provider keys, and refusing them HERE is what keeps a credential out of
      // a per-row declaration. A recipient may come from a row; a credential
      // never may (AUD-067).
      additionalProperties: false,
      properties: {
        provider: { type: 'string', pattern: '^[A-Za-z_][A-Za-z0-9_-]*$' },
        data: { type: 'object', additionalProperties: VALUE },
        to: { type: 'string', minLength: 1 },
        subject: { type: 'string', minLength: 1 },
        text: { type: 'string', minLength: 1 },
        html: { type: 'string', minLength: 1 },
      },
    },
  },
} as const;

/** One entry: a `path#export` string, or a declaration. Used by both keywords. */
export const HANDLER_SCHEMA = {
  oneOf: [{ type: 'string', minLength: 3 }, DECLARATION_SCHEMA],
} as const;

export const isDeclaration = (handler: HandlerDecl): handler is Declaration => typeof handler !== 'string';

/** How a handler is named in an error message and in a log line. */
export function describeHandler(handler: HandlerDecl): string {
  return typeof handler === 'string' ? `"${handler}"` : `${Object.keys(handler)[0]} declaration`;
}

/** Every call a declaration makes, in order. Used by boot cross-referencing. */
export function callsOf(declaration: Declaration): CallDecl[] {
  if ('call' in declaration) return [declaration.call];
  if ('batch' in declaration) return declaration.batch;
  return [];
}

// ---------------------------------------------------------------------------
// Compilation
// ---------------------------------------------------------------------------

export type CompiledValue = { literal: unknown } | { expression: Compiled };

export interface CompiledCall {
  op: string;
  model: string;
  id?: Compiled;
  data: [string, CompiledValue][];
}

export type CompiledDeclaration =
  | { kind: 'call'; call: CompiledCall }
  | { kind: 'batch'; calls: CompiledCall[] }
  | { kind: 'set'; fields: [string, CompiledValue][] }
  | { kind: 'deny'; when: Compiled; reason: string }
  | { kind: 'skip'; when: Compiled }
  | {
      kind: 'notify';
      provider: string;
      data: [string, CompiledValue][];
      to?: Compiled;
      subject?: string;
      text?: string;
      html?: string;
      /**
       * Whether any of this declaration's expressions reads `row`.
       *
       * A listener runs after the commit, on its own transaction, and its
       * context carries the EVENT's payload — not the row. So a declaration
       * that names the row needs it loaded at delivery time, through
       * `ctx.call('get', …)`, which re-applies the gates on the row as it is
       * now. Decided here, at boot, so a declaration that does not mention the
       * row does not pay for a fetch — and so the existing operator webhook,
       * which does not, behaves exactly as before.
       */
      needsRow: boolean;
    };

/**
 * Keyed by the declaration OBJECT, for the reason `schema.ts` and `gates.ts`
 * key their caches that way: two apps in one process must not share compiled
 * state because two declarations happen to look alike.
 */
const compiled = new WeakMap<object, CompiledDeclaration>();

export const compiledDeclaration = (declaration: Declaration): CompiledDeclaration | undefined =>
  compiled.get(declaration);


// ---------------------------------------------------------------------------
// Message templates (S-112)
// ---------------------------------------------------------------------------

/**
 * `{name}` — one placeholder, naming one key of the declaration's `data`.
 *
 * Deliberately not an expression language. `data` is already expressions, and
 * a second one inside a subject line would mean the same value could be
 * computed two ways and drift. A template names what `data` produced, nothing
 * more, and boot refuses a name `data` does not produce.
 */
const PLACEHOLDER = /\{([A-Za-z_][A-Za-z0-9_]*)\}/g;

/** Every key a template names, in order, deduplicated. */
export function placeholdersOf(template: string): string[] {
  return [...new Set([...template.matchAll(PLACEHOLDER)].map((match) => match[1]!))];
}

/**
 * Substitute a template against the values `data` produced.
 *
 * A key `data` did not produce — because its expression yielded nothing on this
 * row — renders as empty rather than as the literal `{name}`, which is the same
 * rule `set` follows for a value that resolves to nothing: a declaration that
 * has no opinion says nothing, it does not print its own source.
 */
export function fillTemplate(template: string, data: Record<string, unknown>): string {
  return template.replace(PLACEHOLDER, (_, key: string) => {
    const value = data[key];
    return value === undefined || value === null ? '' : String(value);
  });
}

/** A problem found at boot, with the path an author can go and edit. */
interface Problem { where: string; detail: string }

function compileValue(raw: DeclaredValue, where: string, problems: Problem[]): CompiledValue {
  if (typeof raw !== 'string') return { literal: raw };
  try {
    return { expression: compileExpression(raw, where) };
  } catch (error) {
    problems.push({ where, detail: (error as Error).message.replace(`${where}: `, '') });
    return { literal: undefined };
  }
}

function compileCall(raw: CallDecl, where: string, problems: Problem[]): CompiledCall {
  const data: [string, CompiledValue][] = [];
  for (const [field, value] of Object.entries(raw.data ?? {})) {
    data.push([field, compileValue(value, `${where}.data.${field}`, problems)]);
  }
  let id: Compiled | undefined;
  if (raw.id !== undefined) {
    try {
      id = compileExpression(raw.id, `${where}.id`);
    } catch (error) {
      problems.push({ where: `${where}.id`, detail: (error as Error).message });
    }
  }
  return { op: raw.op, model: raw.model, id, data };
}

/**
 * Compile one declaration and remember it against its own object.
 *
 * `owner` is the model the declaration is written on, and the only thing
 * checked against it is `set`: a declaration may CALL any model (the gates
 * decide whether it may), but it can only patch the write it is a hook on.
 */
function compileOne(
  declaration: Declaration, owner: { name: string; props: Record<string, unknown> },
  where: string, problems: Problem[],
): void {
  if ('call' in declaration) {
    compiled.set(declaration, { kind: 'call', call: compileCall(declaration.call, `${where}.call`, problems) });
    return;
  }
  if ('batch' in declaration) {
    compiled.set(declaration, {
      kind: 'batch',
      calls: declaration.batch.map((call, i) => compileCall(call, `${where}.batch[${i}]`, problems)),
    });
    return;
  }
  if ('set' in declaration) {
    const fields: [string, CompiledValue][] = [];
    for (const [field, value] of Object.entries(declaration.set)) {
      if (!(field in owner.props)) {
        problems.push({
          where: `${where}.set.${field}`,
          detail: `"${owner.name}" has no property "${field}" — declare it, or set a different field`,
        });
        continue;
      }
      fields.push([field, compileValue(value, `${where}.set.${field}`, problems)]);
    }
    compiled.set(declaration, { kind: 'set', fields });
    return;
  }
  if ('notify' in declaration) {
    const decl = declaration.notify;
    const data: [string, CompiledValue][] = [];
    const sources: string[] = [];
    for (const [field, value] of Object.entries(decl.data ?? {})) {
      data.push([field, compileValue(value, `${where}.notify.data.${field}`, problems)]);
      if (typeof value === 'string') sources.push(value);
    }

    let to: Compiled | undefined;
    if (decl.to !== undefined) {
      try {
        to = compileExpression(decl.to, `${where}.notify.to`);
        sources.push(decl.to);
      } catch (error) {
        problems.push({ where: `${where}.notify.to`, detail: (error as Error).message });
      }
    }

    // A template may only name what `data` produced. Catching it at boot is the
    // difference between a body that reads "Hi {name}" in somebody's inbox and
    // a config error an author can fix before anything is sent.
    const declared = new Set(data.map(([field]) => field));
    for (const part of ['subject', 'text', 'html'] as const) {
      for (const key of placeholdersOf(decl[part] ?? '')) {
        if (!declared.has(key)) {
          problems.push({
            where: `${where}.notify.${part}`,
            detail: `names "{${key}}", which notify.data does not produce — `
              + (declared.size ? `it produces: ${[...declared].join(', ')}` : 'it produces nothing'),
          });
        }
      }
    }

    const needsRow = sources.some((source) => {
      try { return mentionsPath(source, 'row', `${where}.notify`); } catch { return false; }
    });

    compiled.set(declaration, {
      kind: 'notify', provider: decl.provider, data, to, needsRow,
      subject: decl.subject, text: decl.text, html: decl.html,
    });
    return;
  }
  if ('deny' in declaration) {
    try {
      compiled.set(declaration, {
        kind: 'deny',
        when: compileExpression(declaration.deny.when, `${where}.deny.when`),
        reason: declaration.deny.reason,
      });
    } catch (error) {
      problems.push({ where: `${where}.deny.when`, detail: (error as Error).message });
    }
    return;
  }
  try {
    compiled.set(declaration, { kind: 'skip', when: compileExpression(declaration.skip.when, `${where}.skip.when`) });
  } catch (error) {
    problems.push({ where: `${where}.skip.when`, detail: (error as Error).message });
  }
}

/**
 * Kinds that make sense as an ACTION.
 *
 * An action *is* the operation: it must produce a result. `set` patches a write
 * that a hook is standing beside, and `deny`/`skip` speak about a chain an
 * action is not part of — so all three would declare something that quietly
 * does nothing, which is the silence §13's boot checks exist to prevent.
 */
const ACTION_KINDS = new Set(['call', 'batch']);

/**
 * Kinds that make sense where they are written.
 *
 * `notify` reaches outside the process, so it belongs where the write it is
 * about has already committed: a hook that notified would be sending for
 * something that can still roll back, and there is no unsend. Everything else
 * is a statement about a chain an event is not part of, or about a pending
 * write an event no longer has.
 */
const EVENT_KINDS = new Set(['call', 'batch', 'notify']);

/**
 * Compile every declaration on one model. Collects every problem and reports
 * them together: an author fixing a config wants the whole list, not the first
 * line of it (WP-04's posture).
 *
 * Returns the messages; the caller raises them as its own `ConfigError` so this
 * module needs no opinion about how a config error is spelled.
 */
export function compileDeclarations(
  owner: { name: string; props: Record<string, unknown> },
  hooks: Record<string, HandlerDecl[]>,
  actions: Record<string, HandlerDecl>,
  events: Record<string, HandlerDecl[]> = {},
): string[] {
  const problems: Problem[] = [];

  const entry = (handler: HandlerDecl, where: string, context: 'hook' | 'action' | 'event') => {
    if (typeof handler === 'string') {
      if (!handler.includes('#')) {
        problems.push({ where, detail: `handler "${handler}" must be of the form path#namedExport` });
      }
      return;
    }
    const kind = Object.keys(handler)[0]!;
    if (context === 'action' && !ACTION_KINDS.has(kind)) {
      problems.push({
        where,
        detail: `an action must produce a result, so it is "call", "batch" or a path#namedExport — "${kind}" only means something as a hook`,
      });
      return;
    }
    if (context === 'event' && !EVENT_KINDS.has(kind)) {
      problems.push({
        where,
        detail: `an event listener runs after the commit, so it is "call", "batch", "notify" or a path#namedExport — "${kind}" only means something as a hook`,
      });
      return;
    }
    if (context === 'hook' && kind === 'notify') {
      problems.push({
        where,
        detail: '"notify" sends outside this process and only means something in x-events — a hook that notified would send for a write that can still roll back',
      });
      return;
    }
    compileOne(handler, owner, where, problems);
  };

  for (const [point, handlers] of Object.entries(hooks)) {
    handlers.forEach((handler, i) => entry(handler, `x-hooks.${point}[${i}]`, 'hook'));
  }
  for (const [name, handler] of Object.entries(actions)) {
    entry(handler, `x-actions.${name}`, 'action');
  }
  // An event listener is a hook, not an action: it runs beside something that
  // has already happened and nobody is waiting for what it returns. So `set`,
  // `deny` and `skip` compile here exactly as they do on a hook point — and
  // mean nothing, which `run.ts` documents rather than the compiler refusing
  // three forms an author is unlikely to reach for post-commit.
  for (const [name, handlers] of Object.entries(events)) {
    handlers.forEach((handler, i) => entry(handler, `x-events."${name}"[${i}]`, 'event'));
  }

  return problems.map((p) => `${p.where}: ${p.detail}`);
}

/**
 * Cross-model checks, once every model has compiled (the same reason
 * `x-lookup`'s live in `loadModels`): a call naming a model that loads later
 * must not fail merely because of directory order.
 *
 * What is checked is what would otherwise be silent: a model that does not
 * exist, and an op that is neither builtin nor declared on the target. Whether
 * the ACTOR may perform it is not checked here and must not be — that is the
 * gate's decision, per request, and it is made when the call runs.
 */
/**
 * Every `notify` names a provider that exists.
 *
 * Separate from the model cross-reference because providers are not a family
 * and do not load with the models — but the check is the same shape and for the
 * same reason: a listener naming a provider nobody declared would bind at boot,
 * look wired, and fail on the first event that reached it.
 */
export function crossReferenceProviders(
  models: Map<string, { name: string; events: Record<string, HandlerDecl[]> }>,
  providers: Iterable<string>,
): string[] {
  const known = [...providers];
  const problems: string[] = [];
  for (const model of models.values()) {
    for (const [event, handlers] of Object.entries(model.events ?? {})) {
      handlers.forEach((handler, i) => {
        if (!isDeclaration(handler) || !('notify' in handler)) return;
        if (known.includes(handler.notify.provider)) return;
        problems.push(
          `${model.name}.x-events."${event}"[${i}]: notifies unknown provider "${handler.notify.provider}" — ` +
          (known.length
            ? `declared in notifications.yaml: ${known.join(', ')}`
            : 'no config/notifications.yaml declares any'),
        );
      });
    }
  }
  return problems;
}

export function crossReferenceDeclarations(
  models: Map<string, {
    name: string;
    hooks: Record<string, HandlerDecl[]>;
    actions: Record<string, HandlerDecl>;
    events?: Record<string, HandlerDecl[]>;
  }>,
): string[] {
  const problems: string[] = [];
  const known = [...models.keys()].join(', ');

  for (const model of models.values()) {
    const check = (declaration: Declaration, where: string) => {
      for (const call of callsOf(declaration)) {
        const target = models.get(call.model);
        if (!target) {
          problems.push(`${model.name}.${where}: calls unknown model "${call.model}" — known: ${known}`);
          continue;
        }
        if (!BUILTIN_OPS.has(call.op) && !(call.op in target.actions)) {
          const custom = Object.keys(target.actions);
          problems.push(
            `${model.name}.${where}: calls "${call.op}" on "${target.name}", which has no such operation — ` +
            `builtin: ${[...BUILTIN_OPS].join(', ')}${custom.length ? `; declared: ${custom.join(', ')}` : ''}`,
          );
        }
      }
    };

    for (const [point, handlers] of Object.entries(model.hooks)) {
      handlers.forEach((handler, i) => {
        if (isDeclaration(handler)) check(handler, `x-hooks.${point}[${i}]`);
      });
    }
    for (const [name, handler] of Object.entries(model.actions)) {
      if (isDeclaration(handler)) check(handler, `x-actions.${name}`);
    }
    for (const [name, handlers] of Object.entries(model.events ?? {})) {
      handlers.forEach((handler, i) => {
        if (isDeclaration(handler)) check(handler, `x-events."${name}"[${i}]`);
      });
    }
  }
  return problems;
}
