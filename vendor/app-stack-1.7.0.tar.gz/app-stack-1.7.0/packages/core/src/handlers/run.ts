/**
 * Declarative hooks and actions — the runtime (ARCHITECTURE §12, §13).
 *
 * `declarativeHandler` turns one compiled declaration into an ordinary
 * `HandlerFn`. That is the whole point of the shape: the engine's hook runner
 * and its custom-action branch take a function and never ask where it came
 * from, so "declaration" is not a second execution path to secure — it is a
 * different way of producing the same one.
 */
import { makeView } from '../gates.ts';
import type { Model } from '../model.ts';
import { BadRequest } from '../errors.ts';
import type { ActionContext, HookResult, Row } from './types.ts';
import {
  compiledDeclaration, describeHandler, fillTemplate,
  type CompiledCall, type CompiledValue, type Declaration,
} from './declare.ts';

/**
 * What a declaration's expressions see: the gate view, plus the two things a
 * hook has and a gate does not.
 *
 * `id` is the row the operation names — a gate never needs it because the row
 * itself is in scope, but a `call` acting on "this row" does. `result` is only
 * populated after commit, so a before-hook reading it gets `undefined` rather
 * than a stale value from somewhere else.
 *
 * Nothing callable crosses: this is the same frozen plain data the gates get,
 * so a declaration can read the request and cannot reach the transaction, the
 * adapter or the filesystem except by going back through `ctx.call`.
 */
function declarationView(ctx: ActionContext) {
  return Object.freeze({
    ...makeView(ctx.actor, ctx.op, ctx.model, ctx.data, ctx.row),
    id: ctx.id,
    result: ctx.result,
  });
}

/**
 * Nothing to write.
 *
 * An EXPRESSION that yields `undefined` or `null` means "this declaration has
 * no opinion about that field": `input.title|trim` on a request that sent no
 * title, or `row.customerId` on a row that has no customer. Writing what it
 * produced would blank a column, or hand a JSON Schema `type: string` a null
 * and fail the request — a hook that says nothing must not be able to do that.
 *
 * A LITERAL `null` in the YAML is the opposite: an instruction, written by the
 * author rather than read from the request, so it is passed through as written
 * and the target's own schema decides whether it is acceptable.
 */
const NOTHING = Symbol('nothing');

const valueOf = (value: CompiledValue, view: unknown): unknown => {
  if ('literal' in value) return value.literal;
  const resolved = value.expression.evalSync(view);
  return resolved === undefined || resolved === null ? NOTHING : resolved;
};

async function runCall(call: CompiledCall, ctx: ActionContext, view: unknown): Promise<unknown> {
  const data: Row = {};
  for (const [field, value] of call.data) {
    const resolved = valueOf(value, view);
    if (resolved !== NOTHING) data[field] = resolved;
  }

  let id: string | undefined;
  if (call.id) {
    const resolved = call.id.evalSync(view);
    if (resolved === undefined || resolved === null) {
      throw new BadRequest(`declared call to ${call.op} ${call.model} has no id`);
    }
    id = String(resolved);
  }
  return ctx.call(call.op, call.model, { id, data });
}

/**
 * One declaration, as a handler.
 *
 * As a HOOK the return value is read as a `HookResult`: `set` becomes a patch,
 * `deny` a refusal, `skip` an early end to the chain. A `call`'s result is a
 * row, which carries none of those keys and is therefore ignored — the same
 * thing that happens today when a coded hook returns something the runner does
 * not recognise.
 *
 * As an ACTION the return value *is* the result, which is why the compiler
 * admits only `call` and `batch` there.
 */
/**
 * What a declaration needs from outside itself.
 *
 * Only `notify` has any: everything else reaches persistence through `ctx.call`
 * and nothing else. Passed in rather than imported so this module keeps knowing
 * nothing about providers, sockets or the network — it evaluates expressions and
 * hands the result to whatever was bound at boot.
 */
/** What a `notify` declaration resolved to, ready for a provider. */
export interface NotifyPayload {
  data: Record<string, unknown>;
  /**
   * Recipients the declaration named, or undefined when it named none — in
   * which case the provider's own `to` remains the default (S-111).
   */
  to?: string[];
  subject?: string;
  text?: string;
  html?: string;
}

export interface DeclarationDeps {
  notify?: (provider: string, payload: NotifyPayload, ctx: ActionContext) => Promise<void>;
}

/**
 * What a `to` expression may have produced, as a recipient list.
 *
 * A string is one address, an array is several, and anything empty means the
 * declaration named nobody — which falls back to the provider's `to` rather
 * than sending to nobody, because a confirmation with no recipient is a silent
 * loss and the provider's default is the operator who wants to know.
 */
function recipientsOf(resolved: unknown, where: string): string[] | undefined {
  if (resolved === undefined || resolved === null) return undefined;
  const list = (Array.isArray(resolved) ? resolved : [resolved])
    .filter((value) => value !== undefined && value !== null)
    .map((value) => String(value).trim())
    .filter((value) => value.length > 0);
  if (!list.length) return undefined;
  for (const address of list) {
    // A row value reaching an SMTP header is an injection surface, so the
    // refusal is here as well as at the socket: a newline in an address would
    // append headers of the attacker's choosing. Refused loudly — the outbox
    // records the failure, rather than sending a message somebody else wrote.
    if (/[\r\n]/.test(address)) {
      throw new BadRequest(`${where}: a recipient may not contain a line break`);
    }
    if (!/^[^@\s]+@[^@\s]+$/.test(address)) {
      throw new BadRequest(`${where}: "${address}" is not an address`);
    }
  }
  return list;
}

export function declarativeHandler(
  model: Model, declaration: Declaration, where: string, deps: DeclarationDeps = {},
) {
  const plan = compiledDeclaration(declaration);
  if (!plan) {
    throw new Error(`${model.name}.${where}: ${describeHandler(declaration)} was not compiled at boot`);
  }

  return async function declared(ctx: ActionContext): Promise<HookResult | unknown> {
    const view = declarationView(ctx);

    switch (plan.kind) {
      case 'deny':
        return plan.when.evalSync(view) === true ? { deny: plan.reason } : undefined;

      case 'skip':
        return plan.when.evalSync(view) === true ? { skip: true as const } : undefined;

      case 'set': {
        const patch: Row = {};
        for (const [field, value] of plan.fields) {
          const resolved = valueOf(value, view);
          if (resolved !== NOTHING) patch[field] = resolved;
        }
        return Object.keys(patch).length ? { patch } : undefined;
      }

      case 'notify': {
        if (!deps.notify) {
          throw new Error(`${model.name}.${where}: notify was not bound at boot`);
        }
        /**
         * The row, at delivery time (S-111).
         *
         * A listener runs after the commit with the EVENT's payload in `input`
         * and no row, and the outbox payload carries ids and names only — an
         * address written into it would be a row value sitting in plain JSON
         * beside the ciphertext of the field it came from. So a declaration
         * that names the row fetches it now, through the one door: `ctx.call`
         * re-applies the access, scope and field gates as the actor who caused
         * the event, on the row as it is NOW. A field that actor may not read
         * is absent here, so it cannot be mailed anywhere.
         */
        let notifyView = view;
        if (plan.needsRow && ctx.row === undefined && ctx.id) {
          const row = await ctx.call('get', model.name, { id: ctx.id });
          notifyView = Object.freeze({ ...view, row });
        }

        const data: Row = {};
        for (const [field, value] of plan.data) {
          const resolved = valueOf(value, notifyView);
          if (resolved !== NOTHING) data[field] = resolved;
        }
        const to = plan.to
          ? recipientsOf(plan.to.evalSync(notifyView), `${model.name}.${where}.notify.to`)
          : undefined;
        const fill = (template: string | undefined) =>
          (template === undefined ? undefined : fillTemplate(template, data));

        const perform = () => deps.notify!(plan.provider, {
          data, to, subject: fill(plan.subject), text: fill(plan.text), html: fill(plan.html),
        }, ctx);
        /**
         * Deferred when the outbox offers it, so the SMTP conversation happens
         * AFTER the delivery transaction commits rather than inside it
         * (AUD-087). A send held open inside the transaction keeps a write lock
         * for the length of a network round trip, and a retrying backlog then
         * 500s unrelated writes on a single connection.
         *
         * Everything above is already resolved — the row, the recipients, the
         * substituted body — inside the transaction, on the row as it is now.
         * Only the socket moves out.
         *
         * Throws on failure either way, deliberately: the outbox counts the
         * attempt and tries again. A receiver being down is not a reason to
         * lose the event.
         */
        if (ctx.deferSend) { ctx.deferSend(perform); return; }
        return perform();
      }

      case 'call':
        return runCall(plan.call, ctx, view);

      case 'batch': {
        const results: unknown[] = [];
        // In order, on the caller's transaction: a failure part-way rolls the
        // whole request back, exactly as a coded handler making the same calls
        // would. There is no partial batch.
        for (const call of plan.calls) results.push(await runCall(call, ctx, view));
        return results;
      }
    }
  };
}
