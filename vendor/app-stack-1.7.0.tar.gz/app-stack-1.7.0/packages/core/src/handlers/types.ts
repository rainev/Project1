/** The one handler signature (ARCHITECTURE §12). Code and declarations both produce it. */
import type { Row } from '../db/adapter.ts';

export type { Row };
export type { ActionContext, HookResult } from '../engine/types.ts';

export type HandlerFn = (context: any) => unknown | Promise<unknown>;
