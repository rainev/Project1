/**
 * Handler binding (ARCHITECTURE §13).
 *
 * Two kinds of handler, one registry, one `HandlerFn` out (WP-02 H-103):
 *
 *  - **code** — `path#namedExport`, resolved at boot by Bun's own module
 *    loader. There is no registry of ids to drift from the config: if the file
 *    or the export is missing, the server does not start. Bun runs TypeScript
 *    natively, so an extension needs no build step. This code is TRUSTED: it
 *    runs in-process with full capability and there is no sandbox.
 *  - **declaration** — an object on the model, compiled by `declare.ts` and
 *    turned into a function by `run.ts`. It is NOT trusted code and gets no
 *    privilege code does not have: every operation it performs goes back
 *    through `ctx.call` and therefore through the gates.
 *
 * The engine asks the registry for a handler and runs it. It cannot tell which
 * kind it got, which is what stops "declarative" from becoming a second
 * execution path with its own security posture.
 */
import { resolve } from 'node:path';
import type { Model } from '../model.ts';
import { describeHandler, isDeclaration, type Declaration, type HandlerDecl } from './declare.ts';
import { declarativeHandler, type DeclarationDeps } from './run.ts';
import type { HandlerFn } from './types.ts';

export type { HandlerFn };
export type { HandlerDecl, Declaration };

export interface HandlerRef {
  reference: string;
  model: string;
  where: string;
}

export class ExtensionError extends Error {
  constructor(ref: HandlerRef, detail: string) {
    super(`${ref.model}.${ref.where}: "${ref.reference}" ${detail}`);
    this.name = 'ExtensionError';
  }
}

/**
 * Lookup is by the handler AS DECLARED — the reference string, or the
 * declaration object itself.
 *
 * Declarations are keyed by identity, not by their content: two models may
 * carry declarations that serialise identically and still mean different
 * things, and a content key would quietly make them the same handler. It is the
 * same reasoning `gates.ts` and `schema.ts` give for keying their caches by the
 * `Model` object. A plain `Map<string, HandlerFn>` still satisfies this
 * interface, which is what lets a test hand the engine one.
 */
export interface HandlerRegistry {
  get(handler: HandlerDecl): HandlerFn | undefined;
}

class Handlers implements HandlerRegistry {
  /** Shared across models: the same `path#export` is imported and bound once. */
  private code = new Map<string, HandlerFn>();
  /** Per declaration object, so identical text on two models stays two handlers. */
  private declared = new WeakMap<object, HandlerFn>();

  get(handler: HandlerDecl): HandlerFn | undefined {
    return typeof handler === 'string' ? this.code.get(handler) : this.declared.get(handler);
  }

  async bindCode(ref: HandlerRef, configDir: string): Promise<void> {
    if (this.code.has(ref.reference)) return;

    const [path, exportName] = ref.reference.split('#') as [string, string];
    const specifier = path.startsWith('.') ? resolve(configDir, path) : path;

    let module: Record<string, unknown>;
    try {
      module = await import(specifier);
    } catch (error) {
      throw new ExtensionError(ref, `could not be imported: ${(error as Error).message}`);
    }

    const handler = module[exportName];
    if (handler === undefined) {
      const available = Object.keys(module).filter((k) => typeof module[k] === 'function');
      throw new ExtensionError(ref, `has no export "${exportName}" (exports: ${available.join(', ') || 'none'})`);
    }
    if (typeof handler !== 'function') {
      throw new ExtensionError(ref, `export "${exportName}" is not a function`);
    }
    this.code.set(ref.reference, handler as HandlerFn);
  }

  bindDeclaration(model: Model, declaration: Declaration, where: string, deps: DeclarationDeps): void {
    this.declared.set(declaration, declarativeHandler(model, declaration, where, deps));
  }
}

/**
 * Resolve every declared handler. Throws at boot, naming model and lifecycle
 * point — a missing file, a missing export, or a declaration that never
 * compiled.
 */
export async function loadHandlers(
  models: Iterable<Model>, configDir: string, deps: DeclarationDeps = {},
): Promise<HandlerRegistry> {
  const registry = new Handlers();

  for (const model of models) {
    const bind = async (handler: HandlerDecl, where: string) => {
      if (isDeclaration(handler)) registry.bindDeclaration(model, handler, where, deps);
      else await registry.bindCode({ reference: handler, model: model.name, where }, configDir);
    };

    for (const [point, handlers] of Object.entries(model.hooks)) {
      for (const handler of handlers) await bind(handler, `x-hooks.${point}`);
    }
    for (const [action, handler] of Object.entries(model.actions)) {
      await bind(handler, `x-actions.${action}`);
    }
    // Post-commit listeners resolve at boot like everything else: a missing
    // file or export must fail startup, not the first delivery attempt — which
    // would otherwise retry a broken import five times in a background loop.
    for (const [name, handlers] of Object.entries(model.events)) {
      for (const handler of handlers) await bind(handler, `x-events."${name}"`);
    }
  }
  return registry;
}

export { describeHandler, isDeclaration };
