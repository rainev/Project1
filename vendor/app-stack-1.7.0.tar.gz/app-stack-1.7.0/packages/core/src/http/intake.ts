/**
 * HTTP intake: everything between a request and an envelope, and between a
 * result and a response (ARCHITECTURE §3, §6, §9, §14).
 *
 *   /<version>/<action>/<model>/<id?>
 *
 * Route parsing, the actor, the body (JSON or multipart), query parsing, the
 * batch and file-download forms, one transaction per writing request, staged
 * file promotion after commit, the audit row, and the wire mapping of errors.
 * Nothing here decides whether an operation may run — that is the engine's.
 */
import type { Filter, Row } from '../db/adapter.ts';
import type { FileAdapter, FileDescriptor } from '../files/adapter.ts';
import type { Model } from '../model.ts';
import { allowsAction, canWrite, makeView, READ_OPS } from '../gates.ts';
import { isAnonymous } from '../public.ts';
import { verifyBytes } from '../files/signature.ts';
import { createGuard } from '../auth/rate-limit.ts';
import { BadRequest, Denied, NotFound } from '../errors.ts';
import { json, type Handler } from '../server.ts';
import { createAuditWriter, describeError, type Attempted } from '../engine/audit.ts';
import { createEngine, type DispatchOptions } from '../engine/execute.ts';
import { withStoreRetry } from '../engine/retry.ts';
import { runQuery, streamQueryCsv } from '../queries/execute.ts';
import { STAGE_PREFIX } from '../engine/types.ts';
import type { Envelope, Query, StagedFile } from '../engine/types.ts';

const FILTER_OPS = new Set(['eq', 'ne', 'gt', 'gte', 'lt', 'lte', 'contains', 'in']);

/** Paging and ordering belong to the reader; everything else on the URL is a param. */
const RESERVED_QUERY_KEYS = new Set(['limit', 'cursor', 'sort', 'dir']);

const coerce = (value: string): unknown =>
  value === 'true' ? true : value === 'false' ? false
    : value !== '' && !Number.isNaN(Number(value)) ? Number(value) : value;

/** `?where=field:op:value` — the operator is matched against a framework enum. */
export function parseFilters(url: URL): Filter[] {
  return url.searchParams.getAll('where').map((raw) => {
    const [field, op, ...rest] = raw.split(':');
    if (!field || !op || !FILTER_OPS.has(op)) {
      throw new BadRequest(`malformed filter "${raw}" (expected field:op:value)`);
    }
    const value = rest.join(':');
    return { field, op: op as Filter['op'], value: op === 'in' ? value.split(',') : coerce(value) };
  });
}

/** Multipart intake: files are staged, and the descriptor is what the row stores. */
async function readMultipart(
  request: Request, model: Model, orgId: string, files: FileAdapter, staged: StagedFile[],
): Promise<Row> {
  const form = await request.formData();
  const data: Row = {};

  for (const [key, value] of form.entries()) {
    if (!(value instanceof File)) {
      // Non-file parts are ordinary input; JSON is preferred but forms send strings.
      data[key] = value === 'true' ? true : value === 'false' ? false : value;
      continue;
    }
    const settings = model.uploads[key];
    if (!settings) throw new BadRequest(`"${key}" does not accept an uploaded file`);
    if (value.size > settings.maxSize) {
      throw new BadRequest(`"${key}" exceeds the maximum size of ${settings.maxSize} bytes`);
    }
    // Browsers send parameters on the media type ("text/plain;charset=utf-8");
    // the allowlist is about the type itself.
    const mediaType = (value.type || '').split(';')[0]!.trim().toLowerCase();
    if (settings.accept.length && !settings.accept.includes(mediaType)) {
      throw new BadRequest(`"${key}" does not accept ${mediaType || 'unknown'} (allowed: ${settings.accept.join(', ')})`);
    }
    // The declared type got the file past the allowlist; the BYTES decide
    // whether it was telling the truth (AUD-069). Before `stage`, so a refusal
    // writes nothing — S-102 holds by construction, not by a cleanup path.
    const mismatch = await verifyBytes(value, mediaType);
    if (mismatch) throw new BadRequest(`"${key}" ${mismatch}`);
    const descriptor = await files.stage(orgId, value);
    staged.push({ orgId, id: descriptor.id });
    // A reference, not the descriptor. Both upload paths now hand the engine
    // the same thing, so the engine has one rule to enforce instead of a
    // trusted shape and an untrusted one that look identical (WP-02 H-122).
    data[key] = `${STAGE_PREFIX}${descriptor.id}`;
  }
  return data;
}

export function createDispatcher(options: DispatchOptions): Handler {
  const engine = createEngine(options);
  const audit = createAuditWriter(options.db);
  /**
   * Writes by a VISITOR are rate-limited (WP-07, §22).
   *
   * The credential routes have been limited since WP-05; a public write is the
   * second unauthenticated way to reach the database, and shipping one without
   * a limit is shipping a defect. The same limiter, keyed by its own route name
   * so a contact form cannot spend a sign-in budget or vice versa.
   *
   * Counted on every ATTEMPT rather than on failures, which is `register`'s
   * shape and for `register`'s reason: the threat is the volume of rows
   * created, so a success is exactly what needs bounding.
   */
  const guard = createGuard();

  return async ({ request, url, client }) => {
    const segments = url.pathname.split('/');
    const [, , action, modelName, id] = segments;
    const meta: Envelope['meta'] = {
      requestId: crypto.randomUUID(), at: new Date().toISOString(), source: 'http',
    };

    if (!action) return json({ error: 'bad_request', detail: 'expected /<version>/<action>/<model>/<id?>' }, 400);

    const actor = await options.resolveActor(request);
    if (!actor) return json({ error: 'unauthenticated' }, 401);

    const readBody = async (): Promise<Row> => {
      if (!request.headers.get('content-type')?.includes('application/json')) return {};
      try { return (await request.json()) as Row; } catch { throw new BadRequest('body is not valid JSON'); }
    };

    // What we will say was attempted, filled in as the request is understood, so
    // a failure that happens before the envelope is built still audits.
    const attempted = {
      actor, op: action, model: modelName ?? '-', id, data: {} as Row, meta,
    };

    /**
     * Fields the write gate dropped anywhere in this request, including inside
     * a `ctx.call` (WP-02 H-120, AUD-059). Collected by the engine, reported
     * here — a silently trimmed write is the one thing §5 says a caller must
     * not have to infer from a 201.
     *
     * This tells the caller nothing it did not already know: the list can only
     * contain field names the caller itself just sent. What a model HAS is
     * still projected per actor (§19) and is not disclosed here.
     */
    const denied: string[] = [];
    const withDenied = (body: Record<string, unknown>) =>
      denied.length ? { ...body, denied: [...new Set(denied)] } : body;
    const deniedDetail = () =>
      (denied.length ? `denied fields: ${[...new Set(denied)].join(',')}` : undefined);

    /**
     * One audit row per batch element, written once the transaction has settled
     * (WP-02 H-121, AUD-062). A batch used to audit as a single row with
     * `model '-'`, which is the one shape §6 says the record must never take:
     * it names neither what was touched nor which row.
     *
     * The batch row itself is still written, by the same machinery every other
     * request uses, so the two are distinguishable — an element carries
     * `source: 'batch'` and its own model, the batch carries `source: 'http'`.
     */
    interface ElementRecord { envelope: Attempted; error?: unknown; status?: number; detail?: string }
    const elements: ElementRecord[] = [];
    const flushElements = async () => {
      for (const element of elements) await audit(element);
    };

    const handle = async (): Promise<Response> => {
      // One transaction per request, shared by every element of a batch.
      if (action === 'batch') {
        const body = await readBody();
        const operations = (body.operations ?? []) as Envelope[];
        if (!Array.isArray(operations) || operations.length === 0) {
          throw new BadRequest('operations must be a non-empty array');
        }
        const results = await options.db.tx(async (tx) => {
          const out: unknown[] = [];
          for (const op of operations) {
            const element: Envelope = {
              actor, op: String(op.op), model: String(op.model), id: op.id,
              data: op.data ?? {}, query: {}, meta: { ...meta, source: 'batch' },
            };
            const record: ElementRecord = { envelope: element };
            elements.push(record);
            try {
              const result = await engine.execute(element, tx, 0, undefined, undefined, denied);
              record.status = 200;
              // A create mints its id inside the engine, so the record only
              // learns which row it wrote by looking at what came back.
              if (result && typeof result === 'object' && 'id' in result) {
                record.envelope = { ...record.envelope, id: String((result as Row).id) };
              }
              out.push(result);
            } catch (error) {
              record.error = error;
              throw error;
            }
          }
          return out;
        }).catch((error) => {
          // Everything that ran is gone. An element that succeeded still gets a
          // row — it was attempted, and the attempt is the record — but it says
          // so, rather than claiming a write that no longer exists.
          for (const element of elements) if (!element.error) element.detail = 'rolled back';
          throw error;
        });
        return json({ data: results, meta: withDenied({ ...meta, count: results.length }) });
      }

      /**
       * Stage bytes before the row exists (WP-02 H-122, for WP-01 phase 3).
       *
       * `POST /v0/stage/<model>/<property>` with one file part. The response is
       * a descriptor for display plus the `ref` the form puts in the field; the
       * row is written later, by an ordinary create or update carrying that ref.
       *
       * Writing bytes to disk is a side effect, so §22 applies in full: the
       * access gate and the field-write gate both run BEFORE anything is read
       * from the body. `x-upload`'s size and type limits are the same ones the
       * multipart path enforces. Nothing is promoted here — bytes stay in the
       * tenant's staging area until a row that references them commits, and the
       * janitor sweeps whatever is never claimed.
       */
      if (action === 'stage') {
        const [, , , stageModel, property] = segments;
        if (!options.files) throw new NotFound('file storage is not configured');
        if (!stageModel || !property) throw new BadRequest('expected /v0/stage/<model>/<property>');
        const model = options.models.get(stageModel);
        if (!model) throw new NotFound('unknown_model');

        // Gate first, with no row: staging precedes the record it will belong
        // to. The model-level gate runs BEFORE the property is looked at, so a
        // caller who may not write this model learns nothing about its upload
        // properties — which of a model's fields take a file is part of the
        // shape §19 projects per actor, not public.
        const view = makeView(actor, 'create', model, {});
        if (!allowsAction(model, view)) throw new Denied('forbidden');

        const settings = model.uploads[property];
        if (!settings) throw new BadRequest(`"${property}" does not accept an uploaded file`);
        if (!canWrite(model, view, property)) throw new Denied('forbidden');

        const declared = Number(request.headers.get('content-length') ?? 0);
        if (declared > settings.maxSize * 2) {
          throw new BadRequest(`"${property}" exceeds the maximum size of ${settings.maxSize} bytes`);
        }
        const form = await request.formData();
        const file = [...form.values()].find((v): v is File => v instanceof File);
        if (!file) throw new BadRequest('expected one file part');
        if (file.size > settings.maxSize) {
          throw new BadRequest(`"${property}" exceeds the maximum size of ${settings.maxSize} bytes`);
        }
        const mediaType = (file.type || '').split(';')[0]!.trim().toLowerCase();
        if (settings.accept.length && !settings.accept.includes(mediaType)) {
          throw new BadRequest(`"${property}" does not accept ${mediaType || 'unknown'} (allowed: ${settings.accept.join(', ')})`);
        }
        // Same rule as the multipart path, and for the same reason: `file.type`
        // came from the caller, and what a download later SERVES is decided
        // here (AUD-069). Refused before `stage`, so nothing is left staged.
        const mismatch = await verifyBytes(file, mediaType);
        if (mismatch) throw new BadRequest(`"${property}" ${mismatch}`);

        const descriptor = await options.files.stage(actor.orgId, file);
        attempted.data = { [property]: descriptor.name };
        // `ref` is the whole contract: an id the server can look its own record
        // up by. The descriptor beside it is for showing a name and a size.
        return json({
          data: {
            ref: `${STAGE_PREFIX}${descriptor.id}`,
            name: descriptor.name,
            size: descriptor.size,
            contentType: descriptor.contentType,
          },
          meta,
        });
      }

      // Downloads run the full read path first: access, scope and field-read all
      // apply before a single byte is streamed.
      if (action === 'file') {
        const [, , , fileModel, fileId, property] = segments;
        if (!options.files) throw new NotFound('file storage is not configured');
        if (!fileModel || !fileId || !property) throw new BadRequest('expected /v0/file/<model>/<id>/<property>');

        const row = (await engine.execute(
          { actor, op: 'get', model: fileModel, id: fileId, data: {}, query: {}, meta: { ...meta, source: 'file' } },
          options.db, 0,
        )) as Row;

        // Absent means either no file or no permission to read the field — the
        // projection already removed it, and we must not distinguish the two.
        const raw = row[property];
        if (typeof raw !== 'string') throw new NotFound('not_found');
        const descriptor = JSON.parse(raw) as FileDescriptor;
        const stream = await options.files.read(actor.orgId, descriptor.id, descriptor.kid);
        if (!stream) throw new NotFound('not_found');

        return new Response(stream, {
          headers: {
            'content-type': descriptor.contentType,
            'content-length': String(descriptor.size),
            'content-disposition': `attachment; filename="${descriptor.name.replace(/"/g, '')}"`,
            'cache-control': 'private, no-store',
          },
        });
      }

      /**
       * A declared query (§7.1): `/v0/query/<name>`.
       *
       * It is a READ, and it is gated like one — the query's own `x-access.read`
       * first, then every participating model's, then each model's scope bound
       * into the statement. None of that happens here; this is only the wire.
       *
       * GET carries parameters in the query string. POST carries them in a JSON
       * body, for a parameter set too large or too structured for a URL — an
       * `in` list of two hundred ids is the ordinary case. It reads nothing and
       * writes nothing either way, so it takes no transaction.
       */
      if (action === 'query') {
        // `/v0/query/<name>.csv` is the same read, rendered differently (Q-112).
        const csv = modelName?.endsWith('.csv') ?? false;
        const name = csv ? modelName!.slice(0, -'.csv'.length) : modelName;
        if (!name) throw new BadRequest('expected /<version>/query/<name>');
        attempted.model = name;
        /**
         * A cross-tenant read is audited as its own operation (Q-125). It is
         * recorded on the ATTEMPT, so a tenant actor's refused attempt at one is
         * as visible in the record as a platform actor's successful read — and
         * the marking rides in `op` rather than in a new `_audits` column,
         * because adding a column to a system model would fail the boot drift
         * check on every database that already exists (schema evolution is
         * roadmap initiative 8).
         */
        if (options.queries?.get(name)?.crossTenant) attempted.op = 'query:cross-tenant';

        let params: Row = {};
        let limit = url.searchParams.get('limit');
        let cursor = url.searchParams.get('cursor') ?? undefined;

        if (request.method === 'POST') {
          const body = await readBody();
          params = (body.params ?? {}) as Row;
          if (body.limit !== undefined) limit = String(body.limit);
          if (typeof body.cursor === 'string') cursor = body.cursor;
        } else {
          for (const [key, value] of url.searchParams.entries()) {
            if (RESERVED_QUERY_KEYS.has(key)) continue;
            params[key] = value;
          }
        }
        if (limit !== null && limit !== undefined && !/^\d+$/.test(limit)) {
          throw new BadRequest('limit must be a positive integer');
        }

        const sortKey = url.searchParams.get('sort') ?? undefined;
        const ask = {
          actor, name, params: params as Record<string, unknown>,
          limit: limit != null ? Number(limit) : undefined,
          cursor,
          sort: sortKey,
          dir: url.searchParams.get('dir') === 'desc' ? 'desc' as const : 'asc' as const,
        };

        if (csv) {
          const { stream, filename } = await streamQueryCsv(options.queries ?? new Map(), options.db, ask);
          return new Response(stream, {
            headers: {
              'content-type': 'text/csv; charset=utf-8',
              'content-disposition': `attachment; filename="${filename}"`,
              'cache-control': 'private, no-store',
            },
          });
        }

        const result = await runQuery(options.queries ?? new Map(), options.db, ask);
        return json({
          data: result.rows,
          meta: { ...meta, count: result.rows.length, nextCursor: result.nextCursor, columns: result.columns },
        });
      }

      if (!modelName) throw new BadRequest('expected /<version>/<action>/<model>/<id?>');

      const rawLimit = url.searchParams.get('limit');
      if (rawLimit !== null && !/^\d+$/.test(rawLimit)) throw new BadRequest('limit must be a positive integer');

      const query: Query & { op?: string } = {
        limit: rawLimit !== null ? Number(rawLimit) : undefined,
        sort: url.searchParams.get('sort') ?? undefined,
        dir: url.searchParams.get('dir') === 'asc' ? 'asc' : undefined,
        cursor: url.searchParams.get('cursor') ?? undefined,
        filters: parseFilters(url),
        op: url.searchParams.get('op') ?? undefined,
      };

      const multipart = request.headers.get('content-type')?.includes('multipart/form-data');
      const staged: StagedFile[] = [];
      const removals: StagedFile[] = [];

      if (multipart) {
        const model = options.models.get(modelName);
        if (!model) throw new NotFound('unknown_model');
        if (Object.keys(model.uploads).length === 0) throw new BadRequest(`${modelName} accepts no uploads`);
        const declared = Number(request.headers.get('content-length') ?? 0);
        const ceiling = Math.max(...Object.values(model.uploads).map((u) => u.maxSize));
        // Reject before buffering when the sender is honest about the size.
        if (declared > ceiling * 2) throw new BadRequest('request body exceeds the maximum upload size');
      }

      const data = READ_OPS.has(action) && action !== 'aggregate'
        ? {}
        : multipart
          ? await readMultipart(request, options.models.get(modelName)!, actor.orgId, options.files!, staged)
          : await readBody();

      attempted.model = modelName;
      attempted.data = data;

      // Before the engine, because a limit that runs after the work is not a
      // limit. Reads are untouched: they are bounded by scope and by the
      // server's own page ceiling, and throttling them would throttle the site.
      if (isAnonymous(actor) && !READ_OPS.has(action)) {
        const limited = guard.check('anonymous-write', client);
        if (limited) return limited;
        guard.attempt('anonymous-write', client);
      }

      const envelope: Envelope = { actor, op: action, model: modelName, id, data, query, meta };

      let result: unknown;
      try {
        // Reads need no transaction; anything that can write gets exactly one.
        result = READ_OPS.has(action)
          ? await engine.execute(envelope, options.db, 0, staged, removals, denied)
          // The WHOLE transaction is what retries, and only on a transient
          // store conflict — see `engine/retry.ts`. A `Denied`, a validation
          // failure and a unique-index conflict are answers, and are not
          // retried. Staged bytes are handled outside the transaction, so a
          // retry does not stage anything twice.
          : await withStoreRetry(() =>
            options.db.tx((tx) => engine.execute(envelope, tx, 0, staged, removals, denied)));
      } catch (error) {
        // The transaction rolled back, so staged bytes must not survive it.
        for (const file of staged) await options.files?.discard(file.orgId, file.id);
        throw error;
      }

      // Committed: promote staged bytes into place, and drop the ones whose rows
      // no longer exist. Both only now — a rollback leaves the disk untouched.
      for (const file of staged) await options.files?.finalise(file.orgId, file.id);
      for (const file of removals) await options.files?.remove(file.orgId, file.id);

      if (action === 'list') {
        const page = result as { rows: Row[]; nextCursor?: string };
        return json({ data: page.rows, meta: { ...meta, count: page.rows.length, nextCursor: page.nextCursor } });
      }
      return json({ data: result, meta: withDenied(meta) }, action === 'create' ? 201 : 200);
    };

    // Successful reads are not audited — that would make every list a write, and
    // the read itself is already constrained by scope. A REFUSED read is audited,
    // because a denial is the signal worth keeping.
    const worthRecording = (error?: unknown) => error !== undefined || !READ_OPS.has(action);

    try {
      const response = await handle();
      await flushElements();
      if (worthRecording()) {
        await audit({ envelope: attempted, status: response.status, detail: deniedDetail() });
      }
      return response;
    } catch (error) {
      const described = describeError(error, meta);
      /**
       * A visitor refused by a gate gets 401, not 403 (S-101).
       *
       * A request with no session carries the anonymous actor rather than
       * stopping at the intake, so a "who are you" refusal arrives here as
       * "you may not" — and answering 403 would tell a signed-out caller to
       * stop trying rather than to sign in. The record
       * keeps the outcome `denied` and the status actually sent, so the audit
       * row and the wire still agree.
       */
      /**
       * ...but only when the GATE refused them, not when their input was.
       *
       * `Denied` covers both: phase one and phase two raise it with the gate's
       * own reasons, and a declared `deny` hook raises it with whatever reason
       * the model wrote. Telling a visitor whose honeypot tripped that they are
       * "unauthenticated" is a lie that also invites them to go and sign in.
       * So the swap is keyed on the gate's own two reasons and nothing else.
       */
      const GATE_REFUSALS = ['forbidden', 'forbidden_for_this_row'];
      const status = described.outcome === 'denied' && isAnonymous(actor)
        && GATE_REFUSALS.includes(String(described.detail))
        ? 401 : described.status;
      const body = status === 401 && described.outcome === 'denied'
        ? { error: 'unauthenticated' } : described.body;

      await flushElements();
      if (worthRecording(error)) await audit({ envelope: attempted, error, status, detail: deniedDetail() });
      return json(body, status);
    }
  };
}
