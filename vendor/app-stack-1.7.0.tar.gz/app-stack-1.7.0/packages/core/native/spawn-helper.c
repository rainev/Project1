/*
 * spawn-helper — give the child a controlling terminal, then exec it.
 *
 * setsid(2) and ioctl(TIOCSCTTY) must run in the child AFTER fork and BEFORE exec.
 * `Bun.spawn` offers no hook there, so the channel runner spawns this tiny program
 * instead: it takes the pty slave path, becomes a session leader, adopts the slave as
 * its controlling terminal, wires stdin/stdout/stderr to it, and execs the real command.
 *
 * Without this a TUI runs with no controlling terminal — job control is unavailable and
 * `stty` cannot see the terminal it is attached to.
 *
 * It also sets the initial window size on the slave itself. Setting it on the master
 * before spawning does NOT survive the child's own open of the slave (measured: the child
 * read 0x0 while the master reported the requested size), and setting it after spawning
 * races the child's first `stty`. Doing it here, between open and exec, is the only
 * ordering with no race.
 *
 *   spawn-helper <slave-path> <rows> <cols> <command> [args...]
 */
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <termios.h>
#include <unistd.h>

int main(int argc, char **argv) {
  if (argc < 5) { fprintf(stderr, "spawn-helper: usage: <slave-path> <rows> <cols> <command> [args...]\n"); return 64; }

  if (setsid() < 0) { perror("spawn-helper: setsid"); return 71; }

  int slave = open(argv[1], O_RDWR);
  if (slave < 0) { perror("spawn-helper: open slave"); return 71; }

#ifdef TIOCSCTTY
  if (ioctl(slave, TIOCSCTTY, 0) < 0) { perror("spawn-helper: TIOCSCTTY"); return 71; }
#endif

  {
    struct winsize ws;
    ws.ws_row = (unsigned short)atoi(argv[2]);
    ws.ws_col = (unsigned short)atoi(argv[3]);
    ws.ws_xpixel = 0; ws.ws_ypixel = 0;
    if (ws.ws_row > 0 && ws.ws_col > 0 && ioctl(slave, TIOCSWINSZ, &ws) < 0) {
      perror("spawn-helper: TIOCSWINSZ"); return 71;
    }
  }

  if (dup2(slave, STDIN_FILENO) < 0 || dup2(slave, STDOUT_FILENO) < 0 || dup2(slave, STDERR_FILENO) < 0) {
    perror("spawn-helper: dup2"); return 71;
  }
  if (slave > STDERR_FILENO) close(slave);

  execvp(argv[4], &argv[4]);
  perror("spawn-helper: execvp");
  return 127;
}
