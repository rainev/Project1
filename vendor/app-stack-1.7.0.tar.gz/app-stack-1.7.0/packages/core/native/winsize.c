/*
 * winsize — set/read a pty's window size.
 *
 * `ioctl` is variadic, and Apple ARM64 passes variadic arguments on the STACK; a plain
 * `bun:ffi` declaration puts the pointer in a register the callee never reads, so the
 * call returns 0 — success — having written nothing. These non-variadic wrappers are
 * the fix. Measured 2026-09-20: without them, setting 32x120 reads back [0,0,0,0].
 */
#include <fcntl.h>
#include <sys/ioctl.h>
#include <termios.h>

int as_set_winsize(int fd, unsigned short rows, unsigned short cols) {
  struct winsize ws;
  ws.ws_row = rows; ws.ws_col = cols; ws.ws_xpixel = 0; ws.ws_ypixel = 0;
  return ioctl(fd, TIOCSWINSZ, &ws);
}

int as_get_rows(int fd) { struct winsize ws; if (ioctl(fd, TIOCGWINSZ, &ws) != 0) return -1; return ws.ws_row; }
int as_get_cols(int fd) { struct winsize ws; if (ioctl(fd, TIOCGWINSZ, &ws) != 0) return -1; return ws.ws_col; }

/*
 * `fcntl` is variadic too, and has the same Apple ARM64 problem as `ioctl`: declared
 * non-variadically through FFI, the third argument goes to a register the callee never
 * reads, so the flags are never set. The fd stays BLOCKING, and a read loop on it stops
 * the event loop dead — observed as a server that spawns a terminal and then freezes.
 */
int as_set_nonblocking(int fd) {
  int flags = fcntl(fd, F_GETFL, 0);
  if (flags < 0) return -1;
  return fcntl(fd, F_SETFL, flags | O_NONBLOCK);
}
