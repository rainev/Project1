/**
 * The component names a view may use, as plain data.
 *
 * Kept separate from `registry.ts` so the SERVER can import it: `registry.ts`
 * imports `.vue` single-file components, which only the Vite build understands.
 * The app hands this list to `createApp`, which then rejects a view naming a
 * component that does not exist — at boot, rather than as a blank area of the
 * page (AUD-029 / DEF-010).
 *
 * `registry.ts` asserts at load that it covers exactly these names, so the two
 * cannot drift.
 */
import { HEADING_PATTERN } from './screens/marked-runs.ts';
import { ICON_PATHS } from './screens/icons.ts';

/**
 * The icons the framework ships, as plain data, for the same reason
 * `COMPONENT_NAMES` is here: the server cross-checks a view's icon names at
 * boot and cannot import a `.vue` file to learn them. The app's own
 * `icons.yaml` is added to these at boot; a name in neither fails the boot.
 */
export const BUILTIN_ICON_NAMES: readonly string[] = Object.keys(ICON_PATHS);

export const COMPONENT_NAMES = [
  'PageShell', 'ListScreen', 'LoginScreen', 'SessionBar', 'FormScreen', 'DataGrid',
  'ChartScreen', 'DetailScreen', 'BoardScreen', 'WizardScreen', 'Navigation', 'LanguagePicker', 'Prose',
  'ReportScreen', 'Dashboard', 'MembersScreen', 'OrgScreen',
  // Content (WP-07 S-102): what a public page is built from.
  'ContentSection', 'ContentList',
  // WP-09 C-101: the repeated small thing — cards, a numbered process, a checklist.
  'ContentCards',
  // WP-09 C-102/C-103: a row of label/value tiles, and an image with actions.
  'ContentStats', 'ContentMedia',
  // What the framework recorded about one row (WP-06 W-122).
  'TimelineScreen',
  // A declared duplex channel, drawn (`x-channels`).
  'Terminal',
  // The workbench: a project's files, a file being edited, and regions behind tabs.
  'FileTree', 'FileEditor', 'Tabs', 'Drawer',
  // Layout and content primitives. Stack, Row and Box take children, so any
  // arrangement is declarable without a new component.
  'Stack', 'Row', 'Box', 'Heading', 'Text', 'Badge', 'Action', 'Media', 'Quote', 'Icon', 'Decor', 'Disclosure',
] as const;

// ConfirmAction is deliberately absent: DataGrid renders it directly from the
// row's actions, so it is not a name a view may use.

export type ComponentName = (typeof COMPONENT_NAMES)[number];

/**
 * What each component's props must look like, for the ones that declare it
 * (WP-07 S-102). Handed to `createApp` beside the names, so `core` validates a
 * view's props at boot without importing the UI package.
 *
 * Partial on purpose. A component with no entry is validated no further than
 * the view meta-schema — which is where every component was until now — so this
 * arrives one at a time instead of as a flag day across sixteen of them.
 */
/**
 * A heading a view author may mark a gradient run in (WP-09 C-115).
 *
 * `Build your [[AI business stack.]]` fills those words and leaves the rest
 * plain. The pattern refuses a stray, empty or nested marker AT BOOT, so a
 * mistyped `[[` is a startup error naming the view rather than a literal `[[`
 * rendered on the page for everyone to read.
 */
const HEADING = { type: 'string', pattern: HEADING_PATTERN } as const;

export const COMPONENT_PROPS: Readonly<Record<string, object>> = {
  /**
   * Added 2026-09-20 after a declaration passed boot with `rowHref` — a prop this component does
   * not have — and silently did nothing. Nothing in any app declares ListScreen yet, so the
   * schema costs no migration; it is one of the 15 that had none (audit B1-G2).
   */
  ListScreen: {
    type: 'object', additionalProperties: false, required: ['model', 'columns'],
    properties: {
      model: { type: 'string', minLength: 1 },
      columns: {
        type: 'array', minItems: 1,
        items: {
          type: 'object', required: ['field', 'label'], additionalProperties: false,
          properties: { field: { type: 'string', minLength: 1 }, label: { type: 'string', minLength: 1 } },
        },
      },
      limit: { type: 'integer', minimum: 1, maximum: 500 },
    },
  },
  /**
   * The grid (AUD-204). It was one of the components with no schema, and it is
   * the one an `icon` key was about to land on — a new key on an unvalidated
   * component is a key a typo silently drops, which is the `rowHref` failure
   * `ListScreen` got its schema for.
   *
   * `rowActions[].when` stays cross-checked in the projection against the
   * model's declared states; this says only that `when` is an object, because
   * the schema cannot know a model's lifecycle.
   */
  DataGrid: {
    type: 'object', additionalProperties: false, required: ['model', 'columns'],
    properties: {
      model: { type: 'string', minLength: 1 },
      columns: {
        type: 'array', minItems: 1,
        items: {
          type: 'object', required: ['field', 'label'], additionalProperties: false,
          properties: {
            field: { type: 'string', minLength: 1 }, label: { type: 'string', minLength: 1 },
            sortable: { type: 'boolean' },
          },
        },
      },
      pageSize: { type: 'integer', minimum: 1, maximum: 500 },
      pageSizes: { type: 'array', minItems: 1, items: { type: 'integer', minimum: 1, maximum: 500 } },
      filterField: { type: 'string', minLength: 1 },
      filter: {
        type: 'object', minProperties: 1,
        additionalProperties: { type: ['string', 'number', 'boolean'] },
      },
      rowHref: { type: 'string', minLength: 1 },
      editHref: { type: 'string', minLength: 1 },
      /** The icon on the built-in Edit link, by name from the app's `icons.yaml`. */
      editIcon: { type: 'string', minLength: 1 },
      /** The icon on the built-in Delete action. */
      deleteIcon: { type: 'string', minLength: 1 },
      deletable: { type: 'boolean' },
      selectable: { type: 'boolean' },
      rowActions: {
        type: 'array', minItems: 1,
        items: {
          type: 'object', required: ['op', 'label'], additionalProperties: false,
          properties: {
            op: { type: 'string', minLength: 1 },
            /** Always the accessible name; the visible text only when there is no icon. */
            label: { type: 'string', minLength: 1 },
            icon: { type: 'string', minLength: 1 },
            title: { type: 'string', minLength: 1 },
            description: { type: 'string', minLength: 1 },
            when: { type: 'object', minProperties: 1 },
          },
        },
      },
    },
  },
  FileTree: {
    type: 'object', additionalProperties: false, required: ['session'],
    properties: {
      session: { type: 'string', minLength: 1 },
      channel: { type: 'string', minLength: 1 },
      model: { type: 'string', minLength: 1 },
      label: { type: 'string', minLength: 1 },
      select: { enum: ['file', 'directory'] },
    },
  },
  FileEditor: {
    type: 'object', additionalProperties: false, required: ['session'],
    properties: {
      session: { type: 'string', minLength: 1 },
      channel: { type: 'string', minLength: 1 },
      model: { type: 'string', minLength: 1 },
      rows: { type: 'integer', minimum: 4, maximum: 200 },
    },
  },
  Drawer: {
    type: 'object', additionalProperties: false, required: ['title'],
    properties: {
      title: { type: 'string', minLength: 1 },
      collapsed: { type: 'boolean' },
      side: { enum: ['left', 'right'] },
    },
  },
  Tabs: {
    type: 'object', additionalProperties: false, required: ['tabs'],
    properties: {
      tabs: {
        type: 'array', minItems: 1,
        items: {
          type: 'object', required: ['id', 'label'], additionalProperties: false,
          properties: { id: { type: 'string', minLength: 1 }, label: { type: 'string', minLength: 1 } },
        },
      },
    },
  },
  Terminal: {
    type: 'object', additionalProperties: false, required: ['session'],
    properties: {
      session: { type: 'string', minLength: 1 },
      channel: { type: 'string', minLength: 1 },
      model: { type: 'string', minLength: 1 },
      rows: { type: 'integer', minimum: 4, maximum: 200 },
    },
  },
  Stack: {
    type: 'object', additionalProperties: false,
    properties: { gap: { type: 'string', minLength: 1 }, align: { type: 'string', minLength: 1 }, justify: { type: 'string', minLength: 1 }, pad: { type: 'string', minLength: 1 }, measure: { type: 'string', minLength: 1 }, center: { type: 'boolean' }, offset: { type: 'string', minLength: 1 }, anchor: { type: 'string', minLength: 1 }, width: { type: 'string', minLength: 1 }, height: { type: 'string', minLength: 1 }, radius: { type: 'string', minLength: 1 }, background: { type: 'string', minLength: 1 }, gradient: { type: 'string', minLength: 1 }, shadow: { type: 'string', minLength: 1 }, borderInk: { type: 'string', minLength: 1 }, divide: { type: 'boolean' },
                  border: { anyOf: [{ type: 'boolean' }, { enum: ['t', 'b', 'l', 'r', 'x', 'y'] }] }, column: { type: 'string', minLength: 1 }, place: { enum: ['start', 'center', 'end', 'stretch'] } },
  },
  Row: {
    type: 'object', additionalProperties: false,
    properties: { tracks: { anyOf: [{ type: 'string', minLength: 1 }, { type: 'object', additionalProperties: false,
                    properties: { sm: { type: 'string', minLength: 1 }, md: { type: 'string', minLength: 1 }, lg: { type: 'string', minLength: 1 } } }] }, gap: { type: 'string', minLength: 1 }, align: { type: 'string', minLength: 1 }, justify: { type: 'string', minLength: 1 }, pad: { type: 'string', minLength: 1 },
                  wrap: { type: 'boolean' }, offset: { type: 'string', minLength: 1 }, background: { type: 'string', minLength: 1 }, radius: { type: 'string', minLength: 1 },
                  borderInk: { type: 'string', minLength: 1 }, clip: { type: 'boolean' }, measure: { type: 'string', minLength: 1 }, center: { type: 'boolean' },
                  border: { anyOf: [{ type: 'boolean' }, { enum: ['t', 'b', 'l', 'r', 'x', 'y'] }] } },
  },
  Box: {
    type: 'object', additionalProperties: false,
    properties: { tone: { enum: ['hero', 'plain', 'invert', 'band', 'gradient', 'card'] },
                  pad: { type: 'string', minLength: 1 },
      /** Span the viewport, escaping the page measure. */
      bleed: { type: 'boolean' },
      /** Background colour, any CSS colour. */
      background: { type: 'string', minLength: 1 }, gradient: { type: 'string', minLength: 1 }, radius: { type: 'string', minLength: 1 }, measure: { type: 'string', minLength: 1 }, align: { type: 'string', minLength: 1 }, offset: { type: 'string', minLength: 1 }, blur: { type: 'string', minLength: 1 },
                  shadow: { type: 'string', minLength: 1 }, borderInk: { type: 'string', minLength: 1 },
                  border: { anyOf: [{ type: 'boolean' }, { enum: ['t', 'b', 'l', 'r', 'x', 'y'] }] }, clip: { type: 'boolean' }, relative: { type: 'boolean' }, center: { type: 'boolean' }, lift: { type: 'boolean' }, anchor: { type: 'string', minLength: 1 }, width: { type: 'string', minLength: 1 }, height: { type: 'string', minLength: 1 }, column: { type: 'string', minLength: 1 }, place: { enum: ['start', 'center', 'end', 'stretch'] } },
  },
  Heading: {
    type: 'object', additionalProperties: false, required: ['text'],
    properties: { text: HEADING, level: { type: 'integer', minimum: 1, maximum: 4 },
                  display: { enum: ['lg', 'md', 'plain', 'none'] }, weight: { type: 'string', minLength: 1 }, tracking: { type: 'string', minLength: 1 }, size: { type: 'string', minLength: 1 }, leading: { type: 'string', minLength: 1 }, center: { type: 'boolean' }, align: { type: 'string', minLength: 1 }, measure: { type: 'string', minLength: 1 },
                  scale: { enum: ['xs', 'sm', 'base', 'lg', 'xl', '2xl', '3xl', '4xl', '5xl', '6xl'] }, scaleUp: { enum: ['xs', 'sm', 'base', 'lg', 'xl', '2xl', '3xl', '4xl', '5xl', '6xl'] }, offset: { type: 'string', minLength: 1 },
                  tone: { enum: ['ink', 'canvas', 'muted'] } },
  },
  Text: {
    type: 'object', additionalProperties: false, required: ['text'],
    properties: { text: { type: 'string' }, size: { type: 'string', minLength: 1 }, weight: { type: 'string', minLength: 1 },
                  tone: { enum: ['ink', 'muted', 'accent', 'canvas'] }, transform: { type: 'string', minLength: 1 },
                  tracking: { type: 'string', minLength: 1 }, leading: { type: 'string', minLength: 1 }, strike: { type: 'boolean' },
                  align: { type: 'string', minLength: 1 }, measure: { type: 'string', minLength: 1 },
                  scale: { enum: ['xs', 'sm', 'base', 'lg', 'xl', '2xl', '3xl', '4xl', '5xl', '6xl'] }, scaleUp: { enum: ['xs', 'sm', 'base', 'lg', 'xl', '2xl', '3xl', '4xl', '5xl', '6xl'] }, offset: { type: 'string', minLength: 1 },
                  strikeInk: { type: 'string', minLength: 1 }, strikeWidth: { type: 'string', minLength: 1 },
                  ink: { type: 'string', minLength: 1 }, mono: { type: 'boolean' }, center: { type: 'boolean' } },
  },
  Badge: {
    type: 'object', additionalProperties: false, required: ['text'],
    properties: { text: { type: 'string', minLength: 1 }, icon: { type: 'string', minLength: 1 }, tone: { enum: ['pill', 'plain'] }, offset: { type: 'string', minLength: 1 } },
  },
  Action: {
    type: 'object', additionalProperties: false, required: ['label', 'href'],
    properties: { label: { type: 'string', minLength: 1 }, href: { type: 'string', minLength: 1 }, emphasis: { enum: ['primary', 'secondary', 'invert', 'outline'] }, icon: { type: 'string', minLength: 1 }, offset: { type: 'string', minLength: 1 } },
  },
  Media: {
    type: 'object', additionalProperties: false, required: ['src', 'alt'],
    properties: { src: { type: 'string', minLength: 1 }, alt: { type: 'string' }, bloom: { type: 'boolean' },
                  shadow: { type: 'string', minLength: 1 }, radius: { type: 'string', minLength: 1 }, measure: { type: 'string', minLength: 1 }, offset: { type: 'string', minLength: 1 } },
  },
  Quote: {
    type: 'object', additionalProperties: false, required: ['text'],
    properties: { text: { type: 'string', minLength: 1 }, size: { type: 'string', minLength: 1 }, measure: { type: 'string', minLength: 1 }, offset: { type: 'string', minLength: 1 },
                  ruleInk: { type: 'string', minLength: 1 } },
  },
  Disclosure: {
    type: 'object', additionalProperties: false, required: ['summary', 'body'],
    properties: { summary: { type: 'string', minLength: 1 }, body: { type: 'string', minLength: 1 }, offset: { type: 'string', minLength: 1 },
                  measure: { type: 'string', minLength: 1 }, icon: { type: 'string', minLength: 1 } },
  },
  /**
   * A decorative layer a view places inside a positioned box — a corner bloom,
   * a gradient hairline. Inert: it takes no text and no children.
   */
  Decor: {
    type: 'object', additionalProperties: false,
    properties: { top: { type: 'string', minLength: 1 }, right: { type: 'string', minLength: 1 }, bottom: { type: 'string', minLength: 1 }, left: { type: 'string', minLength: 1 },
                  width: { type: 'string', minLength: 1 }, height: { type: 'string', minLength: 1 }, radius: { type: 'string', minLength: 1 },
                  ink: { type: 'string', minLength: 1 }, gradient: { type: 'string', minLength: 1 }, blur: { type: 'string', minLength: 1 }, opacity: { type: 'string', minLength: 1 } },
  },
  /**
   * An icon a view places on its own, rather than one a component draws for
   * itself. The scroll cue is a caption beside a bouncing chevron: two
   * elements, one of which no existing component could put on the page.
   */
  Icon: {
    type: 'object', additionalProperties: false, required: ['name'],
    properties: { name: { type: 'string', minLength: 1 }, size: { type: 'string', minLength: 1 },
                  color: { type: 'string', minLength: 1 }, tone: { enum: ['ink', 'muted', 'accent', 'canvas'] },
                  animate: { enum: ['bounce', 'pulse', 'spin'] }, offset: { type: 'string', minLength: 1 }, weight: { type: 'string', minLength: 1 } },
  },

  /**
   * The page itself (WP-09 C-111, C-114, C-118, C-119, C-120).
   *
   * Closed, like the rest: a misspelt `widht` that silently renders the default
   * measure is exactly the kind of half-applied config this validation exists
   * to refuse at boot rather than in a screenshot.
   */
  /**
   * `items` is not declared: it is INJECTED per navigation, like `Navigation`'s
   * own items and `SessionBar`'s session. A view that wrote its own would be
   * overwritten, so the schema does not invite one.
   */
  LanguagePicker: {
    type: 'object',
    additionalProperties: false,
    properties: { label: { type: 'string', minLength: 1 } },
  },
  PageShell: {
    type: 'object',
    additionalProperties: false,
    properties: {
      title: HEADING,
      subtitle: { type: 'string' },
      eyebrow: { type: 'string' },
      /**
       * One of the four names, or any CSS length — AUD-114. `wide` is 1152px and
       * the reference runs to 1400px, which no name could say.
       */
      width: { type: 'string', minLength: 1 },
      /** A CSS length. The heading column's measure when the page is not split. */
      measure: { type: 'string', minLength: 1 },
      /** A minimum height for the heading block, any CSS length — AUD-090. */
      heroMin: { type: 'string', minLength: 1 }, heroClose: { type: 'string', minLength: 1 }, heroRule: { type: 'boolean' }, rhythm: { type: 'boolean' }, pad: { type: 'string', minLength: 1 }, insetGutter: { type: 'boolean' },
      /** The gutter between the measure and the viewport edge — AUD-091. */
      gutter: { type: 'string', minLength: 1 },
      /** Split the hero itself; `#hero-aside` fills the second track — AUD-094. */
      heroRatio: { type: 'string', minLength: 1 },
      /** The eyebrow as bare text or a bordered pill — AUD-122. */
      eyebrowVariant: { enum: ['plain', 'pill'] },
      /** An icon before the eyebrow, by name from the framework's set. */
      eyebrowIcon: { type: 'string', minLength: 1 },
      /** The quieter paragraph below the subtitle — AUD-122. */
      body: { type: 'string' },
      actions: {
        type: 'array',
        items: {
          type: 'object',
          required: ['label', 'href'],
          additionalProperties: false,
          properties: {
            label: { type: 'string', minLength: 1 },
            href: { type: 'string', minLength: 1 },
            emphasis: { enum: ['primary', 'secondary', 'invert'] },
          },
        },
      },
      display: { enum: ['lg', 'md', 'plain', 'none'] }, weight: { type: 'string', minLength: 1 }, tracking: { type: 'string', minLength: 1 },
      columns: {
        type: 'object',
        additionalProperties: false,
        properties: {
          /** A `grid-template-columns` value, e.g. `.72fr 1.28fr`. */
          ratio: { type: 'string', minLength: 1 },
          sticky: { type: 'boolean' },
        },
      },
      brand: {
        type: 'object',
        additionalProperties: false,
        properties: {
          /**
           * Draw the language picker in the header strip. The items themselves
           * are injected per navigation, never declared — `languageItems` is
           * here so the schema admits what the injection writes.
           */
          languages: { type: 'boolean' },
          languageItems: { type: 'array' },
          logo: { type: 'string', minLength: 1 },
          wordmark: { type: 'string', minLength: 1 },
          backHref: { type: 'string', minLength: 1 },
          backLabel: { type: 'string', minLength: 1 },
          tagline: { type: 'string', minLength: 1 },
          backIcon: { type: 'string', minLength: 1 },
          backFirst: { type: 'boolean' },
        },
      },
      backdrop: { anyOf: [{ type: 'boolean' }, { enum: ['hero', 'page'] }] },
      rule: { type: 'boolean' },
    },
  },
  ContentSection: {
    type: 'object',
    additionalProperties: false,
    properties: {
      eyebrow: { type: 'string' },
      badge: { type: 'string' },
      heading: HEADING,
      standfirst: { type: 'string' },
      body: { type: 'string' },
      align: { enum: ['start', 'center'] },
      columns: { type: 'integer', minimum: 1, maximum: 2 },
      /**
       * The split's track ratio, a `grid-template-columns` value — AUD-106.
       * Implies `columns: 2`. Same spelling as `PageShell.columns.ratio`.
       */
      /** An icon above the eyebrow, from the app's declared set. */
      /** Block padding for this section, any CSS padding value. */
      pad: { type: 'string', minLength: 1 },
      /** Corner radius for this block, any CSS length. */
      radius: { type: 'string', minLength: 1 },
      /** Span the viewport, escaping the page measure. */
      bleed: { type: 'boolean' },
      /** Background colour, any CSS colour. */
      background: { type: 'string', minLength: 1 },
      /** Which edges carry a border: true for all, 'y' or 'x' for a pair. */
      border: { anyOf: [{ type: 'boolean' }, { enum: ['y', 'x'] }] },
      icon: { type: 'string', minLength: 1 },
      /** That icon's colour, any CSS colour. */
      iconColor: { type: 'string', minLength: 1 },
      ratio: { type: 'string', minLength: 1 },
      rule: { type: 'boolean' },
      display: { enum: ['lg', 'md'] },
      tone: { enum: ['hero', 'plain', 'invert', 'band', 'gradient', 'card'] },
      actions: {
        type: 'array',
        items: {
          type: 'object',
          required: ['label', 'href'],
          additionalProperties: false,
          properties: {
            label: { type: 'string', minLength: 1 },
            href: { type: 'string', minLength: 1 },
            emphasis: { enum: ['primary', 'secondary', 'invert'] },
          },
        },
      },
    },
  },
  TimelineScreen: {
    type: 'object',
    additionalProperties: false,
    required: ['model', 'id'],
    properties: {
      model: { type: 'string', minLength: 1 },
      id: { type: 'string', minLength: 1 },
      title: { type: 'string' },
    },
  },
  ContentCards: {
    type: 'object',
    additionalProperties: false,
    required: ['items'],
    properties: {
      eyebrow: { type: 'string' },
      heading: HEADING,
      standfirst: { type: 'string' },
      /** The section's own heading/items split — see ContentCards.ratio. */
      ratio: { type: 'string', minLength: 1 },
      /** Inner padding of each card, any CSS length — AUD-098. */
      cardPad: { type: 'string', minLength: 1 },
      /** Gap between items, any CSS length. */
      gap: { type: 'string', minLength: 1 },
      /** Corner radius of each item, any CSS length. */
      itemRadius: { type: 'string', minLength: 1 },
      /** A numbered marker as bare text, or a chip. */
      markerStyle: { enum: ['plain', 'chip'] },
      /** Which edges of a check item carry a rule: none, top, or all. */
      itemBorder: { enum: ['none', 'top', 'all'] },
      tone: { enum: ['hero', 'plain', 'invert', 'band', 'gradient', 'card'] },
      /** An icon above the heading, from the app's declared set. */
      /** Block padding for this section, any CSS padding value. */
      pad: { type: 'string', minLength: 1 },
      /** Corner radius for this block, any CSS length. */
      radius: { type: 'string', minLength: 1 },
      /** Span the viewport, escaping the page measure. */
      bleed: { type: 'boolean' },
      /** Background colour, any CSS colour. */
      background: { type: 'string', minLength: 1 },
      /** Which edges carry a border: true for all, 'y' or 'x' for a pair. */
      border: { anyOf: [{ type: 'boolean' }, { enum: ['y', 'x'] }] },
      icon: { type: 'string', minLength: 1 },
      /** That icon's colour, any CSS colour. */
      iconColor: { type: 'string', minLength: 1 },
      variant: { enum: ['number', 'hairline', 'icon', 'check', 'plain', 'accordion'] },
      display: { enum: ['lg', 'md'] },
      itemHeading: { enum: ['h3', 'h4', 'none'] },
      columns: { type: 'integer', minimum: 1, maximum: 4 },
      items: {
        type: 'array',
        minItems: 1,
        items: {
          anyOf: [
            { type: 'string', minLength: 1 },
            {
              type: 'object',
              required: ['title'],
              additionalProperties: false,
              properties: {
                marker: { type: 'string' },
                title: { type: 'string', minLength: 1 },
                body: { type: 'string' },
              },
            },
          ],
        },
      },
    },
  },
  ContentStats: {
    type: 'object',
    additionalProperties: false,
    required: ['items'],
    properties: {
      eyebrow: { type: 'string' },
      heading: HEADING,
      columns: { type: 'integer', minimum: 1, maximum: 4 },
      variant: { enum: ['plain', 'card'] },
      items: {
        type: 'array',
        minItems: 1,
        items: {
          type: 'object',
          required: ['label'],
          additionalProperties: false,
          properties: {
            label: { type: 'string', minLength: 1 },
            // An authored value, or a declared query to read one from. A
            // privileged number belongs in the query, which is gated; props are
            // copied to the browser wholesale and are not.
            value: { type: 'string' },
            query: { type: 'string', minLength: 1 },
            valueKey: { type: 'string', minLength: 1 },
            // Shown when the query read successfully and matched nothing.
            // Never shown when it was refused — see the component.
            emptyValue: { type: 'string' },
            note: { type: 'string' },
          icon: { type: 'string', minLength: 1 },
          },
        },
      },
    },
  },
  ContentMedia: {
    type: 'object',
    additionalProperties: false,
    // `alt` is required: an image a view author cannot describe is one a screen
    // reader cannot announce. A decorative image declares an empty string.
    required: ['src', 'alt'],
    properties: {
      eyebrow: { type: 'string' },
      heading: HEADING,
      standfirst: { type: 'string' },
      src: { type: 'string', minLength: 1 },
      alt: { type: 'string' },
      surface: { enum: ['plain', 'panel', 'inset', 'bloom'] },
      download: { type: 'string', minLength: 1 },
      openLabel: { type: 'string', minLength: 1 },
      size: { enum: ['sm', 'md', 'lg', 'full'] },
    },
  },
  ContentList: {
    type: 'object',
    additionalProperties: false,
    required: ['model', 'titleField'],
    properties: {
      model: { type: 'string', minLength: 1 },
      titleField: { type: 'string', minLength: 1 },
      summaryField: { type: 'string' },
      dateField: { type: 'string' },
      hrefTemplate: { type: 'string' },
      limit: { type: 'integer', minimum: 1 },
      sort: { type: 'string' },
      dir: { enum: ['asc', 'desc'] },
      heading: { type: 'string' },
      emptyText: { type: 'string' },
    },
  },
};
