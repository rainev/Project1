/**
 * Stroke-based icon paths on a 24 grid. The component sets size and colour.
 *
 * These exist for what framework components draw for THEMSELVES — the
 * accordion chevron, a tick, an action's arrow, the grid's sort and refresh
 * controls. An application is never forced to declare them, and is never
 * limited to them: a name an app declares in its own `icons.yaml` wins
 * (`Icon.vue`). The app's vocabulary is for what the APP names.
 */
export const ICON_PATHS: Record<string, string> = {
  check: 'M20 6 9 17l-5-5',
  arrowRight: 'M5 12h14 M12 5l7 7-7 7',
  chevronDown: 'm6 9 6 6 6-6',
  // The grid's own chrome (G5): the sort indicator and the refresh control.
  sortAscending: 'M18 15l-6-6-6 6',
  sortDescending: 'M6 9l6 6 6-6',
  refresh: 'M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8 M21 3v5h-5',
  sparkles: 'M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z',
};
