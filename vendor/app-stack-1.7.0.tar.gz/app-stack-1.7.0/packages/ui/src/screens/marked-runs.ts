/**
 * A marked run inside a heading (WP-09 C-115, revised).
 *
 * The reference does not gradient-fill a heading. It fills PART of one: the h1
 * is white and a span inside it carries the ramp — "Build your
 * **AI business stack.**". Filling the whole heading, which is what the first
 * pass did, is a different design that happens to use the same property, and it
 * measures differently: our h1 computed `rgba(0, 0, 0, 0)` with a background
 * image, the reference's computes `rgb(255, 255, 255)` with none.
 *
 * `AI-BUSINESS-STACK-COMPONENTS.md` specified this as "a marker in the heading
 * string" rather than a prop, and that is the right shape: which WORDS are
 * filled is part of the sentence, so it belongs in the sentence. A separate
 * `gradientWords` prop would restate a substring of the heading and drift from
 * it the moment anyone edits the copy.
 *
 * ## The marker
 *
 * `[[...]]` — `Build your [[AI business stack.]]`.
 *
 * It stays plain text on both sides of this function. A run is rendered into a
 * `<span>` as a TEXT NODE, never through `v-html`, for the reason
 * `ContentSection` states at length: the same component renders a field off a
 * row the moment anyone points it at one, and a row is data. This is a
 * presentation marker over a fixed vocabulary of one, not a markup subset.
 *
 * ## YAML
 *
 * A plain scalar may not START with `[` — that is a flow sequence — so a
 * heading beginning with the marker must be quoted:
 *
 *     heading: "[[7,500 pesos]] per seat"     # quoted, because it starts with [
 *     heading: One workshop. [[One working solution.]]
 *
 * Unbalanced or nested markers are refused at BOOT by the `pattern` on every
 * heading prop in `COMPONENT_PROPS`, so a stray `[[` is a startup error naming
 * the view rather than a literal `[[` rendered on the page.
 */

export interface Run {
  text: string;
  /** Render this run filled with the text gradient. */
  marked: boolean;
}

/**
 * The shape a heading may take, as a source-of-truth for the boot schema.
 *
 * Square brackets appear ONLY as balanced, non-empty, non-nested `[[ ]]` pairs.
 * Anything else — a stray `[`, an empty `[[]]`, a nested pair — is refused.
 */
export const HEADING_PATTERN = '^[^\\[\\]]*(?:\\[\\[[^\\[\\]]+\\]\\][^\\[\\]]*)*$';

/**
 * Split a heading into its plain and marked runs.
 *
 * A heading with no marker yields one unmarked run, which is every heading
 * written before this existed — so nothing changes for them.
 */
export function markedRuns(text: string): Run[] {
  const runs: Run[] = [];
  let index = 0;
  const pattern = /\[\[([^[\]]+)\]\]/g;
  let match: RegExpExecArray | null;

  while ((match = pattern.exec(text)) !== null) {
    if (match.index > index) runs.push({ text: text.slice(index, match.index), marked: false });
    runs.push({ text: match[1], marked: true });
    index = match.index + match[0].length;
  }
  if (index < text.length) runs.push({ text: text.slice(index), marked: false });

  return runs.length ? runs : [{ text, marked: false }];
}

/** Does this heading ask for a gradient run at all? */
export const hasMarkedRun = (text: string | undefined): boolean =>
  typeof text === 'string' && /\[\[[^[\]]+\]\]/.test(text);
